/**
 * OneUI Angular Generator
 *
 * Usage:
 *    gulp / gulp serve
 *        Default task for local development.
 *      Builds styles, scripts, and templates and
 *      starts a connect server with watches.
 *        gulp release
 *            gulp tasks for building on Jenkins and releasing
 */
var gulp = require('gulp'),
    sass = require('gulp-sass'),
    bump = require('gulp-bump'),
    fs = require('fs'),
    tag = require('gulp-tag-version'),
    filter = require('gulp-filter'),
    uglify = require('gulp-uglify'),
    connect = require('gulp-connect'),
    concat = require('gulp-concat'),
    sourcemaps = require('gulp-sourcemaps'),
    proxy = require('proxy-middleware'),
    url = require('url'),
    templateCache = require('gulp-angular-templatecache');

var config = {
    appName: 'fs-sso-support-ui',
    sources: {
        scripts: [
            'bower_components/angular/angular.js',
            'bower_components/angular-ui-router/release/angular-ui-router.js',
            'bower_components/angular-sanitize/angular-sanitize.js',
            'bower_components/angular-messages/angular-messages.js',
            'bower_components/oneui-*/dist/oneui-*.js',
            'app/app.module.js',
            'app/app.config.js',
            'app/app.run.js',
            'app/*/scripts/*.module.js',
            'app/*/scripts/*.config.js',
            'app/*/scripts/*.run.js',
            'app/*/scripts/*.routes.js',
            'app/*/scripts/*.service.js',
            'app/*/scripts/*.factory.js',
            'app/*/scripts/*.provider.js',
            'app/*/scripts/*.controller.js',
            'app/*/scripts/*.service.js',
            'app/*/scripts/*.directive.js',
            'app/*/scripts/*.filter.js',
            'app/templates.js'
        ],
        fonts: [
            'bower_components/oneui-core-style/dist/fonts/*',
            'bower_components/oneui-icons/dist/fonts/*',
            'bower_components/angular-ui-grid/*',
            'app/core/assets/fonts/*'
        ],
        images: [
            'app/core/assets/images/*',
            'bower_components/oneui-header/dist/assets/images/*',
            'bower_components/oneui-footer/dist/assets/images/*',
            'bower_components/angular-ui-grid/*'
        ],
        style: [
            'app/core/styles/app.scss'
        ],
        templates: [
            'app/**/*.html'
        ],
        tests: [
            'app/build/all.js',
            'app/*/scripts/*.js',
            'bower_components/angular-mocks/angular-mocks.js',
            'bower_components/jquery/dist/jquery.js',
            'tests/specs/*.js'
        ]
    }
};

var localServerPort = 9000;

// Start a connect server with livereload
gulp.task('connect', function () {

    connect.server({
        root: 'app',
        livereload: true,
        port: localServerPort

    });


});

gulp.task('connectLocal', function () {
    connect.server({
        root: 'app',
        livereload: true,
        port: localServerPort,
        open: {
            browser: 'google chrome' // if not working OS X browser: 'Google Chrome'
        },
        middleware: function(connect, o) {
            return [(function () {
                var url = require('url');
                var proxy = require('proxy-middleware');

                 var options = url.parse('http://localhost:9090/fs-sso-support-app-web/');
                options.route = '/fs-sso-support-app-web';
                return proxy(options);
            })()];
        }

    });


});
gulp.task('connectDev', function () {

    connect.server({
        root: 'app',
        livereload: true,
        port: localServerPort,
        open: {
            browser: 'chrome' // if not working OS X browser: 'Google Chrome'
        },
        middleware: function(connect, o) {
            return [(function () {
                var url = require('url');
                var proxy = require('proxy-middleware');
                var options = url.parse('http://fsso-spt-devapp.cloud.capitalone.com/fs-sso-support-app-web/');
                options.route = '/fs-sso-support-app-web';
                return proxy(options);
            })()];
        }

    });


});

gulp.task('connectQa', function () {

    connect.server({
        root: 'app',
        livereload: true,
        port: localServerPort,
        open: {
            browser: 'chrome' // if not working OS X browser: 'Google Chrome'
        },
        middleware: function(connect, o) {
            return [(function () {
                var url = require('url');
                var proxy = require('proxy-middleware');

                var options = url.parse('http://fsso-spt-qaapp.cloud.capitalone.com/fs-sso-support-app-web/');
                options.route = '/fs-sso-support-app-web';
                return proxy(options);
            })()];
        }

    });


});

gulp.task('rebuild', function () {
    connect.server({
        root: "rebuild",
        livereload: true,
        port: localServerPort
    });
});

// Watches
gulp.task('watch', ['build'], function () {
    gulp.watch('app/**.*.scss', ['build-css']);
    gulp.watch('app/**/*.scss', ['build-css']);
    gulp.watch([config.sources.scripts, '!app/templates.js', config.sources.templates], ['build-js']);
    gulp.watch(['app/**/*.html'], ['build-js']);
});

// Cache templates
gulp.task('cache-templates', function () {
    return gulp.src(config.sources.templates)
        .pipe(templateCache('templates.js', {module: config.appName}))
        .pipe(gulp.dest('app'));
});

// Build style
gulp.task('build-css', function () {
    return gulp.src(config.sources.style)
        .pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(sourcemaps.write())
        .pipe(gulp.dest('app/build'))
        .pipe(connect.reload());
});

// Build scripts
gulp.task('build-js', ['cache-templates'], function () {
    return gulp.src(config.sources.scripts)
        .pipe(sourcemaps.init())
        .pipe(concat('all.js'))
        .pipe(sourcemaps.write())
        .pipe(gulp.dest('app/build'))
        .on('end', function () {
            // remove the app/templates.js file when the concat/dest is done
            fs.unlinkSync('app/templates.js');
        })
        .pipe(connect.reload());
});

gulp.task("copy-fonts", function () {
    return gulp.src(config.sources.fonts)
        .pipe(gulp.dest('app/build/assets/fonts'));
});

gulp.task("copy-images", function () {
    return gulp.src(config.sources.images)
        .pipe(gulp.dest('app/build/assets/images'));
});


//create task to copy assets
gulp.task("copy-assets", ['copy-fonts', 'copy-images']);


//create build task
gulp.task('build', ['build-js', 'copy-assets', 'build-css']);

// task to build and run locally
// does build also, which is a dependency of 'watch'
gulp.task('serve', ['watch', 'connect']);
gulp.task('local', ['watch', 'connectLocal']);
gulp.task('dev', ['watch', 'connectDev']);
gulp.task('qa', ['watch', 'connectQa']);


//task to build and update version on server
gulp.task('release', ['build']);

//default task
gulp.task('default', ['serve']);
gulp.task('new', ['watch', 'rebuild']);
