(function () {
    'use strict';

    angular
        .module('account')
        .controller('accountController', accountController);

    accountController.$inject = ['$state', 'accountFactory', '$scope'];

    /** Angualr filter to map id and dropdown values for Lock Status*/

    angular
        .module('account')
        .filter('mapLockStatus', function () {
            var lockStatusHash = {
                1: 'UNLOCKED',
                2: 'LOCKED'
            };
            return function (input) {
                if (!input) {
                    return '';
                } else {
                    return lockStatusHash[input];
                }
            };

        });


    function accountController($state, accountFactory, $scope) {

        $scope.tooltipObj = {
            text: "Please Create SLR and Contact Home Loans FRAUD", //required
            showIcon: true, //optional - no default
            placement: "right" //optional - default "top"
        };


        var vm = this;

        vm.accounts = accountFactory;

        activate();


        function activate() {
            vm.data = accountFactory.get();
            if (Object.keys(vm.data).length) {

            } else {
                $state.go('fsSsoSupport.search');
            }
        }


    }
})();