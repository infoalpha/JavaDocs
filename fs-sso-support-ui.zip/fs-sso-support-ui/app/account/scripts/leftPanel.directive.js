(function (angular) {
    'use strict';

    angular
        .module('account')
        .directive('leftPanel', leftPanel);

    leftPanel.$inject = ['accountFactory'];
    function leftPanel(accountFactory) {
        leftPanelController.$inject = [];
        function leftPanelController() {
            this.limit = 10;
            this.search = function (ssn) {
                this.submitted = true;
                if (this.searchForm.ssn.$valid) {
                    this.searchForm.$setPristine();
                    accountFactory.add(ssn).then(data => {
                        this.ssn = '';
                        this.submitted = false;
                    }, error => {
                        this.ssn = '';
                        this.submitted = false;
                    });
                }

            };

            this.accountFactory = accountFactory;

            this.increaseLimit = function () {
                this.limit += 10;
            };

            this.filterValue = function ($event) {
                this.submitted = false;
                if ($event.charCode === 0) {
                    return;
                }
                else if ($event.charCode < 48 || $event.charCode > 57) {
                    $event.preventDefault();
                    return;
                } else {
                    return;
                }
            };

        }

        return {
            templateUrl: 'account/partials/applicantInfo.html',
            bindToController: true,
            controller: leftPanelController,
            controllerAs: 'Account',
            restrict: 'AE'
        };
    }

})(window.angular);
