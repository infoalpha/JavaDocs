// This Sevice is used to manipulate Account Data after Search is executed


(function (angular) {
    'use strict';

    angular
        .module('fs-sso-support-ui')
        .service('AccountService', AccountService);

    AccountService.$inject = ['$http','cofModal', 'FS_SSO_SUPPORT_CONSTANTS', 'Flash'];
    function AccountService($http,cofModal, FS_SSO_SUPPORT_CONSTANTS, Flash) {
        class Account {
            constructor(account) {
                angular.extend(this, account);
                this.digitalProfileInformations.map(profile => {
                    profile.lockStatuses.map(status => {
                        status.lockStatus.toLowerCase() === 'unlocked' ? status.status = true : status.status = false;
                    });
                });
            }

            getFullName() {
                return `${this.applicantDataList[0].firstName} ${this.applicantDataList[0].lastName}`;
            }

            parseLockStatus(status) {
                return status == 'unlocked' ? false : true;
            }

            // If user is Fraud locked . We should not allow agent to unlock profile
            userFraudLockValidation(lockStatus, profile) {
                var response = true;
                profile.lockStatuses.map(status => {

                    if (lockStatus.lockType === FS_SSO_SUPPORT_CONSTANTS.profile) {
                        if (status.lockType === FS_SSO_SUPPORT_CONSTANTS.fraud && status.status === false) {

                            lockStatus.status = false;
                            Flash.create('danger', FS_SSO_SUPPORT_CONSTANTS.userFraudLockValidationMessage);
                            response = false;
                        }
                    }
                });

                return response;
            }

            changeProfileLockStatusBasedOnFraudLock(lockStatus, profile) {
                // Api will unlock/lock profile lock when fraud lock is unlocked/locked
                profile.lockStatuses.map(status => {

                    if (lockStatus.lockType === FS_SSO_SUPPORT_CONSTANTS.fraud) {
                        if (status.lockType === FS_SSO_SUPPORT_CONSTANTS.profile) {
                            if (lockStatus.status) {
                                status.lockStatus = 'UNLOCKED';
                                status.status = true;
                            } else {
                                status.lockStatus = 'LOCKED';
                                status.status = false;
                            }

                        }
                    }
                });

            }

            restoreLockStatus(lockStatus, profile) {

                if (lockStatus.status) {
                    lockStatus.status = false
                    lockStatus.lockStatus = 'LOCKED';
                } else {
                    lockStatus.status = true
                    lockStatus.lockStatus = 'UNLOCKED';
                }

                this.changeProfileLockStatusBasedOnFraudLock(lockStatus, profile);

            }


            changeStatus(lockStatus, profile) {

                Flash.clear();

                if (this.userFraudLockValidation(lockStatus, profile)) {
                    this.changeProfileLockStatusBasedOnFraudLock(lockStatus, profile);
                    if (lockStatus.status) {
                        lockStatus.lockStatus = 'UNLOCKED';
                    } else {
                        lockStatus.lockStatus = 'LOCKED';
                    }
                    this.updateLockStatus(lockStatus, profile)

                }
            }

            updateLockStatus(lockStatus, profile) {

                var lockOperation;

                if (lockStatus.status) {
                    lockOperation = 'UNLOCK';
                } else {
                    lockOperation = 'LOCK';
                }

                return $http({
                    method: 'POST',
                    url: FS_SSO_SUPPORT_CONSTANTS.updateLockStatusURL,
                    data: '',
                    headers: {
                        'lockType': lockStatus.lockType,
                        'ssoId': profile.ssoId,
                        'lockOperation': lockOperation,
                        'agentId': FS_SSO_SUPPORT_CONSTANTS.agentId,
                        'Client-Correlation-Id':this.correlationID
                    }
                }).then(response => {
                    return response;
                }, error=> {
                    this.restoreLockStatus(lockStatus, profile);
                    Flash.create('danger', error.data.text);
                    return error;
                });
            }

            unlockAll(index) {
                Flash.clear();
                return $http({
                    method: 'POST',
                    url: FS_SSO_SUPPORT_CONSTANTS.unLockAllURL,
                    data: '',
                    headers: {
                        'ssoId': this.digitalProfileInformations[index].ssoId,
                        'agentId': FS_SSO_SUPPORT_CONSTANTS.agentId,
                        'Client-Correlation-Id':this.correlationID
                    }
                }).then(response => {
                    this.digitalProfileInformations[index].lockStatuses.map((status) => {
                        status.lockStatus = 'UNLOCKED';
                        status.status = true;
                    });
                    return response;
                }, error => {
                    var errorID = " With Error Id :" + error.data.id;
                    var message = error.data.text + errorID;
                    Flash.create('danger', message);
                    return error;
                });
            }


            updateEmail(profile, profileIndex) {
                Flash.clear();
                cofModal({
                    icon: '/core/assets/images/edit-07.svg',
                    overrideButtons: true,
                    template: '<update-email></update-email>'
                }).then(newEmailAddress => {
                    this.submitEmailUpdate(profile, newEmailAddress);
                }, error => {

                });
            }

            submitEmailUpdate(profile, newEmailAddress) {
                return $http({
                    method: 'PUT',
                    url: FS_SSO_SUPPORT_CONSTANTS.modifyEmailURL,
                    data: '',
                    headers: {
                        'ssoId': profile.ssoId,
                        'contactPointId': profile.contactPointId,
                        'emailAddress': newEmailAddress,
                        'Client-Correlation-Id':this.correlationID

                    }
                }).then(response => {

                    profile.email = newEmailAddress;
                    return response;
                }, error => {

                    Flash.create('danger', error.data.text);
                    return error;
                });
            }
        }
        ;

        return Account;
    }
}(window.angular));