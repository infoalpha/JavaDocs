(function (angular) {
    'use strict';

    angular.module('saturnHeader', []);

}(window.angular));