(function (angular) {
    'use strict';

    angular
        .module('saturnHeader')
        .directive('saturnHeader', saturnHeader);

    saturnHeader.$inject = ['$state'];

    function saturnHeader($state) {
        /** The linking function */
        function saturnHeaderLink(scope, element, attributes) {

        }

        /** @type {Object} - The directive definition object */
        var directiveDefinitionObject = {
            link: saturnHeaderLink,
            restrict: 'AE',
            scope: {},
            templateUrl: '/saturnHeader/partials/saturnHeader.directive.html'
        };

        /** Return the directive */
        return directiveDefinitionObject;
    }
}(window.angular));