/**
 * Top level route config
 */
(function (angular) {
    'use strict';

    angular
        .module('fs-sso-support-ui')
        .factory('spinnerInterceptor', spinnerInterceptor);

    spinnerInterceptor.$inject = ['$q', 'spinner'];
    function spinnerInterceptor($q, spinner) {
        var interceptor = {},
            counter = 0;

        interceptor.request = function(request) {
            counter += 1;
            spinner.showSpinner();
            return request;
        };


        interceptor.response = function(response) {
            counter -= 1;
            counter <= 0 ? spinner.hideSpinner() : null;
            return response;
        };


        interceptor.responseError = function(response) {
            counter -= 1;
            counter === 0 ? spinner.hideSpinner() : null;
            return $q.reject(response);
        };

        return interceptor;
    }
}(window.angular));
