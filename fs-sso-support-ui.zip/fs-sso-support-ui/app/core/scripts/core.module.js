/**
 * App level module / Angular Bootstrap
 */
(function () {
  	'use strict';

    angular
        .module('fs-sso-support-ui.core', ['ngSanitize']);
})();