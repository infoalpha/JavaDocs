(function () {
    'use strict';

    angular
        .module('fs-sso-support-ui')
        .factory('unAuthorizedInterceptor', unAuthorizedInterceptor);

    unAuthorizedInterceptor.$inject = ['$q', '$location', '$window'];

    function unAuthorizedInterceptor($q, $location, $window) {
        var service = {
            responseError: responseError
        };
        function responseError(error) {

            if (error.status === 307 && error.data.id == 200008) {
                var redirectUrl = error.data.developerText;
                var currentUrl = $location.absUrl();
                $window.location.href = redirectUrl + currentUrl;
            }else{
                return $q.reject(error);
            }


        };

        return service;
    }

})();
