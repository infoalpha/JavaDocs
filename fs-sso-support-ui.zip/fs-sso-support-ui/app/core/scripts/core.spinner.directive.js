/**
 * Top level route config
 */
(function (angular) {

    'use strict';
    angular
        .module('fs-sso-support-ui')
        .service('spinner', spinner);

    spinner.$inject = [];
    function spinner() {
        var body = angular.element(document.querySelector('body')),
            spinner = angular.element('<div/>')
                .addClass('saturn-spinner');

        this.showSpinner = function () {
            body.append(spinner);
        };

        this.hideSpinner = function () {
            angular.element(document.querySelector('.saturn-spinner')).remove();
        };
    }
}(window.angular));


