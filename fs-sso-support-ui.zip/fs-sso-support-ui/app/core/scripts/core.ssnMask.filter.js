/**
 * Top level route config
 */
(function (angular) {

    'use strict';

    angular
        .module('fs-sso-support-ui')
        .filter('SSNMASK', SSNMASK);

    SSNMASK.$inject = ['$filter'];

    function SSNMASK($filter) {
        return function (inputSSN) {
            var outSSN = ' *** ** ' + inputSSN.substr(5, 9);
            return outSSN;

        };
    }

}(window.angular));



