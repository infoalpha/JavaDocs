/**
 * Top level route config
 */
(function() {
	angular
		.module('fs-sso-support-ui.core')
		.config(config);

	config.$inject = ["$urlRouterProvider"];
	function config($urlRouterProvider) {
		// for all unmatched routes
    $urlRouterProvider.otherwise("/");
  }
})();
