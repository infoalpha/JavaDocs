(function (angular) {
    'use strict';

    angular
        .module('fs-sso-support-ui')
        .directive('saturnNav', saturnNav);

    saturnNav.$inject = ['accountFactory'];
    function saturnNav(accountFactory) {
        /** Linking function */
        function saturnNavLink(scope, element, attributes) {
            scope.accounts = accountFactory;
        }

        /** Directive definition object */
        var saturnNavDirective = {
            link: saturnNavLink,
            restrict: 'AE',
            scope: {
                filterTemp: "@"
            },
            templateUrl: '/saturnNav/partials/saturnNav.html'
        };

        /** Return the directive definition object */
        return saturnNavDirective;
    }
}(window.angular));