(function () {
    'use strict';

    angular
        .module('auth')
        .factory('authService', authService);

    authService.$inject = ['$http','$q','FS_SSO_SUPPORT_CONSTANTS'];

    var config = {
        headers : {
            'Cache-Control': 'no-cache',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
    };

    function authService($http,$q,FS_SSO_SUPPORT_CONSTANTS) {


        return {
            authenticate: function () {
                return $http({
                    method: 'POST',
                    url: FS_SSO_SUPPORT_CONSTANTS.authURL,
                    headers:{
                        'Cache-Control': 'no-cache',
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then (response => {
                    return response;
                } ,error => {
                    return $q.reject(error);
                });
            }


        };


    }
})();