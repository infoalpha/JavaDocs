
(function () {
    'use strict';

    angular
        .module('auth')
        .controller('authController', authController);

    authController.$inject = ['$state', 'authService', '$scope'];

    function authController($state, authService, $scope) {

        var vm = this;
        authService.authenticate().then (response => {
            $state.go('fsSsoSupport.search');
        } ,error => {

            $state.go('fsSsoSupport.unAuthorized');
        });


    }
})();
