(function (angular) {
    'use strict';

    angular
        .module('fs-sso-support-ui')
        .config(appRoutes)

    appRoutes.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider','$locationProvider'];


    function appRoutes($stateProvider, $urlRouterProvider, $httpProvider,$locationProvider) {



        $httpProvider.interceptors.push('spinnerInterceptor');
        $httpProvider.interceptors.push('unAuthorizedInterceptor');


        $stateProvider
            .state('fsSsoSupport', {
                url: '/',
                templateUrl: 'search/partials/global.html',
                controller: 'MainController',
                controllerAs: 'Main',
                abstract: true
            }).state('fsSsoSupport.unAuthorized', {
                url: 'unauthorized',
                templateUrl: 'auth/partials/unauthorized.html',
                controller: "authController",
                controllerAs: 'authenticate'

            })
            .state('fsSsoSupport.search', {
               // url: "search",
                templateUrl: "search/partials/home.html",
                controller: "SearchController",
                controllerAs: 'Search'
            })
            .state('fsSsoSupport.account', {
                url: 'account',
                templateUrl: 'account/partials/ecrData.html',
                controller: 'accountController',
                controllerAs: 'accountCtrl',
                data: {
                    pageTitle: 'account Result'
                },
            })
            .state('fsSsoSupport.auth', {
                url: "auth",
                controller: "authController",
                controllerAs: 'authenticate'
            });


        $urlRouterProvider.otherwise('/auth');

    }

}(window.angular));