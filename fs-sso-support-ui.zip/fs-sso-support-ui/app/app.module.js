// The main app module declaration.
// This file should declare the app module and its dependencies and nothing else.
//

(function (angular) {

    'use strict';

    angular
        .module('fs-sso-support-ui', [
            'ui.router',
            'ngMessages',
            'cof.modal',
            'fs-sso-support-ui.core',
            'auth',
            'search',
            'account',
            'saturnHeader',
            'ngFlash',
            'oneui-tooltips'
        ]);

}(window.angular));
