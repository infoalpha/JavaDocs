(function (angular) {
    'use strict';

    angular
        .module('cof.modal', ['ngSanitize']);
}(window.angular));