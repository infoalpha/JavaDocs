(function (angular) {
    'use strict';

    angular
        .module('cof.modal')
        .provider('cofModal', cofModalProvider);

    cofModalProvider.$inject = [];
    function cofModalProvider() {
        var toElement;
        this.setEl = function (element) {
            toElement = element;
        };

        this.$get = ['$compile', '$q', '$rootScope', 'cofModalResolve', function ($compile, $q, $rootScope, cofModalResolve) {
            return function (config, injectedData) {
                var template = config.template,
                    buttonText = config.buttonText || 'Done',
                    modalClass = config.modalClass,
                    topMessage = config.topMessage,
                    overrideButtons = config.overrideButtons,
                    confirmationModal = config.confirmationModal,
                    buttonClass = config.buttonClass,
                    iconUrl = config.icon,
                    injectedData = injectedData || {},
                    deferred = $q.defer();

                var modal = angular.element('<cof-modal/>');
                modal.attr('button-class', buttonClass);
                modal.attr('button-text', buttonText);
                modal.attr('confirmation-modal', confirmationModal);
                modal.attr('modal-class', modalClass);
                modal.attr('top-message', topMessage);
                modal.attr('override-buttons', overrideButtons);
                modal.attr('icon', iconUrl);
                modal.attr('aria-live', 'assertive');
                modal.attr('role', 'dialog');
                modal.attr('tabindex', 0);
                modal.append(template);
                ;

                cofModalResolve.set(injectedData);
                $compile(modal)($rootScope);

                angular.element(document.querySelector(toElement || 'body')).append(modal);

                $rootScope.$on('cofModalDestroy', function (event, scope, destroyedModal) {
                    if (scope) {
                        deferred.resolve(scope);
                    } else if (destroyedModal) {
                        deferred.resolve(destroyedModal);
                    } else {
                        deferred.reject({
                            message: 'Modal closed'
                        });
                    }
                });

                return deferred.promise;
            };
        }];
    }
}(window.angular));