!(function (angular) {
    'use strict';

    angular.module('cof.modal')
        .directive('cofModal', [function () {
            /** Modal controller */
            var cofModalController = ['$element', '$injector', 'cofModalResolve', function ($element, $injector, cofModalResolve) {
                var $q = $injector.get('$q'),
                    $rootScope = $injector.get('$rootScope'),
                    $sce = $injector.get('$sce'),
                    focused = document.activeElement;

                $element[0].focus();

                this.injectedData = cofModalResolve.get();
                this.icon ? this.icon = $sce.trustAsResourceUrl(this.icon) : null;

                this.done = function (data) {
                    var transcluded;
                    $element.find('ng-transclude').length ? transcluded = $element.find('ng-transclude') : transcluded = $element.find('data-ng-transclude');
                    transcluded = angular.element(transcluded.contents()[0]);
                    data = data || transcluded.isolateScope();
                    $rootScope.$broadcast('cofModalDestroy', data, this);
                    focused.focus();
                    $element.remove();
                    cofModalResolve.clear();
                };

                this.close = function () {
                    $rootScope.$broadcast('cofModalDestroy', false);
                    cofModalResolve.clear();
                    focused.focus();
                    $element.remove();
                };

                this.confirm = function (status) {
                    this.confirmation = status;
                    this.done();
                };

                $rootScope.$on("destroyModalEvent", function () {
                    this.done();
                }.bind(this));
            }];

            /** Directive definition object */
            var cofModal = {
                bindToController: true,
                controller: cofModalController,
                controllerAs: 'modal',
                restrict: 'AE',
                scope: {
                    buttonClass: '@',
                    buttonText: '@',
                    confirmationModal: '=',
                    modalClass: '@',
                    overrideButtons: '=',
                    topMessage: '@',
                    icon: '@'
                },
                templateUrl: '/cofModal/partials/cof-modal.html',
                transclude: true
            };

            /** Return the directive object */
            return cofModal;
        }]);
}(window.angular));
