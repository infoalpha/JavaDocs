(function (angular) {
    'use strict';

    angular
        .module('cof.modal')
        .service('cofModalResolve', cofModalResolve);

    cofModalResolve.$injector = [];
    function cofModalResolve() {
        var dataStore;

        this.set = function (data) {
            dataStore = data;
        };

        this.get = function () {
            return dataStore;
        };

        this.clear = function () {
            dataStore = undefined;
        };

    }
}(window.angular));