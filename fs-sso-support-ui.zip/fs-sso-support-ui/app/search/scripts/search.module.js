//  Example feature module declaration
//

(function () {

    'use strict';

    angular
        .module('search', []);

})();