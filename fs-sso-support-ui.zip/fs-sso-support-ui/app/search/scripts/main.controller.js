(function (angular) {
    'use strict';

    angular
        .module('fs-sso-support-ui')
        .controller('MainController', mainController);

    mainController.$inject = [];
    function mainController() {

    }
}(window.angular));