/**
 * Angular Controller Example
 *
 * Use controllers to:
 *    - set the initial state of views
 *    - modify or add to views in response to events
 */
(function () {
    'use strict';

    angular
        .module('search')
        .controller('SearchController', searchController);

    searchController.$inject = ['$state', 'accountFactory', '$scope'];

    function searchController($state, accountFactory, $scope) {

        var vm = this;
        accountFactory.clear();
        vm.onSubmit = onSubmit;

        $scope.filterValue = function ($event) {
            $scope.submitted = false;
            if ($event.charCode === 0) {
                return;
            }
            else if ($event.charCode < 48 || $event.charCode > 57) {
                $event.preventDefault();
                return;
            } else {
                return;
            }
        };


        function onSubmit() {

            $scope.submitted = true;
            if ($scope.searchForm.ssn.$valid) {

                accountFactory.add(vm.ssn).then(function (success) {
                    success ? $state.go('fsSsoSupport.account') : null;
                });
            }

        }
    }
})();
