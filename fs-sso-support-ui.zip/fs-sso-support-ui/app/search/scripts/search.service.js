(function () {
    'use strict';

    angular
        .module('search')
        .factory('searchService', searchService);

    searchService.$inject = ['$http','$q', 'FS_SSO_SUPPORT_CONSTANTS','Flash'];

    var config = {
        headers : {
            'Cache-Control': 'no-cache',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
    };

    function searchService($http, $q, FS_SSO_SUPPORT_CONSTANTS,Flash) {


        return {
            getContactPointDetails: function (model) {
                return $http({
                    method: 'POST',
                    url: FS_SSO_SUPPORT_CONSTANTS.searchURL,
                    data:model,
                    headers:{
                        'Cache-Control': 'no-cache',
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then (response => {
                    return response;
                } ,error => {
                    return $q.reject(error);
                });
            }


        };


    }
})();