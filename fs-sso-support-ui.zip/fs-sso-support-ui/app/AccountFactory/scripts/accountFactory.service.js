(function(angular) {
    'use strict';

    angular
        .module('fs-sso-support-ui')
        .factory('accountFactory', accountFactory);

    accountFactory.$inject = ['$state', 'AccountService', 'cofModal', 'cofModalResolve', 'searchService'];
    function accountFactory($state, Account, cofModal, cofModalResolve, searchService) {
        var account 	= {},
            accounts 	= {};

        account.accounts = {};

        account.setActive = function(key) {
            this.active = key;
        };

        account.add = function(key) {
            return searchService.getContactPointDetails(key).then(function(response) {
                if (response.data.applicantDataList==null || !response.data.applicantDataList.length) {
                    cofModal({
                        template: '<p style="text-align:center">OPUS DATA NOT FOUND</p>'
                    }).then(function(data) {
                        // Whatever
                    })
                } else {
                    this.setActive(key);
                    accounts[key] = new Account(response.data);
                    return true;
                }
            }.bind(this), reject => {
                cofModal({
                    template: `<p style="text-align:center">${reject.data.text}</p>`
                }, reject.data.text).then(function(data) {
                    // Whatever
                });
            });
        };

        account.remove = function(key) {
            if (key === this.active) {
                cofModal('<div/>hello</div>').then(scope => {
                    delete accounts[key];
                    Object.keys(accounts).length ? null : $state.go('fsSsoSupport.search');
                }, reject => {

                });
            } else {
                delete accounts[key];
            }
        };

        account.clear = function(){
            accounts 	= {};
        };

        account.get = function(key) {
            return key ? accounts[key] : accounts;
        };

        account.getActive = function() {
            return accounts[this.active];
        };

        return account;
    }
}(window.angular));