/**
 *
 *
 * Use this service to declare all Application wide constants
 *
 */
(function (angular) {
    'use strict';

    angular
        .module('fs-sso-support-ui')
        .constant('FS_SSO_SUPPORT_CONSTANTS', {
            rootURL: '/fs-sso-support-ui',
            searchURL: '/fs-sso-support-app-web/support/search',
            modifyEmailURL: '/fs-sso-support-app-web/support/modifyEmail',
            updateLockStatusURL: '/fs-sso-support-app-web/support/updateLockStatus',
            unLockAllURL: '/fs-sso-support-app-web/support/unLockAll',
            authURL:'/fs-sso-support-app-web/support/auth',
            agentId: 'XMK762',
            unlocked: 'UNLOCKED',
            locked: 'LOCKED',
            unlock: 'UNLOCK',
            lock: 'LOCK',
            fraud: 'FRAUD',
            customer: 'CUSTOMER',
            profile: 'PROFILE',
            userFraudLockValidationMessage: "As User is Fraud Locked This operation cannot be performed. Please Unlock Fraud User"

        });
}(window.angular));