(function (angular) {
    'use strict';

    angular
        .module('fs-sso-support-ui')
        .directive('updateEmail', updateEmail);

    updateEmail.$inject = [];
    function updateEmail() {
        /** Linking function */
        function updateEmailLink(scope, element, attributes, modalController) {
            scope.confirm = function () {
                if (scope.updateEmail.$valid && scope.newEmail === scope.confirmNewEmail) {
                    modalController.done(scope.newEmail);
                } else if (scope.newEmail != scope.confirmNewEmail) {
                    scope.errorMessage = 'Please make sure the email addresses match';
                } else {
                    scope.errorMessage = 'Please Enter Valid Email Address';
                }

            };

            scope.cancel = function () {
                modalController.close();
            };
        }

        /** Directive definition object */
        var updateEmailDirectiveDefinitionObject = {
            link: updateEmailLink,
            restrict: 'AE',
            require: '^cofModal',
            scope: {},
            templateUrl: '/UpdateEmail/partials/updateEmail.html'
        };

        /** Return the directive definition object */
        return updateEmailDirectiveDefinitionObject;
    }
}(window.angular));