const path = require("path");  
const express = require("express");  
const webpack = require("webpack");

process.env.ENV = 'production';
process.env.NODE_ENV = 'production';

const config = require("./webpack.config.js");

const app           = express(),  
      DIST_DIR      = path.join(__dirname, "dist"),
      HTML_FILE     = path.join(DIST_DIR, "index.html"),
      isProd        = process.env.ENV === "production",
      DEFAULT_PORT  = 8080,
      compiler      = webpack(config);

app.set("port", process.env.PORT || DEFAULT_PORT);

if (isProd) {  
    app.use(express.static(DIST_DIR));

    app.get("*", (req, res) => {
        res.sendFile(HTML_FILE);
    });
}

app.listen(app.get("port"));