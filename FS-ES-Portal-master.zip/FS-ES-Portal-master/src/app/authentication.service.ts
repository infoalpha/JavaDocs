import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Http, Headers } from '@angular/http';
import { ENV_VARS } from './environment';

import { AppState } from './app.service';

import { Observable, Observer } from 'rxjs';

@Injectable()
export class AuthGuard implements CanActivate {

    constructor(private appState: AppState, private router: Router, private http: Http) {

    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | boolean {

        const readCookie = function(name) {
            var nameEQ = name + "=";
            var ca = document.cookie.split(';');
            for(var i=0;i < ca.length;i++) {
                var c = ca[i];
                while (c.charAt(0)==' ') c = c.substring(1,c.length);
                if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
            }
            return null;
        }

        const maintainStateOnRefresh = () => {
            if(localStorage.getItem('FsEsPortalAppModule') && (Boolean(localStorage.getItem("SSORedirect")) 
                || (readCookie("SHTSP") && readCookie("SHTS")
                && readCookie("SHTSP") === state.url && Math.abs(new Date().getUTCSeconds() - parseInt(readCookie("SHTS"))) < 5 )))
            {
                this.appState.set('appModule', JSON.parse(localStorage.getItem('FsEsPortalAppModule')));
                localStorage.removeItem('FsEsPortalAppModule');
            }
            else {
                this.appState.set('appModule', void 0);
                localStorage.removeItem('FsEsPortalAppModule');
            }
            localStorage.removeItem("SSORedirect");
        }

        if(this.appState.get('currentUser') || ENV !== 'production') {
            maintainStateOnRefresh();
            return true;
        }
        else {
            return Observable.create((observer: Observer<boolean>) => {
                this.http.get(
                    ENV_VARS.baseAPIPath + '/getLoggedInUser',
                    { headers: new Headers(ENV_VARS.defaultHeaders), withCredentials: true }
                ).subscribe(
                    (response) => {
                        maintainStateOnRefresh();
                        let cookie = readCookie('SP_HTMLNCCPROD');
                        let today = new Date();
                        let newDate = new Date(today.getTime() + 13*60*60000);
                        let month = [
                            "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
                        ]
                        let stringifiedDate = newDate.getDate() + " " + month[newDate.getMonth()] + " " + newDate.getFullYear() + " " + (newDate.getHours() < 10 ? "0" : "") + newDate.getHours() + ":" + (newDate.getMinutes() < 10 ? "0" : "") + newDate.getMinutes() + ":00 GMT";
                        document.cookie = "SP_HTMLNCCPROD=" + cookie + ";domain=.capitalone.com;path=" + encodeURI('/') + ";expires=" + stringifiedDate + ";";
                        this.appState.set('currentUser', response.json());
                        observer.next(true);
                    },
                    (error) => {
                        ENV_VARS.ssoRedirectFn(error, ENV_VARS, this.router.url, this.appState)
                        observer.next(false);
                    }
                )
            });
        }
    }

}