import {
  ComponentRef,
  ComponentFactoryResolver,
  Injector,
  ViewContainerRef,
  ReflectiveInjector,
  ResolvedReflectiveProvider
} from '@angular/core';

export interface CreateComponentArgs {
  component: any;
  vcRef: ViewContainerRef;
  injector?: Injector;
  bindings?: ResolvedReflectiveProvider[];
  projectableNodes?: any[][];
}

export function createComponent(args: CreateComponentArgs): ComponentRef<any> {
  let injector: Injector = getInjector(args);
  return args.vcRef.createComponent(
    injector.get(ComponentFactoryResolver).resolveComponentFactory(args.component),
    args.vcRef.length,
    injector,
    args.projectableNodes
  );
}

function getInjector(args: CreateComponentArgs) {
  const ctxInjector = args.injector || args.vcRef.parentInjector;
  return Array.isArray(args.bindings) && args.bindings.length > 0 ?
    ReflectiveInjector.fromResolvedProviders(args.bindings, ctxInjector) : ctxInjector;

}