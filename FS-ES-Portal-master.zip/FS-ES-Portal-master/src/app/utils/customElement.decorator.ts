export function CustomElement(name: string)  {
    return function(target: any) {
        (<any>window).customElements.define(name, target);
    }
}