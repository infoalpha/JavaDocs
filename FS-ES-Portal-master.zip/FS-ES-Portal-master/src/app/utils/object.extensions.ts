export {}

declare global {
    interface Object {
        mergeDeep(target: any, ...sources: Array<any>): any;
    }
}

Object.mergeDeep = function(target, ...sources: Array<any>) {
  if (!sources.length) return target;
  const source = sources.shift();

  if (typeof target === 'object' && typeof source === 'object') {
    for (const key in source) {
      if (typeof source[key] === 'object') {
        if (!target[key]) Object.assign(target, { [key]: {} });
        Object.mergeDeep(target[key], source[key]);
      } else {
        Object.assign(target, { [key]: source[key] });
      }
    }
  }

  return Object.mergeDeep(target, ...sources);
}