export {}

declare global {
    interface Array<T> {
        getItem(query: any, returnIndex?: boolean): T | number;
        removeItem(query: any, removeByDelete?: boolean): void;
        addPropertyFilter(property: string | Array<string>, value: any, include?: boolean, exact?: boolean, removeFirstMatch?: boolean): number;
        removePropertyFilter(property: string | Array<string> | number): void;
        sortByProperty(property: string | Array<string>, order?: string): void;
        removeSort(): void;
        createShadow(): void;
        restore(): void;
        subset(start: number, count: number): void;
        removeSubset(): void;

        readonly _shadow: Array<any>;
        readonly _filteredResults: Array<any>;
        readonly _sortedResults: Array<any>;
        readonly _sortProperty: string;
        readonly _sortOrder: string;
        readonly _subset: Array<number>;
        readonly _filters: Array<any>;
        readonly _removedItems: Array<any>;
    }
}

// Array.prototype._shadow = [];
// Array.prototype._shadow._filters = void 0;
// Array.prototype._shadow._shadow = void 0;
// Array.prototype._filters = [];
// Array.prototype._filters._filters = void 0;
// Array.prototype._filters._shadow = void 0;

Array.prototype.getItem = function(query: any, returnIndex?: boolean) {
    if(typeof query !== 'object') {
        return void 0;
    }

    for(let i = 0; i < this.length; i++) {
        if(!this[i]) { continue; }
        let isItem = true;
        const keys = Object.keys(query);
        for(let j = 0; j < keys.length; j++) {
            let key = keys[j];
            isItem = isItem && this[i][key] === query[key];
            if(!isItem) { break; }
        }
        if(isItem) {
            if(returnIndex)
                return i;
            else
                return this[i];
        }
    }
}

Array.prototype.removeItem = function(query, removeByDelete?: boolean) {
    if(typeof query === 'number' && query < this.length) {
        this.splice(query, 1);
    }
    else if(typeof query === 'object') {
        for(let i = 0; i < this.length; i++) {
            let remove = true;
            const keys = Object.keys(query);
            for(let j = 0; j < keys.length; j++) {
                let key = keys[j];
                remove = remove && this[i][key] === query[key];
                if(!remove) { break; }
            }
            if(remove) {
                if(removeByDelete)
                    delete this[i];
                else
                    this.splice(i, 1);
            }
        }
    }
    else if(Array.isArray(query)) {
        for(let i = 0; i < query.length; i++) {
            this.removeItem(query[i]);
        }
    }
}

Array.prototype.addPropertyFilter = function(property: string | Array<string>, value: any, include?: boolean, exact?: boolean, removeFirstMatch?: boolean) {
    if(!this._filteredResults) {
        this._filteredResults = this._shadow.slice(0);
    }

    if(!this._filters || !this._filters.length) {
        this._filters = [];
    }

    let preparedValue = typeof value === 'string' ? value.trim().toLowerCase() : value;

    let hashProperty = "";
    if(Array.isArray(property))
        property.forEach(val => hashProperty += val);
    else
        hashProperty = property

    let filterHash = hashProperty + value;

    let saveValue = {
        id: filterHash.hashCode(),
        property: property,
        displayValue: typeof value === 'string' ? value.trim() : value,
        value: preparedValue,
        include: (include === true || typeof include === 'undefined' ? true : false),
        exact: exact === true || false,
        removeFirstMatch: removeFirstMatch || false
    }

    this._filters.push(saveValue);
    applyFilters.apply(this);

    return saveValue.id;
}

Array.prototype.removePropertyFilter = function(property: string | Array<string> | number) {
    if(!this._filters || !this._filteredResults) {
        applyFilters.apply(this);
        return;
    }

    for(let i = 0; i < this._filters.length; i++) {
        if(typeof property === 'number' && this._filters[i].id === property) {
            this._filters.splice(i, 1);
            break;
        }
        else if(this._filters[i].property === property) {
            this._filters.splice(i, 1);
            i--;
        }
    }
    if(!this._filters.length) {
        delete this._filteredResults;
        delete this._filters;
    }
    else {
        this._filteredResults = this._shadow.slice(0);
    }

    applyFilters.apply(this);
}

Array.prototype.sortByProperty = function(property: string | Array<string>, order?: string) {
    if(typeof order === 'string') { order = order.toUpperCase(); }
    else { order = 'ASC'; }

    if(order === 'DESC' || order === 'DSC' || order === 'DESCENDING') {
        this._sortOrder = 'DESC';
    }
    else {
        this._sortOrder = 'ASC';
    }
    this._sortProperty = property;

    applySorting.apply(this);
}

Array.prototype.removeSort = function() {
    if(this._sortedResults) {
        delete this._sortProperty;
        delete this._sortOrder;
        delete this._sortedResults;
    }
    applySorting.apply(this);
}

Array.prototype.createShadow = function() {
    if(!this._shadow)
        this._shadow = this.slice(0);
}

Array.prototype.restore = function() {
    if(!this._shadow)
        return;

    delete this._shadow;

    if(this._filteredResults) {
        this._filters = [];
        delete this._filteredResults;
    }

    if(this._sortedResults) {
        delete this._sortProperty;
        delete this._sortOrder;
        delete this._sortedResults;
    }

    this.splice(0, this.length, ...this._shadow.slice(0));
}

Array.prototype.subset = function(start, count) {
    if(!this._shadow)
        return;

    applySubset.apply(this);
}

Array.prototype.removeSubset = function() {
    this._subset = void 0;
}

function applyFilters() {
    if(this._filteredResults && this._filters && this._filters.length) {
        for(let i = 0; i < this._filteredResults.length; i++) {
            this._filters.forEach((f) => { filter.bind(this)(f); })
        }
    }
    applySorting.apply(this);
}

function applySorting() {
    if(this._sortProperty) {
        this._sortedResults = (this._filteredResults || this._shadow).slice(0);
        this._sortedResults.sort((a, b) => {
            let tA = a, tB = b;
            if(Array.isArray(this._sortProperty)) {
                for(let i = 0; i < this._sortProperty.length; i++) {
                    tA = tA[this._sortProperty[i]];
                    tB = tB[this._sortProperty[i]];
                }
            }
            else {
                tA = a[this._sortProperty];
                tB = b[this._sortProperty];
            }
            if(typeof tA === 'undefined' || tA === null || (typeof tA === 'string' && !tA.trim().length)){
                return 1;
            }
            else if(typeof tB === 'undefined' || tB === null || (typeof tB === 'string' && !tB.trim().length)){
                return -1;
            }
            if(typeof tA !== typeof tB) {
                tA = tA.toString();
                tB = tB.toString();
            }
            if(typeof tA === 'string') {
                tA = tA.toLowerCase();
                tB = tB.toLowerCase();
            }
            if(tA > tB){
                return (this._sortOrder === 'DESC' ? -1 : 1);
            }
            else if(tA < tB){
                return (this._sortOrder === 'DESC' ? 1 : -1);
            }
            
            return 0;
        })
    }
    applySubset.apply(this);
}

function applySubset() {
    let start, end;
    if(this._subset) {
        start = this._subset[0];
        end = this._subset[1];
    }
    else {
        start = 0;
        end = void 0;
    }
    this.splice(0, this.length, ...(this._sortedResults || this._filteredResults || this._shadow).slice(start, end))
}

function filter(filter) {
    for(let i = 0; i < this._filteredResults.length; i++) {
        let itemProperty = this._filteredResults[i];
        if(Array.isArray(filter.property)) {
            filter.property.forEach(p => { itemProperty = itemProperty[p]; })
        }
        else if(typeof filter.property === 'string') {
            itemProperty = itemProperty[filter.property];
        }
        if(filter.exact) {
            itemProperty === filter.value;
            continue;
        }
        if(typeof itemProperty !== 'string' && typeof itemProperty !== 'undefined') { itemProperty = itemProperty.toString(); }
        if((!(itemProperty && itemProperty.toLowerCase().includes(filter.value)) && filter.include) || 
            (itemProperty && itemProperty.toLowerCase().includes(filter.value) && !filter.include)) {
            this._filteredResults.splice(i, 1);
            i--;
            if(filter.removeFirstMatch) {
                break;
            }
        }
    }
}

function applySort() {
    
}