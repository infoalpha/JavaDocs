import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';
import { AppState } from '../app.service';

@Component({
  selector: 'accessmanagement',
  encapsulation: ViewEncapsulation.None,
  template: `
    <sub-menu>
      <ul>
        <li><a [routerLink]="['./roles']" [routerLinkActive]="['active']">Roles</a></li>
        <li><a [routerLink]="['./permissions']" [routerLinkActive]="['active']">Permissions</a></li>
        <li><a>Profiles</a></li>
      </ul>
    </sub-menu>
    <router-outlet></router-outlet>
  `,
  styleUrls: ['./accessmanagement.component.css']
})
export class AccessManagementComponent implements OnInit {

  constructor(
    public appState: AppState
  ) {
    
  }

  public ngOnInit() {
    const moduleId = "accessManagement";

    let appModule = this.appState.get('appModule');

    if(!appModule || (appModule && appModule.id !== moduleId)) {
      this.appState.set('appModule', { name: "Access Management", header: "Access Management", title: "Access Management", id: moduleId, data: {} });
    }
  }

}
