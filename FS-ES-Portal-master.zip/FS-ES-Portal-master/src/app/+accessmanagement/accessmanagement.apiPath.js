import { ENV_VARS } from '../environment';

export default ENV_VARS.baseAPIPath + "/access";