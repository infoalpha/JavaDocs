import { Component, Inject, ViewEncapsulation,ViewChild } from '@angular/core';
import { Http, Headers, RequestOptions, RequestMethod } from '@angular/http'
import { FormBuilder, FormGroup, FormControl, FormArray, Validators, AsyncValidatorFn } from '@angular/forms';
import { FsEsTable, FsEsTableRow } from '../../../components/table';
import { SidePane } from '../../../components/sidepane';
import { defaultHeaders } from '../../../resources';
import apiPath from '../../accessmanagement.apiPath.js';


@Component({
    selector: 'permission-create',
    template:`<permission-form headerText="Create Permissions" formSubmitText="Create" formMethod="POST"></permission-form>`
})
export class CreatePermissionComponent {
}

