import { Component, Input, Inject, OnInit, AfterViewInit, ViewEncapsulation, ViewChild, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, RequestMethod } from '@angular/http'
import { FormBuilder, FormGroup, FormControl, FormArray, Validators, AsyncValidatorFn } from '@angular/forms';
import { Router } from '@angular/router';
import { AppState } from '../../app.service';
import { FsEsTable, FsEsTableRow, manageSelection } from '../../components/table';
import { SidePane } from '../../components/sidepane';
import { defaultHeaders } from '../../resources';
import apiPath from '../accessmanagement.apiPath';
import { ENV_VARS } from '../../environment';


@Component({
    selector: 'permission-form',
    templateUrl: './permissions.formcomponent.html',
    encapsulation: ViewEncapsulation.None
})

export class PermissionsFormComponent implements OnInit, AfterViewInit{

    private api_path = apiPath + '/permissions' ;
    private formAction;
    private defaultNameValue;
    private appDisabled;

    @Input() headerText: string;
    @Input() formSubmitText: string;
    @Input() formMethod: string;
    @Input() permission: any;

    formHeaders: Headers;

    form: FormGroup;
    isVirtualControl: FormControl;
    isReadControl: FormControl;
    isAddControl: FormControl;
    isUpdateControl: FormControl;
    isDeleteControl: FormControl;
    permNameControl: FormControl;
    permDescControl: FormControl;
    rolesControl: FormControl;
    risksControl: FormControl;
    appControl: FormControl;
    taskControl: FormControl;

    availableRoles: Array<any>;
    availableRisks: Array<any>;
    roles: Array<any> = [];
    risks: Array<any> = [];
    apps: Array<any>;
    tasks: Array<any> = [];
 

    @ViewChild('availableRolesTable') availableRolesTable: FsEsTable;
    @ViewChild('selectedRolesTable') selectedRolesTable: FsEsTable;
    @ViewChild('availableRisksTable') availableRisksTable: FsEsTable;
    @ViewChild('selectedRisksTable') selectedRisksTable: FsEsTable;
    @ViewChild(SidePane) _sidePane: SidePane;

    constructor(private http: Http, @Inject(FormBuilder) fb: FormBuilder, private appState: AppState, private zone: NgZone, private router: Router) {
       
        this.formHeaders = new Headers(defaultHeaders);

        this.isVirtualControl = new FormControl(false);
        this.isReadControl = new FormControl(false);
        this.isAddControl = new FormControl(false);
        this.isUpdateControl = new FormControl(false);
        this.isDeleteControl = new FormControl(false);
        this.checkNameAsync = this.checkNameAsync.bind(this);
        this.permNameControl = new FormControl('', [ Validators.required, Validators.maxLength(100) ], this.checkNameAsync);
        this.permDescControl = new FormControl('', [ Validators.required, Validators.maxLength(300) ]);
        this.rolesControl = new FormControl([]);
        this.risksControl = new FormControl([]);
        this.appControl=new FormControl(appState.get(['appModule','data','selectedApplicationId']), Validators.required);
        this.taskControl = new FormControl('');
        
        this.form=fb.group({
            permName: this.permNameControl,
            permDesc: this.permDescControl,
            application: fb.group({ 
                applicationId: this.appControl
            }),
            isVirtual: this.isVirtualControl,
            permissionLevels: fb.array([]),
            roles: this.rolesControl,
            risks: this.risksControl,
            task: fb.group({
                taskId: this.taskControl
            })
        })
 
        this.apps = [];
        this.availableRoles = [];
        this.availableRisks = [];
        this.roles = [];
        this.risks = [];
   }

   ngOnInit() {
        this.formAction = this.permission && this.formMethod.toUpperCase() === "PUT" ? this.api_path + '/' + this.permission.permId : this.api_path;
        this.isReadControl.valueChanges.subscribe(data => this.handlePermissionLevelChange(data, this.isReadControl));
        this.isAddControl.valueChanges.subscribe(data => this.handlePermissionLevelChange(data, this.isAddControl));
        this.isUpdateControl.valueChanges.subscribe(data => this.handlePermissionLevelChange(data, this.isUpdateControl));
        this.isDeleteControl.valueChanges.subscribe(data => this.handlePermissionLevelChange(data, this.isDeleteControl));

        this.appDisabled = false;

        if(this.permission) {
            this.appDisabled=true;
            this.permNameControl.setValue(this.permission.permName);
            this.permNameControl.markAsPristine();
            this.permNameControl.markAsUntouched();
            this.permDescControl.setValue(this.permission.permDesc);
            this.permDescControl.markAsPristine();
            this.permDescControl.markAsUntouched();
            this.taskControl.setValue(this.permission.task ? this.permission.task.taskId : void 0);
            this.taskControl.markAsPristine();
            this.taskControl.markAsUntouched();
            this.appControl.setValue(this.permission.application.applicationId);
            this.isVirtualControl.setValue(this.permission.isVirtual);
            this.appControl.markAsPristine();
            this.appControl.markAsUntouched();
            this.roles = this.permission.roles;
            this.rolesControl.setValue(this.permission.roles);
            this.rolesControl.markAsPristine();
            this.rolesControl.markAsUntouched();
            this.risks = this.permission.risks;
            this.risksControl.setValue(this.permission.risks);
            this.risksControl.markAsPristine();
            this.risksControl.markAsUntouched();


            this.defaultNameValue = this.permission.permName;


            this.permission.permissionLevels.forEach((level) => {
        
                switch(level.permLevelId) {             
                    case 1:
                        this.isReadControl.setValue({ permLevelId: 1 });
                        this.isReadControl.markAsPristine();
                    break;

                    case 2:
                        this.isAddControl.setValue({permLevelId: 2});
                        this.isAddControl.markAsPristine();
                    break;

                    case 3:
                        this.isUpdateControl.setValue({permLevelId: 3});
                        this.isUpdateControl.markAsPristine();
                    break;

                    case 4:
                        this.isDeleteControl.setValue({permLevelId: 4});
                        this.isDeleteControl.markAsPristine();
                    break;
                }
            })      
        }

        this.loadTasks();

        if(this.appControl.value) {
            this.loadAvailableRoles(this.appControl.value);
        }

        this.http.get(apiPath + '/applications', { headers: this.formHeaders, withCredentials: true }).subscribe(
            (response) => {
                this.apps = (<Array<any>>response.json()).sort((a,b) => {
                    if(a.applicationName.toLowerCase() < b.applicationName.toLowerCase())
                        return -1;
                    else if(a.applicationName.toLowerCase() > b.applicationName.toLowerCase())
                        return 1;
                    
                    return 0;
                });
            },
            (error) => { ENV_VARS.ssoRedirectFn(error, ENV_VARS, this.router.url, this.appState); });

        this.loadAvailableRisks();
   }


    public loadRoles($event) {
        var id=$event.target.value;
        this.loadAvailableRoles(id);
    }

    public loadTasks() {
        var path = apiPath +  "/tasks";
        this.http.get(path, { headers: this.formHeaders, withCredentials: true }).subscribe(
            (response) => {
                this.tasks = response.json();
            },
            (error) => { ENV_VARS.ssoRedirectFn(error, ENV_VARS, this.router.url, this.appState); });
    }

    public loadAvailableRoles(id) {
        var path = apiPath +  "/roles/" + id + "/roles";
        this.http.get(path, { headers: this.formHeaders, withCredentials: true }).subscribe(
            (response) => {
                this.availableRoles = response.json();
                this.zone.runOutsideAngular(() => {
                    setTimeout(() => { 
                        this.zone.run(() => {
                            this.availableRolesTable.rows.filter((row) => { return typeof row.data !== 'undefined' }).forEach((row) => {
                                for(let i = 0; i < this.rolesControl.value.length; i++) {
                                    if(this.rolesControl.value[i].roleId === row.data.roleId) {
                                        row.selected = true;
                                        break;
                                    }
                                }
                            });
                            manageSelection(this.availableRolesTable, this.availableRoles, this.selectedRolesTable, this.roles, { identifier: "roleId", zone: this.zone })
                        });
                    }, 0);
                })
            },
            (error) => { ENV_VARS.ssoRedirectFn(error, ENV_VARS, this.router.url, this.appState); });
    }

    public loadAvailableRisks() {
        var path = apiPath +  "/risks";
    	this.http.get(path, { headers: this.formHeaders, withCredentials: true }).subscribe(
			(response) => {
				this.availableRisks = response.json();
                this.zone.runOutsideAngular(() => {
                    setTimeout(() => { 
                        this.zone.run(() => {
                            this.availableRisksTable.rows.filter((row) => { return typeof row.data !== 'undefined' }).forEach((row) => {
                                for(let i = 0; i < this.risksControl.value.length; i++) {
                                    if(this.risksControl.value[i].riskId === row.data.riskId) {
                                        row.selected = true;
                                        break;
                                    }
                                }
                            });
                            manageSelection(this.availableRisksTable, this.availableRisks, this.selectedRisksTable, this.risks, { identifier: "riskId", zone: this.zone })
                        });
                    }, 0);
                });
			},
            (error) => { ENV_VARS.ssoRedirectFn(error, ENV_VARS, this.router.url, this.appState); });
    }
     
    ngAfterViewInit() {
    }

    handlePermissionLevelChange(data, control: FormControl) {
        const arrayControl = <FormArray>this.form.controls['permissionLevels'];
        if(data) {
            arrayControl.push(control);
        }
        else {
            for(let i = 0; i < arrayControl.controls.length; i++) {
                if(arrayControl.controls[i] === control) {
                    arrayControl.removeAt(i);
                    i--;
                }
            }
        }
        console.log(arrayControl);
        control.markAsDirty();
    }

   checkNameAsync(control: FormControl): Promise<any> {
        return new Promise(resolve => {
            
            if(this.permNameControl.value.length === 0 || control.value.length === 0 || control.value===this.defaultNameValue) { resolve(null); return; }

            let headers = new Headers();
            headers.append('Content-Type', 'application/json');

            this.http.post(apiPath + '/permissions/exists', { application: { applicationId: this.appControl.value }, permName: this.permNameControl.value }, { headers: this.formHeaders, withCredentials: true })
                .toPromise()
                .then((data) => {
                    resolve(data.json().taken ? { taken: true } : null);
                })
                .catch((data) => {
                    resolve(null);
                })

        })
    }

    toggleSelectedEntity($event) {
        if($event.selected) {
            this.roles.push($event.data);
        }
        else {
            this.roles.removeItem({roleId:$event.data.roleId});
        }
    }

    toggleSelectedRiskEntity($event) {
        if($event.selected) {
            this.risks.push($event.data);
        }
        else {
            this.risks.removeItem({riskId:$event.data.riskId});
        }
    }

   deselectEntity($event) {
        if(!$event.selected) {
           this.roles.removeItem({roleId: $event.data.roleId });
           let rowData = this.availableRolesTable.rows.filter((row)=>{ return typeof row.data !=='undefined'; });
           rowData.forEach(function(a) { if(a.data.roleId === $event.data.roleId) { a.selected = false; } });
        }
   }

    deselectRiskEntity($event) {
        if(!$event.selected) {
           this.risks.removeItem({riskId: $event.data.riskId });
           let rowData = this.availableRisksTable.rows.filter((row)=>{ return typeof row.data !=='undefined'; });
           rowData.forEach(function(a) { if(a.data.riskId === $event.data.riskId) { a.selected = false; } });
        }
   }

    checkPermissionLevels($event) {
        for(let i = 0; i < this.form['permissionLevels'].length; i++) {
            if(!this.form['permissionLevels'][i]) {
                this.form['permissionLevels'].splice(i, 1);
                i--;
            }
        }

        return true;
    }
    
    createSuccess($event) {
        let res = $event.response.json();
        
        if(res.application.applicationId === this.appState.get(['appModule','data','selectedApplicationId'])) {
            res._highlighted = true;
            const allPermissions: Array<any> = this.appState.get(['appModule', 'data', 'permissions']);
            let thisPermissionIndex = allPermissions.getItem({ permId: parseInt(res.permId) }, true);
            let newPermission = Object.mergeDeep(allPermissions[thisPermissionIndex], res);
            if(typeof thisPermissionIndex === 'number') {               
                //this.appState.set(['appModule', 'data', 'permissions', thisPermissionIndex], newPermission);
            }
            else {              
                //this.appState.state.appModule.data.permissions.push(res)
            }
            var path = apiPath +  "/permissions/" + this.appState.get(['appModule','data','selectedApplicationId']) + "/permissions";
            this.http.get(path, { headers: this.formHeaders, withCredentials: true }).subscribe(
                (response) => {
                    let permissions = this.appState.get(['appModule', 'data', 'permissions'], false);
                    (<Array<any>>permissions).splice(0, permissions.length, ...response.json())
                },
                (error) => { ENV_VARS.ssoRedirectFn(error, ENV_VARS, this.router.url, this.appState); });
        }
        this._sidePane.closeSidePane();    
    }

    createFailure($event) {
        this._sidePane.closeSidePane();
    }

    handleCancelButtonClick($event) {
        $event.preventDefault();
        this._sidePane.closeSidePane();
    }
}
