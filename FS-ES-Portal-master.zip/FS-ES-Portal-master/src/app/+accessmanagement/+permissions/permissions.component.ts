import { Component, OnInit, OnDestroy, AfterViewInit, Inject, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router'
import { Http, Headers, RequestOptions, RequestMethod } from '@angular/http';
import { AppState } from '../../app.service';
import { defaultHeaders } from '../../resources';
import apiPath from '../accessmanagement.apiPath';
import { ENV_VARS } from '../../environment';

import { FsEsModal } from '../../components/modal';

@Component({
  selector: 'permissions-page',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './permissions.component.html',
  styleUrls: ['./permissions.component.css']
})
export class PermissionsComponent implements OnInit {
	apps: Array<any>;
	headers: Headers;
	permissions: Array<any> = [];
	applicationId: any;
	applicationSelected = false;

	constructor( private router: Router, private http: Http, private currentActivatedRoute: ActivatedRoute, private appState: AppState, private modal: FsEsModal ) {
		this.apps = [];

		this.headers = new Headers(defaultHeaders);

		if(this.appState.get(['appModule', 'data', 'permissions'])) {
			this.applicationId = this.appState.get(['appModule', 'data', 'selectedApplicationId']);
			this.appState.set(['appModule', 'data', 'permissions'], this.permissions);
			this.reloadData();
		}
		else {
			this.appState.set(['appModule', 'data', 'permissions'], this.permissions);
			this.appState.set(['appModule', 'data', 'selectedApplicationId'], null);
		}
	}

	public ngOnInit() {

		this.http.get(apiPath + "/applications", { headers: this.headers, withCredentials: true }).subscribe(
			(response) => {
				this.apps = response.json();
			},
			(error) => { ENV_VARS.ssoRedirectFn(error, ENV_VARS, this.router.url, this.appState); });
	}

	public loadData($event) {
		var id=$event.target.value;

		this.appState.set(['appModule','data','selectedApplicationId'], parseInt(id));
		this.applicationSelected = true;

		var path = apiPath +  "/permissions/" + id + "/permissions";

		this.http.get(path, { headers: this.headers, withCredentials: true }).subscribe(
			(response) => {
				this.permissions = response.json();
				this.appState.set(['appModule', 'data', 'permissions'], this.permissions);
			},
			(error) => { ENV_VARS.ssoRedirectFn(error, ENV_VARS, this.router.url, this.appState); });  
	}

  public reloadData() {
    var appId = this.appState.get(['appModule','data','selectedApplicationId']);
    if(appId)
      this.loadData({ target: { value: appId } });
  }

  deleteEntity(entityId) {

    const deleteErrorCallback = () => {
      this.modal.close();
      this.modal.data = {
        header: "Error: Delete Permission",
        body: "There was an error while trying to delete the selected Permission.",
        cancelText: "Okay"
      }
      this.modal.launch();
    }

    const deleteCallback = () => {
      this.http.delete(apiPath + "/permissions/" + entityId, { headers: this.headers, withCredentials: true }).subscribe(
        () => {
          this.modal.close();
          this.appState.get(['appModule', 'data', 'permissions'], false).removeItem({ permId: entityId });
          this.reloadData();
        },
        (error) => {
          ENV_VARS.ssoRedirectFn(error, ENV_VARS, this.router.url, this.appState);
          if(error.status !== 307) {
            deleteErrorCallback();
          }
        });
    };

    this.http.get(apiPath + "/permissions/" + entityId, { headers: new Headers(this.headers), withCredentials: true }).subscribe(
      (res) => {
        let rolesArray: Array<any> = res.json().roles;
        if(rolesArray.length) {
          let rolesListHTML = rolesArray.map((role) => { return `<li>` + role.roleName + `</li>`; }).join("");
          this.modal.data = {
            header: "Delete Permission",
            body: "There are Role relationships that will be removed if you delete this Permission. Are you sure you want to continue?",
            options: [
              {
                text: "Delete",
                click: deleteCallback,
                default: true
              },
              {
                text: "View Relationships",
                content: `
                  <ul class="modal-entity-list">` + rolesListHTML + `</ul>
                `
              }
            ]
          }
          this.modal.launch();
        }
        else {        
          this.modal.data = {
            header: "Delete Permission",
            body: "Are you sure you want to continue?",
            options: [
              {
                text: "Delete",
                click: deleteCallback,
                default: true
              }
              
            ]
          }
          this.modal.launch();
        }

      },
      (error) => {
          ENV_VARS.ssoRedirectFn(error, ENV_VARS, this.router.url, this.appState);
          if(error.status !== 307) {
              deleteErrorCallback();
          }
      });  
  }

	showLog($event,permission){
		$event.preventDefault();
		if($event.target.tagName.toUpperCase() === "A" ||($event.target.tagName.toUpperCase() === "SPAN" && $event.target.classList.contains("action"))){
			return;
		}
		else {
			let tableRow = $event.target.closest('fs-es-tr');
			tableRow.classList.add('active');
			this.appState.set(['appModule', 'data', 'activeRow'], tableRow);
			this.router.navigate(['accessmanagement/permissions/'+ permission.permId]);
		}
	}

	ngOnDestroy() {
		this.appState.set(['appModule','data','selectedApplicationId'], void 0);
		this.appState.set(['appModule','data','permissions'], void 0);
	}

}
