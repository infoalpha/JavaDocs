import { Component,  OnInit, ViewChild, OnDestroy} from '@angular/core';
import { DatePipe } from '@angular/common';
import { Router, ActivatedRoute, Params } from '@angular/router';
import apiPath from '../../accessmanagement.apiPath';
import { Http, Headers, RequestOptions, RequestMethod } from '@angular/http';
import { SidePane } from '../../../components/sidepane';
import { defaultHeaders } from '../../../resources';
import { AppState } from '../../../app.service';
import { ENV_VARS } from '../../../environment';

@Component({
    selector: 'permission-view',
    templateUrl: './viewpermission.component.html',
})
export class ViewPermissionComponent implements OnInit, OnDestroy {
    private headers: Headers;
    public permissionId: number;
    private permission: any;
    private headerText: string;
    private creatorName: string;
    private updatorName: string;
    private createdDate:string;
    private updatedDate:string;
    private datePipe = new DatePipe('en-US');
    private setCreateDate:string;
    private setUpdateDate:string;
    private selectedRow?: HTMLElement;


    @ViewChild(SidePane) _sidePane: SidePane;
    constructor(
        public route: ActivatedRoute, private router: Router, private http: Http, private appState: AppState
    ) {
        this.headers = new Headers(defaultHeaders);
        this.permissionId = +this.route.snapshot.params['id'];
    }

  ngOnInit() {
    this.selectedRow = this.appState.get(['appModule', 'data', 'activeRow'], false);
    if(this.selectedRow) {
      this.appState.set(['appModule', 'data', 'activeRow'], void 0);
    }
    this.http.get(apiPath + '/permissions/'+ this.permissionId, { headers: this.headers, withCredentials: true }).subscribe(
      (data) => {
        this.permission = data.json();
        this.headerText = "View Permission Log '" + this.permission.permName + "'";

        if(this.permission.creator && (this.permission.creator.firstName || this.permission.creator.lastName)) {
          this.creatorName = this.permission.creator.firstName + " " + this.permission.creator.lastName;
        }
        if(this.permission.updator && (this.permission.updator.firstName || this.permission.updator.lastName)) {
          this.updatorName = this.permission.updator.firstName + " " +this.permission.updator.lastName;
        }

        if(this.permission.createDate) {
          this.createdDate = this.datePipe.transform(this.permission.createDate.slice(0,10), 'shortDate');
        }
        if(this.permission.updateDate) {
          this.updatedDate = this.datePipe.transform(this.permission.updateDate.slice(0,10), 'shortDate');
        }
      },
      (error) => { ENV_VARS.ssoRedirectFn(error, ENV_VARS, this.router.url, this.appState) });
  }


  handleCancelButtonClick($event) {
    $event.preventDefault();
    this._sidePane.closeSidePane();
  }

  ngOnDestroy() {
    if(this.selectedRow) {
      this.selectedRow.classList.remove("active");
    }
  }
}

