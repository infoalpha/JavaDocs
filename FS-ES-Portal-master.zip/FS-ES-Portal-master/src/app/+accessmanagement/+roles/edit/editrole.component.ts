import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Http, Headers, RequestOptions, RequestMethod } from '@angular/http';
import { ENV_VARS } from '../../../environment';
import { defaultHeaders } from '../../../resources';
import { AppState } from '../../../app.service';
import apiPath from '../../accessmanagement.apiPath';

@Component({
    selector: 'role-edit',
    template: `<role-form  *ngIf="role" [headerText]="headerText" formSubmitText="Save" formMethod="PUT" [role]="role"></role-form>`
})
export class EditRoleComponent implements OnInit {
    
     private headers: Headers;

    public roleId: number;

    private role: any;

    private headerText: string;

    constructor(
        private router: Router, private route: ActivatedRoute, private http: Http, private appState: AppState
    ) {
         this.headers = new Headers(defaultHeaders);
         this.roleId = +this.route.snapshot.params['id'];
      }

      ngOnInit() {
        this.http.get(apiPath + '/roles/' + this.roleId, { headers: this.headers, withCredentials: true }).subscribe(
            (data) => {
                this.role = data.json();
                this.headerText = "Edit Roles '" + this.role.roleName + "'";
            },
            (error) => { ENV_VARS.ssoRedirectFn(error, ENV_VARS, this.router.url, this.appState) });
            // (error) => {
            //     let errorData = error.json();
            //     if (error.status === 307 && errorData.id == 200008) {
            //         var redirectUrl = errorData.developerText;
            //         var currentUrl = this.router.url;
            //         window.location.href =
            //             redirectUrl +
            //             encodeURIComponent(
            //                 ENV_VARS.ssoRedirectUri["TargetResource"] + 
            //                 this.router.url
            //             );
            //     }
            // });
    }
}