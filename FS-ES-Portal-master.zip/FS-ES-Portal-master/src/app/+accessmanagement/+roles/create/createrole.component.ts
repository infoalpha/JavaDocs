import { Component, Inject, AfterContentInit, ViewChild } from '@angular/core';
import { Http, Headers, RequestOptions, RequestMethod } from '@angular/http'
import { FormBuilder, FormGroup, FormControl, Validators, AsyncValidatorFn } from '@angular/forms';
import { FsEsTable, FsEsTableRow } from '../../../components/table';
import { SidePane } from '../../../components/sidepane';
import { defaultHeaders } from '../../../resources';
import apiPath from '../../accessmanagement.apiPath';


@Component({
    selector: 'role-create',
    template: `<role-form headerText="Create roles" formSubmitText="Create" formMethod="POST"></role-form>`
})
export class CreateRoleComponent {
}