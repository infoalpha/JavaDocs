import { Component, Input, Inject, OnInit, AfterContentInit, ViewEncapsulation, ViewChild, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, RequestMethod, URLSearchParams } from '@angular/http'
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormBuilder, FormGroup, FormControl, FormArray, Validators, AsyncValidatorFn } from '@angular/forms';
import { FsEsTable, FsEsTableRow, manageSelection } from '../../components/table';
import { AppState } from '../../app.service';
import { SidePane } from '../../components/sidepane';
import { defaultHeaders } from '../../resources';
import apiPath from '../accessmanagement.apiPath';
import { ENV_VARS } from '../../environment';

@Component({
    selector: 'role-form',
    templateUrl: './roles.formcomponent.html',
    encapsulation: ViewEncapsulation.None
})

export class RolesFormComponent implements OnInit, AfterContentInit {
 
    private api_path = apiPath + '/roles';
    private defaultNameValue;
    private formAction;
    private appEnabled;
    private roleId;

    @Input() headerText: string;
    @Input() formSubmitText: string;
    @Input() formMethod: string;
    @Input() role: any;

    formHeaders: Headers; 

    form: FormGroup;
    roleNameControl: FormControl;
    roleDescControl: FormControl;
    isVirtualControl: FormControl;
    accesstypesControl: FormControl;
    appControl: FormControl;

    apps: Array<any>;


    availableAccesstypes: Array<any> = [];
    accesstypes: Array<any> = [];

    @ViewChild('availableAccessTypesTable') availableAccessTypesTable: FsEsTable;
    @ViewChild('selectedAccessTypesTable') selectedAccessTypesTable: FsEsTable;
    @ViewChild(SidePane) _sidePane: SidePane;

    constructor(
        private http: Http,
        @Inject(FormBuilder) fb: FormBuilder,
        private appState: AppState,
        private router: Router,
        public route: ActivatedRoute,
        private zone: NgZone
    ) {

        this.formHeaders = new Headers(defaultHeaders);
        this.formAction = apiPath + "/roles";

        this.checkNameAsync = this.checkNameAsync.bind(this);
        this.roleNameControl = new FormControl('', [Validators.maxLength(100), Validators.required], this.checkNameAsync);
        this.roleDescControl = new FormControl('', [Validators.maxLength(300), Validators.required]);
        this.isVirtualControl = new FormControl('');
        this.accesstypesControl = new FormControl([]);
        this.appControl = new FormControl(appState.get(['appModule', 'data', 'selectedApplicationId']), Validators.required);
        this.form = fb.group({
            roleName: this.roleNameControl,
            roleDesc: this.roleDescControl,
            application: fb.group({
                applicationId: this.appControl
            }),
            isVirtual: this.isVirtualControl,
            accesstypes: this.accesstypesControl
        })

        this.apps = [];
        this.availableAccesstypes = [];
        this.accesstypes = [];
        this.roleId = +this.route.snapshot.params['id'];
        

    }

    ngOnInit() {
        this.formAction = this.role && this.formMethod.toUpperCase() === "PUT" ? this.api_path + '/' + this.role.roleId : this.api_path;
        this.appEnabled = false;  
        this. getApplicationList();

        if (this.role) {
            this.appEnabled = true;
            this.roleNameControl.setValue(this.role.roleName);
            this.roleNameControl.markAsPristine();
            this.roleNameControl.markAsUntouched();
            this.roleDescControl.setValue(this.role.roleDesc);
            this.roleDescControl.markAsPristine();
            this.roleDescControl.markAsUntouched();
            this.appControl.setValue(this.role.application.applicationId);
            this.isVirtualControl.setValue(this.role.isVirtual);
            this.appControl.markAsPristine();
            this.appControl.markAsUntouched();
            this.accesstypes=this.role.accesstypes;
            this.accesstypesControl.setValue(this.role.accesstypes)
            this.accesstypesControl.markAsPristine();
            this.accesstypesControl.markAsTouched();
            this.defaultNameValue = this.role.roleName;
        }

        if (this.appControl.value) {
            this.getAvailableAccessTypes(this.appControl.value);
        }
    }

    public loadAccessTypes($event){
        var id=$event.target.value;
        this.getAvailableAccessTypes(id);

    }

    public ngAfterContentInit() {
        this.http.get(apiPath + '/applications', { headers: this.formHeaders, withCredentials: true }).subscribe(
            (response) => {
                this.apps = response.json();
            },
            (error) => { ENV_VARS.ssoRedirectFn(error, ENV_VARS, this.router.url, this.appState); });

    }

    getAvailableAccessTypes(id) {

        let searchParams: URLSearchParams = new URLSearchParams();
        if(this.roleId) { searchParams.set('roleId', this.roleId); }

        let requestOptions = new RequestOptions();
        requestOptions.headers = this.formHeaders;
        requestOptions.withCredentials = true;
        requestOptions.search = searchParams;

        this.http.get(apiPath + "/applications/" + id + "/accesstypes", requestOptions).subscribe(
            (response) => {
                this.availableAccesstypes = response.json();
                this.zone.runOutsideAngular(() => {
                    setTimeout(() =>{
                        this.zone.run(() => {
                            this.availableAccessTypesTable.rows.filter((row) => {return typeof row.data !== 'undefined'}).forEach((row) => {
                                for(let i = 0; i < this.accesstypesControl.value.length; i++) {
                                    if(this.accesstypesControl.value[i].accessTypeId === row.data.accessTypeId) {
                                        row.selected =true;
                                        break;
                                    }
                                }
                            })
                            manageSelection(this.availableAccessTypesTable, this.availableAccesstypes, this.selectedAccessTypesTable, this.accesstypes, { identifier: "accessTypeId", zone: this.zone })
                        });
                    })
                });
            },
            (error) => { ENV_VARS.ssoRedirectFn(error, ENV_VARS, this.router.url, this.appState); });
    }

    checkNameAsync(control: FormControl): Promise<any> {
        return new Promise(resolve => {
            if (this.appControl.value.length === 0 || control.value.length === 0 || control.value===this.defaultNameValue) { resolve(null); return; }
            let headers = new Headers();
            headers.append('Content-Type', 'application/json');
            this.http.post(apiPath + '/roles/exists', { application: { applicationId: this.appControl.value }, roleName: control.value }, { headers: new Headers(defaultHeaders), withCredentials: true })
                .toPromise()
                .then((data) => {
                    resolve(data.json().taken ? { taken: true } : null)
                })
                .catch((response) => {
                    resolve(null);
                })

        })
    }

    addSelectedEntity($event) {
        if ($event.selected) {
            this.accesstypes.push($event.data);
        }
        else {
            this.accesstypes.removeItem({accessTypeId:$event.data.accessTypeId});
        }
    }


   deselectEntity($event) {
        if(!$event.selected) {
           this.accesstypes.removeItem({accessTypeId: $event.data.accessTypeId });
           let rowData = this.availableAccessTypesTable.rows.filter((row)=>{ return typeof row.data !=='undefined'; });
           rowData.forEach(function(a) { if(a.data.accessTypeId === $event.data.accessTypeId) { a.selected = false; } });
        }
   }

    getApplicationList() {
        this.http.get(apiPath + '/applications', { headers: defaultHeaders, withCredentials: true }).subscribe(
            (data) => {
                this.apps = data.json();
            },
            (error) => { ENV_VARS.ssoRedirectFn(error, ENV_VARS, this.router.url, this.appState); });
    }
    createSuccess($event) {
        let res = $event.response.json();
        if(res.application.applicationId === this.appState.get(['appModule','data','selectedApplicationId'])) {
            res._highlighted = true;
            const allRoles: Array<any> = this.appState.get(['appModule', 'data', 'roles']);
            let thisRoleIndex = allRoles.getItem({ permId: parseInt(res.roleId) }, true);
            let newRole = Object.mergeDeep(allRoles[thisRoleIndex], res);
            if(typeof thisRoleIndex === 'number') {
                this.appState.set(['appModule', 'data', 'roles', thisRoleIndex], newRole);
            }
            else {
                this.appState.get(['appModule', 'data', 'roles'], false).push(res)
            }
            var path = apiPath +  "/roles/" + this.appState.get(['appModule','data','selectedApplicationId']) + "/roles";
            this.http.get(path, { headers: this.formHeaders, withCredentials: true }).subscribe(
                (response) => {
                    let roles = this.appState.get(['appModule', 'data', 'roles'], false);
                    roles.splice(0, roles.length, ...response.json());
                },
                (error) => { ENV_VARS.ssoRedirectFn(error, ENV_VARS, this.router.url, this.appState); });
        }
        this._sidePane.closeSidePane();    
    }
    createFailure($event) {
        this._sidePane.closeSidePane();
    }

    handleCancelButtonClick($event) {
        $event.preventDefault();
        this._sidePane.closeSidePane();
    }


}
