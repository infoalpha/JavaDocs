import { Component,  OnInit, OnDestroy, ViewChild} from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { AppState } from '../../../app.service';
import { DatePipe } from '@angular/common';
import apiPath from '../../accessmanagement.apiPath';
import { Http, Headers, RequestOptions, RequestMethod } from '@angular/http';
import { SidePane } from '../../../components/sidepane';
import { defaultHeaders } from '../../../resources';
import { ENV_VARS } from '../../../environment';


@Component({
    selector: 'role-view',
    templateUrl: './viewrole.component.html',
})
export class ViewRoleComponent implements OnInit, OnDestroy {
    private headers: Headers;
    public roleId: number;
    private role: any;
    private headerText: string;
    private creatorName: string;
    private updatorName: string;
    private createdDate:string;
    private updatedDate:string;
    private datePipe = new DatePipe('en-US');
    private selectedRow?: HTMLElement;

    @ViewChild(SidePane) _sidePane: SidePane;
  
    constructor(
        private route: ActivatedRoute, private router: Router, private http: Http, private appState: AppState
    ) {
        this.roleId = +this.route.snapshot.params['id'];
        this.headers = new Headers(defaultHeaders);
    }

  ngOnInit() {
    this.selectedRow = this.appState.get(['appModule', 'data', 'activeRow'], false);
    if(this.selectedRow) {
      this.appState.set(['appModule', 'data', 'activeRow'], void 0);
    }
    this.http.get(apiPath + '/roles/'+ this.roleId, { headers: this.headers, withCredentials: true }).subscribe(
      (data) => {
        this.role = data.json();
        this.headerText = "View Role Log '" + this.role.roleName + "'";

        if(this.role.creator && (this.role.creator.firstName || this.role.creator.lastName)) {
          this.creatorName = this.role.creator.firstName + " " + this.role.creator.lastName;
        }
        if(this.role.updator && (this.role.updator.firstName || this.role.updator.lastName)) {
          this.updatorName = this.role.updator.firstName + " " + this.role.updator.lastName;
        }

        if(this.role.createDate) {
          this.createdDate = this.datePipe.transform(this.role.createDate.slice(0,10), 'shortDate');
        }
        if(this.role.updateDate) {
          this.updatedDate = this.datePipe.transform(this.role.updateDate.slice(0,10), 'shortDate');
        }
      },
      (error) => { ENV_VARS.ssoRedirectFn(error, ENV_VARS, this.router.url, this.appState); });
  }

  ngOnDestroy() {
    if(this.selectedRow) {
      this.selectedRow.classList.remove("active");
    }
  }

  handleCancelButtonClick($event) {
    this._sidePane.closeSidePane();
  }
}

