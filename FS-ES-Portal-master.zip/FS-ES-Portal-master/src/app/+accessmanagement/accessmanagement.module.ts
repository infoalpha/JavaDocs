import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SubMenuModule } from '../components/submenu';

import { FsFormModule } from '../components/form';
import { SidePaneModule } from '../components/sidepane';
import { FsEsTableModule } from '../components/table';

import { routes } from './accessmanagement.routes';
import { AccessManagementComponent } from './accessmanagement.component';

// import { TasksComponent } from './+tasks/tasks.component';
// import { TasksFormComponent } from './+tasks/tasks.formcomponent';
// import { CreateTaskComponent } from './+tasks/create';
// import { ViewTaskComponent } from './+tasks/view';
// import { EditTaskComponent } from './+tasks/edit';

import { RolesComponent } from './+roles/roles.component';
import { RolesFormComponent} from './+roles/roles.formcomponent';
import { CreateRoleComponent } from './+roles/create';
import { ViewRoleComponent } from './+roles/view';
import { EditRoleComponent } from './+roles/edit';

import { PermissionsComponent} from './+permissions/permissions.component';
import { PermissionsFormComponent} from './+permissions/permissions.formcomponent';
import { CreatePermissionComponent} from './+permissions/create';
import { ViewPermissionComponent } from './+permissions/view';
import { EditPermissionComponent } from './+permissions/edit';

@NgModule({
  declarations: [
    AccessManagementComponent,
    // TasksComponent,
    // TasksFormComponent,
    // CreateTaskComponent,
    // ViewTaskComponent,
    // EditTaskComponent,
    RolesComponent,
    RolesFormComponent,
    CreateRoleComponent,  
    ViewRoleComponent,
    EditRoleComponent,
    PermissionsComponent,
    PermissionsFormComponent,
    CreatePermissionComponent,
    ViewPermissionComponent,
    EditPermissionComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    SubMenuModule,
    RouterModule.forChild(routes),
    
    FsFormModule,
    SidePaneModule,
    FsEsTableModule,
    ReactiveFormsModule
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class AccessManagementModule {
  public static routes = routes;
}
