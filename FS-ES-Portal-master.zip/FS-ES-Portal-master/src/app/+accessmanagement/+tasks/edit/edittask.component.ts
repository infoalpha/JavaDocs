import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Http, Headers, RequestOptions, RequestMethod } from '@angular/http'
import { defaultHeaders } from '../../../resources';
import apiPath from '../../accessmanagement.apiPath';

@Component({
    selector: 'task-edit',
    template: `<task-form *ngIf="entity" [headerText]="headerText" formSubmitText="Save" formMethod="PUT" [entity]="entity"></task-form>`
})
export class EditTaskComponent implements OnInit {
    
    private headers: Headers;

    public entityId: number;

    private entity: any;

    private headerText: string;

    constructor(
        public route: ActivatedRoute,
        private http: Http
    ) {
        this.headers = new Headers(defaultHeaders);
        this.entityId = +this.route.snapshot.params['id'];
    }

    ngOnInit() {
        this.http.get(apiPath + '/tasks/' + this.entityId, { headers: this.headers }).toPromise()
            .then((data) => {
                this.entity = data.json();
                this.headerText = "Edit Task '" + this.entity.taskName + "'";
            })
            .catch();
    }

}