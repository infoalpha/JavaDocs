// import { Component, OnInit, AfterViewInit, Inject, ViewChild, ContentChild, ViewEncapsulation, ChangeDetectorRef, NgZone } from '@angular/core';
// import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
// import { Router, ActivatedRoute } from '@angular/router'
// import { Http, Headers } from '@angular/http';
// import { AppState } from '../../app.service';
// import apiPath from '../accessmanagement.apiPath'
// import { defaultHeaders } from '../../resources';
// import { FsEsModal } from '../../components/modal';

// import { FsEsTable, dynamicLoad } from '../../components/table';

// @Component({
//   selector: 'tasks-page',
//   encapsulation: ViewEncapsulation.None,
//   templateUrl: './tasks.component.html',
//   styleUrls: ['./tasks.component.css']
// })
// export class TasksComponent implements OnInit, AfterViewInit {

//   private headers: Headers;

//   private modalButtons = [
//     {
//       text: "Delete",
//       click: () => { console.log("delete"); },
//       default: true
//     },
//     {
//       text: "View Relationships",
//       content: `
//           <div><ul><li>test</li><li><button>button</button>!</li></ul></div>
//       `
//     }
//   ]

//   showModal: boolean = true;

//   @ViewChild('tableControl')
//   private tasksTable: FsEsTable;

//   entities: Array<any>;

//   constructor( private router: Router, private http: Http, private currentActivatedRoute: ActivatedRoute, private appState: AppState, private modal: FsEsModal, private cdr: ChangeDetectorRef, private zone: NgZone) {
//     this.entities = [ ];
//     if(!this.appState.state.appModule.data.tasks) {
//       this.appState.set(['appModule', 'data', 'tasks'], []);
//     }
//     this.headers = new Headers(defaultHeaders)
//   }

//   public ngOnInit() {
//     this.http.get(apiPath + "/tasks", { headers: this.headers })//.toPromise()
//       .subscribe((response) => {
//         this.appState.set(['appModule', 'data', 'tasks'], response.json());
//         this.entities = this.appState.get(['appModule', 'data', 'tasks']);
//         this.entities.createShadow();
//         let a  = this.entities.addPropertyFilter("taskDesc", "7");
//         this.entities.addPropertyFilter("taskDesc", "5");
//         this.entities.addPropertyFilter("taskId", 15, false, true);
//         console.log(a);
//         console.log(this.entities);
//         this.entities.removePropertyFilter(a);
//         //dynamicLoad(this.entities, { table: this.tasksTable, changeDetectorRef: this.cdr })
//         // this.zone.runOutsideAngular(() => {
//         //     setTimeout(() => { console.log(this.entities) }, 5000)
//         // })
//       })
//       // .catch((reason) => {
//       //   console.warn(reason);
//       //   console.log("Could not load task data.");
//       // })

//       this.modal.data = { inputs: { buttons: this.modalButtons } };
//   }

//   public ngAfterViewInit() {
//   }

//   deleteEntity(entityId) {
//     this.modal.launch();
//   }

//   selectedRolesChange($event) {
//     console.log($event);
//   }

//   save($event) {
//     console.log("event");
//     console.log($event);
//   }

// }
