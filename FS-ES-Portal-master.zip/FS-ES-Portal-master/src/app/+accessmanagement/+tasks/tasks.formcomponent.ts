// import { Component, Input, Inject, OnInit, AfterContentInit, ViewChild, ContentChild } from '@angular/core';
// import { Http, Headers, RequestOptions, RequestMethod } from '@angular/http'
// import { FormBuilder, FormGroup, FormControl, Validators, AsyncValidatorFn } from '@angular/forms';
// import { AppState } from '../../app.service';
// import { FsEsTable, FsEsTableRow } from '../../components/table';
// import { SidePane } from '../../components/sidepane';
// import { defaultHeaders } from '../../resources';
// import apiPath from '../accessmanagement.apiPath';

// @Component({
//     selector: 'task-form',
//     templateUrl: './tasks.formcomponent.html'
// })
// export class TasksFormComponent implements OnInit, AfterContentInit {

//     private baseFormAction = apiPath + '/tasks';

//     private formAction;
//     private defaultNameValue;

//     @Input() headerText: string;
//     @Input() formSubmitText: string;
//     @Input() formMethod: string;
//     @Input() entity: any;

//     formHeaders: Headers;

//     form: FormGroup;
//     lobControl: FormControl;
//     taskNameControl: FormControl;
//     descriptionControl: FormControl;
//     permissionsControl: FormControl;

//     availablePermissionsControl: FormControl;

//     lobOptions: Array<any>;
//     applications: Array<any>;
//     availablePermissions: Array<any> = [];
//     permissions: Array<any> = [];

//     @ViewChild('availablePermissionsTable') availablePermissionsTable: FsEsTable;
//     @ViewChild('selectedPermissionsTable') selectedPermissionsTable: FsEsTable;

//     @ViewChild(SidePane) _sidePane: SidePane;

//     constructor(
//         private http: Http,
//         @Inject(FormBuilder) fb: FormBuilder,
//         private appState: AppState
//     ) {

//         this.checkNameAsync = this.checkNameAsync.bind(this);

//         this.formHeaders = new Headers(Object.assign({}, defaultHeaders));

//         this.taskNameControl = new FormControl('', [ Validators.required, Validators.maxLength(50) ], this.checkNameAsync);
//         this.descriptionControl = new FormControl('', [ Validators.required, Validators.maxLength(300) ]);
//         this.lobControl = new FormControl('', Validators.required);
//         this.permissionsControl = new FormControl([]);
//         this.form = fb.group({
//             taskName: this.taskNameControl,
//             taskDesc: this.descriptionControl,
//             lineOfBusiness: fb.group({
//                 lobId: this.lobControl
//             }),
//             permissions: this.permissionsControl,
//             updater: {
//                 eid: "RXD428"
//             },
//             creator: {
//                 eid: "RXD428"
//             }
//         });

//         this.availablePermissionsControl = new FormControl([]);

//         this.lobOptions = [ ];

//         this.applications = [ ]

//     }

//     ngOnInit() {
//         if(this.entity) {
//             this.taskNameControl.setValue(this.entity.taskName);
//             this.taskNameControl.markAsPristine();
//             this.taskNameControl.markAsUntouched();
//             this.descriptionControl.setValue(this.entity.taskDesc);
//             this.descriptionControl.markAsPristine();
//             this.descriptionControl.markAsUntouched();
//             this.lobControl.setValue(this.entity.lineOfBusiness.lobId);
//             this.lobControl.markAsPristine();
//             this.lobControl.markAsUntouched();
//             this.permissions = this.entity.permissions;
//             this.permissionsControl.setValue(this.entity.permissions);
//             this.permissionsControl.markAsPristine();
//             this.permissionsControl.markAsUntouched();

//             this.defaultNameValue = this.entity.taskName;
//         }

//         this.formAction = this.entity && this.formMethod.toUpperCase() === "PUT" ? this.baseFormAction + '/' + this.entity.taskId : this.baseFormAction;
//     }

//     ngAfterContentInit() {

//         this.http.get(apiPath + '/lines-of-business', { headers: this.formHeaders })
//             .toPromise().then((res) => {
//                 this.lobOptions = res.json();
//             })
//             .catch();

//         this.http.get(apiPath + '/applications', { headers: this.formHeaders })
//             .toPromise()
//             .then((res) => {
//                 this.applications = res.json();
//             })
//             .catch();
//     }

//     checkNameAsync(control: FormControl): Promise<any> {
//         return new Promise(resolve => {
            
//             if(this.lobControl.value.length === 0 || 
//                 control.value.length === 0 || 
//                 (this.entity && this.formMethod.toUpperCase() === "PUT" && control.value.toLowerCase() === this.defaultNameValue.toLowerCase())) 
//             { 
//                 resolve(null); return;
//             }

//             this.http.post(apiPath + '/tasks/exists', { lineOfBusiness: { lobId: parseInt(this.lobControl.value, 10) }, taskName: control.value }, { headers: this.formHeaders })
//                 .subscribe(
//                     (data) => {
//                         resolve(data.json().taken ? { taken: true } : null)
//                     },
//                     (error) => {
//                         resolve(null)
//                     }
//                 );

//         })
//     }

//     getAvailablePermissions($event) {
//         this.http.get(apiPath + '/permissions/' + $event.target.value + '/permissions', { headers: this.formHeaders })
//             .toPromise()
//             .then((res) => {
//                 this.availablePermissions = res.json();
//                 setTimeout(() => { // temporary solution!
//                     this.availablePermissionsTable.rows.filter((row) => { return row.isDataRow }).forEach((row) => {
//                         for(let i = 0; i < this.permissionsControl.value.length; i++) {
//                             if(this.permissionsControl.value[i].permId === row.data.permId) {
//                                 row.selected = true;
//                                 break;
//                             }
//                         }
//                     });
//                 }, 1);
//             })
//             .catch();
//     }

//     toggleSelectedEntity($event) {
//         if($event.selected) {
//             this.permissions.push($event.data);
//         }
//         else {
//             this.permissions.removeItem({ permId: $event.data.permId });
//         }
//     }

//     deselectEntity($event) {
//         if(!$event.selected) {
//             this.permissions.removeItem({ permId: $event.data.permId });
//             let rowData = this.availablePermissionsTable.rows.filter((row) => { return row.isDataRow; });
//             rowData.forEach(function(a) { if(a.data.permId === $event.data.permId) { a.selected = false; } });
//         }
//     }

//     createSuccess($event) {
//         let res = $event.response.json();
//         res._highlighted = true;
//         const allTasks: Array<any> = this.appState.get(['appModule', 'data', 'tasks']);
//         let thisTaskIndex = allTasks.getItem({ taskId: parseInt(res.taskId) }, true);
//         let newTask = Object.mergeDeep(allTasks[thisTaskIndex], res);
//         console.log(newTask);
//         if(typeof thisTaskIndex === 'number') {
//             this.appState.set(['appModule', 'data', 'tasks', thisTaskIndex], newTask);
//         }
//         else {
//             this.appState.state.appModule.data.tasks.push(res)
//         }
//         this.http.get(apiPath + "/tasks", { headers: this.formHeaders }).toPromise()
//             .then((response) => {
//                 this.appState.set(['appModule', 'data', 'tasks'], response.json());
//             }).catch()
//         this._sidePane.closeSidePane();
//     }

//     createFailure($event) {
//         this._sidePane.closeSidePane();
//     }

//     handleCancelButtonClick($event) {
//         this._sidePane.closeSidePane();
//     }
// }