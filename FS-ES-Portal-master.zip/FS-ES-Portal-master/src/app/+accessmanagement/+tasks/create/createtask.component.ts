import { Component, Inject, AfterContentInit, ViewChild, ContentChild } from '@angular/core';
import { Http, Headers, RequestOptions, RequestMethod } from '@angular/http'
import { FormBuilder, FormGroup, FormControl, Validators, AsyncValidatorFn } from '@angular/forms';
import { FsEsTable, FsEsTableRow } from '../../../components/table';
import { SidePane } from '../../../components/sidepane';
import { defaultHeaders } from '../../../resources';
import apiPath from '../../accessmanagement.apiPath';

@Component({
    selector: 'task-create',
    template: `<task-form headerText="Create Task" formSubmitText="Create" formMethod="POST"></task-form>`
})
export class CreateTaskComponent { 
}