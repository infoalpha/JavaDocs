import { Component } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

@Component({
    selector: 'task-view',
    template: `
        <side-pane>
            <header>Title for {{ taskId }}</header>
            <main>content</main>
            <footer>actions</footer>
        </side-pane>
    `
})
export class ViewTaskComponent {
    
    public taskId: number;

    constructor(
        public route: ActivatedRoute
    ) {
        console.log(this.route);
        this.taskId = +this.route.snapshot.params['id'];
    }

}