import { AccessManagementComponent } from './accessmanagement.component';

import { PreviousRouteRecorder } from '../previousrouterecorder.service';

// import { TasksComponent } from './+tasks/tasks.component';
// import { CreateTaskComponent } from './+tasks/create/createtask.component';
// import { ViewTaskComponent } from './+tasks/view/viewtask.component';
// import { EditTaskComponent } from './+tasks/edit/edittask.component';

import { RolesComponent } from './+roles/roles.component';
import { CreateRoleComponent } from './+roles/create/createrole.component';
import { ViewRoleComponent } from './+roles/view/viewrole.component';
import { EditRoleComponent } from './+roles/edit/editrole.component';


import { PermissionsComponent } from './+permissions/permissions.component';
import { CreatePermissionComponent } from './+permissions/create/createpermission.component';
import { ViewPermissionComponent } from './+permissions/view/viewpermission.component';
import { EditPermissionComponent } from './+permissions/edit/editpermission.component';

export const routes = [
  {
    path: '', component: AccessManagementComponent,
    children: [
      { path: '', component: AccessManagementComponent, pathMatch: 'full' },
      // {
      //   path: 'tasks', component: TasksComponent,
      //   children: [
      //     { path: '', canDeactivate: [PreviousRouteRecorder] },
      //     { path: 'create', component: CreateTaskComponent, canDeactivate: [PreviousRouteRecorder] },
      //     { path: ':id', component: ViewTaskComponent, canDeactivate: [PreviousRouteRecorder] },
      //     { path: ':id/edit', component: EditTaskComponent, canDeactivate: [PreviousRouteRecorder] }
      //   ]
      // },
      {
        path: 'roles', component: RolesComponent,
        children: [
          { path: '', canDeactivate: [PreviousRouteRecorder] },
          { path: 'create', component: CreateRoleComponent, canDeactivate: [PreviousRouteRecorder] },
          { path: ':id', component: ViewRoleComponent, canDeactivate: [PreviousRouteRecorder] },
          { path: ':id/edit', component: EditRoleComponent, canDeactivate: [PreviousRouteRecorder] }
        ]
      },
      {
        path: 'permissions', component: PermissionsComponent,
        children: [
          { path: '', canDeactivate: [PreviousRouteRecorder] },
          { path: 'create', component: CreatePermissionComponent, canDeactivate: [PreviousRouteRecorder] },
          { path: ':id', component: ViewPermissionComponent, canDeactivate: [PreviousRouteRecorder] },
          { path: ':id/edit', component: EditPermissionComponent, canDeactivate: [PreviousRouteRecorder] }
        ]
      }
    ]
  },
];
