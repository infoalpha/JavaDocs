import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AppState } from './app.service'

@Component({
    template: ``
})
export class AppLogin implements OnInit, OnDestroy {

    private timeout;

    constructor(private appState: AppState, private router: Router, private activatedRoute: ActivatedRoute) {

    }

    ngOnInit() {
        this.activatedRoute.queryParams.subscribe(params => {
            let redirectUri = params['redirect_uri'];
            if(redirectUri) {
                this.appState.set("currentUser", { 'eid': 'ICH407' })
                this.router.navigateByUrl(decodeURI(redirectUri));
                if(this.timeout) { clearTimeout(this.timeout); }
            }
            else {
                this.timeout = setTimeout(() => {
                    this.router.navigateByUrl('/');
                }, 1000);
            }
        })
    }

    ngOnDestroy() {
        if(this.timeout) { clearTimeout(this.timeout); }
    }

}