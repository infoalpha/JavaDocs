import { Directive, ElementRef, Renderer, Input, AfterContentChecked } from '@angular/core';

@Directive({
    selector: '.fs-es-highlighted.',
    // host: {
    //     'class': 'fs-es-highlighted'
    // }
})
export class FsEsHighlighted implements AfterContentChecked {
    
    // @Input('fs-es-highlighted') fsEsHighlighted: boolean;
    // @Input() data: any;

    constructor(private renderer: Renderer, private elementRef: ElementRef) {
        console.log("highlighted");
    }

    ngAfterContentChecked() {
        console.log("highlighted");
        setTimeout(() =>{
            //this.renderer.setElementClass(this.elementRef.nativeElement, 'fs-es-highlighted', false);
            // setTimeout(() => {
            //     if(this.data._highlighted) { this.data._highlighted = void 0; }
            //     this.renderer.setElementAttribute(this.elementRef.nativeElement, 'fs-es-highlighted', void 0);
            // }, 1)
        }, 1)
    }
}