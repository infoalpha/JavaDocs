import { Routes } from '@angular/router';
import { HomeComponent } from './home';
import { AppLogin } from './app.login.component';
import { NoContentComponent } from './no-content';
import { AuthGuard } from './authentication.service'

import { DataResolver } from './app.resolver';

export const ROUTES: Routes = [
  { path: 'authenticate', component: AppLogin },
  {
    path: '', canActivate: [AuthGuard], children: [
      { path: '', component: HomeComponent },
      { path: 'accessmanagement', loadChildren: './+accessmanagement#AccessManagementModule' },
      { path: '**', component: NoContentComponent }
    ]
  }
];
