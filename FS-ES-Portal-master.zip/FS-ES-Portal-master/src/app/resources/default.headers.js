import { ENV_VARS } from '../environment';

export const defaultHeaders = ENV_VARS.defaultHeaders