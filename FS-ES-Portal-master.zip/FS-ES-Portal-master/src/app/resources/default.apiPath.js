export const defaultApiPath = "http://fs-portal.clouddqt.capitalone.com:11400/profile-mgmt-web/tools";
