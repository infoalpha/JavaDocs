import { Injectable } from '@angular/core';

export type InternalStateType = {
  [key: string]: any
};

@Injectable()
export class AppState {

  private _state: InternalStateType = { };

  // already return a clone of the current state
  public get state() {
    return this._state = this._clone(this._state);
  }
  // never allow mutation
  public set state(value) {
    throw new Error('do not mutate the `.state` directly');
  }

  public get(prop?: any, clone?: boolean) {
    if(typeof prop === 'undefined' && typeof clone === 'undefined') {
      return this.state;
    }
    // use our state getter for the clone
    clone = clone === false ? false : true;
    let state = clone ? this.state : this._state;
    if(Array.isArray(prop)) {
      for(let i = 0; i < prop.length; i++) {
        if(state.hasOwnProperty(prop[i])) {
          state = state[prop[i]];
        }
        else
          return void 0;
      }
      return state;
    }
    return state.hasOwnProperty(prop) ? state[prop] : void 0;
  }

  public set(prop: string | Array<string | number>, value: any) {
    // internally mutate our state
    let stateObject = this._state;
    if(Array.isArray(prop)) {
      prop.forEach((p, i) => {
        if(i < prop.length - 1) {
          stateObject = stateObject[p];
        }
        else
          stateObject[p] = value;
      });
    }
    else
      return this._state[prop] = value;
  }

  private _clone(object: InternalStateType) {
    // simple object clone
    return Object.assign({}, object);
  }

  public initializeState(object) {
    this._state = Object.assign({}, object);
  }
}
