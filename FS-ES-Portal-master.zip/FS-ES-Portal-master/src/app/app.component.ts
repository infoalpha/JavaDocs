import { Component, OnInit, AfterViewInit, ViewEncapsulation, ViewChild, ComponentFactoryResolver, ViewContainerRef, HostListener } from '@angular/core';
import { Router, Route, NavigationEnd } from '@angular/router';
import { AppState } from './app.service';
import { FsEsModal, FsEsModalComponent } from './components/modal';

@Component({
	selector: 'app',
	encapsulation: ViewEncapsulation.None,
	styleUrls: [
		'./app.component.css'
	],
	templateUrl: './app.component.html',
	providers: [FsEsModal]
})
export class AppComponent implements OnInit, AfterViewInit {
	public name = 'FS Access Management';

	public userName: string = 'Anonymous User';

	@ViewChild('modalHost', { read: ViewContainerRef }) modalHost: ViewContainerRef;

	constructor(
		public appState: AppState,
		public router: Router,
		private factoryResolver: ComponentFactoryResolver,
		public modal: FsEsModal
	) {
		appState.set('showNavigation', false);
		appState.set('appModule', { });
		this.router.events.subscribe(
			e => {
				this.toggleNavigationPane(false);
			}
		);
	}

	@HostListener('window:beforeunload')
	windowUnload() {
		let appModule = this.appState.get('appModule');
		if(appModule) {
			try {
				let appModuleAsString = JSON.stringify(appModule);
				localStorage.setItem('FsEsPortalAppModule', appModuleAsString);
			}
			catch(e) { console.log(e) }
		}
        localStorage.removeItem('previousRoute');
		let timestamp = new Date().getUTCSeconds();
		document.cookie = 'SHTS=' + timestamp + ';path=' + encodeURI('/') + ';';
		document.cookie = 'SHTSP=' + encodeURI(this.router.url) + ';path=' + encodeURI('/') + ';';
	}

	ngAfterViewInit() {
		this.modal.dynamicComponentContainer = this.modalHost;
	}

	public toggleNavigationPane(showNavigation: boolean) {
		showNavigation = (typeof showNavigation !== 'undefined' ? showNavigation : !this.appState.get('showNavigation'));
		this.appState.set('showNavigation', showNavigation);
	}

	public ngOnInit() {
		let user = this.appState.get("currentUser");
		if(user) {
			this.userName = user.firstName + " " + user.lastName;
		}
	}
}