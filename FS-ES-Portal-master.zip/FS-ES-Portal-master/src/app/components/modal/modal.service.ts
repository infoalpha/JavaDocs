import { Injectable, Inject, ReflectiveInjector, ComponentFactoryResolver, NgZone, ViewContainerRef, ComponentRef } from '@angular/core';

import { FsEsModalComponent } from './modal.component';

@Injectable()
export class FsEsModal {

    private currentComponent: ComponentRef<FsEsModalComponent> = null;

    private modalQueue: Array<ComponentRef<FsEsModalComponent>> = [];

    modal: FsEsModalComponent;

    private _data: any;
    private _dynamicComponentContainer: ViewContainerRef;

    constructor(private resolver: ComponentFactoryResolver, private zone: NgZone) {
    }

    set dynamicComponentContainer(value: ViewContainerRef) {
        this._dynamicComponentContainer = value;
    }

    set data(value: any) {
        this._data = Object.keys(value).map((inputName) => { return { provide: inputName, useValue: value[inputName] }; });
    }

    public launch() {
        if(this._data && this._dynamicComponentContainer) {
            let resolvedInputs = ReflectiveInjector.resolve(this._data);
            let injector = ReflectiveInjector.fromResolvedProviders(resolvedInputs, this._dynamicComponentContainer.parentInjector);
            let factory = this.resolver.resolveComponentFactory(FsEsModalComponent);
            let component = factory.create(injector);
            Object.keys(this._data).forEach((input) => {
                component.instance[this._data[input].provide] = this._data[input].useValue;
            })

            this.insertIntoView(component);
        }
    }

    private insertIntoView(component: ComponentRef<FsEsModalComponent>) {
        if(!this.currentComponent) {
            this.currentComponent = component;
            this._dynamicComponentContainer.insert(this.currentComponent.hostView);
        }
        else {
            this.modalQueue.push(component);
        }
    }

    public close() {
        if(!this.currentComponent) {
            return;
        }
        this.currentComponent.instance.isInitialized = false;
        this.zone.runOutsideAngular(() => {
            setTimeout(() => {
                this.zone.run(() => {
                    this.currentComponent.onDestroy(() => {
                        this.currentComponent = null;
                        if(this.modalQueue.length) {
                            let nextComponent = this.modalQueue[0];
                            this.modalQueue.splice(0,1);
                            this.insertIntoView(nextComponent);
                        }
                    })
                    this.currentComponent.destroy();
                });
            }, 150)
        })
    }

}