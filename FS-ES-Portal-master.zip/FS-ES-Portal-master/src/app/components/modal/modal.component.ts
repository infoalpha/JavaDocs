import { Component, HostBinding, HostListener, Input, Output, EventEmitter, ViewChild, OnInit, AfterViewInit, ElementRef, NgZone, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';

import { FsEsModal } from './modal.service';

const PRIMARY_COLOR = {
    rgb: "rgb(18, 143, 255)",
    rgba: "rgba(18, 143, 255, 1)",
    hex: "#128fff",
    r: 18,
    g: 143,
    b: 255
}
const SECONDARY_COLOR = {
    rgb: "rgb(250, 250, 250)",
    rgba: "rgba(250, 250, 250, 1)",
    hex: "#fafafa",
    r: 250,
    g: 250,
    b: 250
}

@Component({
    selector: 'fs-es-modal',
    template: `
        <div #container class="l-modal" [class.expanded]="content">
            <div class="l-modal__container">
                <div class="header">{{ header }}</div>
                <div class="message">{{ body }}</div>
                <div #menuContainer class="menu">       
                    <ul>
                        <li *ngFor="let option of options; let i = index"><button [class.selected]="option.selected" [tabindex]="i + 1" (focus)="handleButtonFocus($event, option)" (click)="handleButtonFocus($event, option);option.click($event)">{{ option.text }}</button></li>
                        <li *ngIf="!hideCancelButton"><button #cancel [tabindex]="options.length + 1" [class.selected]="options.length === 0" (focus)="handleButtonFocus($event)" (click)="handleButtonFocus($event)">{{ cancelText || "Cancel" }}</button></li>
                    </ul>
                </div>
                <div class="content"><div #contentContainer class="wrapper"></div></div>
            </div>
        </div>`,
    styleUrls: ['modal.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class FsEsModalComponent implements OnInit, AfterViewInit {

    @Input() header: string;
    @Input() body: string;
    @Input() options: Array<any> = [];
    @Input() cancelText: string;
    @Input() hideCancelButton: boolean;

    @ViewChild('container')
    private _container: ElementRef;

    @ViewChild('contentContainer')
    private contentContainer: ElementRef;

    @ViewChild('menuContainer')
    private menuContainer: ElementRef;

    private container: HTMLElement;

    private keyMap = { };

    @ViewChild('cancel')
    private _cancel: ElementRef;
    
    private cancel: HTMLElement;
    
    private _content = "";

    set content(value: any) { 
        this._content = value;
        this.contentContainer.nativeElement.innerHTML = value;
    }

    get content() {
        return this._content;
    }

    private getSelectedButton(): Element {
        return (<HTMLElement>this.menuContainer.nativeElement).querySelectorAll(".selected").item(0);
    }

    public handleButtonFocus($event, data) {
        if(this.getSelectedButton() !== $event.target) {
            this.content = data && data.content ? data.content : "";
            this.content = this.content.trim();
            this.zone.runOutsideAngular(() => {
                this.getSelectedButton().classList.remove("selected");
                $event.target.classList.add("selected");
            })
        }
    }

    @Input() promise: Promise<any>;

    private promiseResolved: Boolean;
    private promiseSuccess: Boolean;

    @HostBinding('class.initialized') isInitialized: boolean = false;

    @HostListener('click', ['$event'])
    private onClick($event) {
        if(this.cancel.contains($event.target)){
            this.handleClose();
            return;
        }
        if(this.container.contains($event.target)) {
            return;
        }
        this.handleClose();
    }

    @HostListener('window:keydown', ['$event'])
    @HostListener('window:keyup', ['$event'])
    private keyboardInput(event: KeyboardEvent) {
        event.preventDefault();     

        this.keyMap[event.keyCode] = event.type === "keydown";

        let selectedIndex = 0;
        for(let i = 0; i < this.options.length; i++) {
            if(this.options[i].selected) {
                selectedIndex = i;
                break;
            }
            else if(i === this.options.length - 1) {
                selectedIndex = this.options.length
            }
        }

        let nextIndex;

        if(this.keyMap[13]) {
            if(selectedIndex === this.options.length)
                this.handleClose();
            else if(typeof this.options[selectedIndex].click === 'function')
                this.options[selectedIndex].click();
            return false;
        }
        else if(this.keyMap[27]) {
            this.handleClose();
            return false;
        }
        else if(this.keyMap[40] || (this.keyMap[9] && !this.keyMap[16])) {
            nextIndex = (selectedIndex + 1) % (this.options.length + 1);
        }
        else if(this.keyMap[38] || (this.keyMap[9] && this.keyMap[16])) {
            nextIndex = (((selectedIndex - 1) % (this.options.length + 1)) + (this.options.length + 1)) % (this.options.length + 1) ;
        }
        else {
            return true;
        }

        if(selectedIndex === this.options.length)
            this.cancel.classList.remove("selected");
        else
            this.options[selectedIndex].selected = false;

        if(nextIndex === this.options.length) {
            this.content = "";
            this.cancel.classList.add("selected");
        }   
        else {
            this.content = this.options[nextIndex].content ? this.options[nextIndex].content : "";
            this.content = this.content.trim();
            this.options[nextIndex].selected = true;    
        }
    }

    constructor(private modal: FsEsModal, private zone: NgZone) {

    }

    ngOnInit() {

        if(this.options.length) {
            let defaultIndex = 0;
            this.options.forEach((button, index) => {
                if(button.default && (button.default === true || 
                    button.default === 1 || 
                    button.default.toString().toLowerCase() === "true")) { 
                        defaultIndex = index;
                    }
                if(typeof button.click !== 'function') {
                    button.click = () => { };
                }
            })

            this.options[defaultIndex].selected = true;
        }
    }

    ngAfterViewInit() {
        this.container = this._container.nativeElement;
        if(this._cancel) { this.cancel = this._cancel.nativeElement; }

        this.setMargins();

        this.zone.runOutsideAngular(() => {
            setTimeout(() => {
                this.zone.run(() => { this.isInitialized = true; });
            }, 0);
        });
    }

    private setMargins() {
        this.container.style.marginTop = -this.container.offsetHeight / 2 + "px";
    }

    public handleClose() {
        this.modal.close();
    }

}