export { FsEsModalModule } from './modal.module';
export { FsEsModal } from './modal.service';
export { FsEsModalComponent } from './modal.component';

// import { CustomElement } from '../../utils';

// @CustomElement('fs-es-modal')
// class FsEsModal extends HTMLElement {

//     private canvas;
//     private context;

//     get width() {
//         return parseInt(this.getAttribute("width"), 10);
//     }

//     get height() {
//         return parseInt(this.getAttribute("height"), 10);
//     }

//     constructor() {
//         super();

//         this.canvas = document.createElement('canvas');

//         this.canvas.width = this.width ? this.width * 2 : 1126;
//         this.canvas.height = this.height ? this.height * 2 : 800;
//         this.canvas.style.width = this.width + "px";
//         this.canvas.style.height = this.height + "px";
//         this.canvas.style.marginLeft = -(this.width / 2) + "px";
//         this.canvas.style.marginTop = -(this.height / 2) + "px";
        
//         this.context = this.canvas.getContext("2d");

//         let shadowRoot = this.attachShadow({ mode: 'open' });
//         shadowRoot.innerHTML = `
//             <style>
//                 :host {
//                     display: block;
//                     position: fixed;
//                     z-index: 10000;
//                     top: 0px;
//                     left: 0px;
//                     right: 0px;
//                     bottom: 0px;
//                     background: rgba(0, 0, 0, .4);
//                 }
//                 :host>canvas {
//                     position: absolute;
//                     left: 50%;
//                     top: 50%;
//                 }
//             </style>
//             <div><slot></slot></div>
//         `;
//         shadowRoot.appendChild(this.canvas);

//         this.draw();
//     }

//     private draw() {
//         this.context.strokeStyle = "rgba(250, 250, 250, 1)";
//         this.context.lineWidth = 10;
//     }

//     private animateLoadBar() {

//     }

//     private animateBox() {

//     }

// }