import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';
import { NgModule } from '@angular/core';

import { FsEsModalComponent } from './modal.component';


@NgModule({
  declarations: [
    FsEsModalComponent
  ],
  imports: [
    CommonModule,
    HttpModule
  ],
  exports: [
    FsEsModalComponent
  ]
})
export class FsEsModalModule { }