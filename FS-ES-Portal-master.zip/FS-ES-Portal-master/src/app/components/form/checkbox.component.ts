import { Component, forwardRef, ViewChild, Input, Output, EventEmitter, AfterViewInit } from '@angular/core';
import { FormControl, ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
    selector: 'fs-es-checkbox',
    /* Do not format by adding line breaks between element declarations as it will mess up styling  */
    template: `
    <div [ngClass]="{ 'form-input': true, 'form-input__checkbox': true }">
        <div class="input-wrapper"><input [id]="getInputId()" [value]="value" [name]="name" #inputField type="checkbox"  
                    (change)="handleChange($event)"
                    (blur)="handleBlur($event)" 
                    (focus)="handleFocus($event)" 
                    (input)="handleInputEvent($event)"
                    [checked]="_value"
        /><label [for]="getInputId()"><ng-content></ng-content></label></div>   
    </div>   
    `,
    styleUrls: ['./checkbox.component.css'],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => FsEsCheckbox),
            multi: true
        }
    ]
})
export class FsEsCheckbox implements ControlValueAccessor {

    @ViewChild('inputField') inputField;

    private _value: any;

    @Input() value;

    @Input() formControl: FormControl;
    @Input() name: string;
    @Input() type: boolean;
    @Input() label: string;
    @Input() validation: any;
    @Input() required: any;

    @Output() change = new EventEmitter();
    @Output() input = new EventEmitter();
    @Output() blur = new EventEmitter();
    @Output() focus = new EventEmitter();

    public suggestionText: String;
    public suggestionValue: String;
    public isValid: boolean;

    propegateChange = (_: any) => { }

    constructor() {
        this.suggestionText = "";
        this.suggestionValue = "";
    }

    getInputId() {
        if(!this.name || this.name.length === 0) {
            return void 0;
        }
        let inputId = "";
        if(this.inputField.nativeElement.form.name) {
            inputId += this.inputField.nativeElement.form.name;
            inputId += "__";
        }
        else {
            inputId += "anonymous-form__";
        }
        inputId += this.name;
        return inputId;
    }

    writeValue(value: any) {
        this._value = value;
        if(typeof this.value === 'undefined') {
            this.propegateChange(this._value);
        }
        else if(this._value === true)
            this.propegateChange(this.value);
        else {
            this.propegateChange(void 0);
        }
    }

    registerOnChange(fn) {
        this.propegateChange = fn;
    }

    registerOnTouched(fn) {

    }

    handleChange($event) {
        this.writeValue($event.target.checked);
    }

    handleInputEvent($event) {
        //this.value = $event.target.value;
        this.input.emit($event);
    }

     handleBlur($event) {
        this.blur.emit($event);
    }

    handleFocus($event) {
        this.focus.emit($event);
    }
}