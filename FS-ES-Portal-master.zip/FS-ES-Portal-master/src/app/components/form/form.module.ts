import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { NgModule } from '@angular/core';

import { FsEsForm } from './form.component';
import { FsEsInput } from './input.component';
import { FsEsHiddenInput } from './hiddeninput.component';
import { FsEsFormrow } from './formrow.component';
import { FsEsDropdown } from './dropdown.component';

import { FsEsCheckbox } from './checkbox.component';

import { FsEsTextarea } from './textarea.component';
import { FsEsAutocomplete } from './autocomplete.component';


@NgModule({
  declarations: [
    FsEsForm,
    FsEsInput,
    FsEsHiddenInput,
    FsEsFormrow,
    FsEsDropdown,
    FsEsCheckbox,
    FsEsTextarea,
    FsEsAutocomplete
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule
  ],
  exports: [
    FsEsForm,
    FsEsInput,
    FsEsHiddenInput,
    FsEsFormrow,
    FsEsDropdown,
    FsEsCheckbox,
    FsEsTextarea,
    FsEsAutocomplete
  ]
})
export class FsFormModule { }
