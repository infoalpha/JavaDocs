import { Component, forwardRef, ViewChild, Input, Output, EventEmitter, OnInit, ViewEncapsulation, NgZone } from '@angular/core';
import { FormControl, ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

const SUGGESTION_LIST_ITEM_HEIGHT = 33;

@Component({
    selector: 'fs-es-autocomplete',
    template: `
        <div [ngClass]="{ 'form-input': true, 'form-input__autocomplete': true, 'hasSuggestions': suggestionText.length }" [style.width]="width">
            <div class="label-wrapper">
                <label [ngClass]="{ 'required': required }" [for]="getInputId()">{{ label }}</label>
            </div>
            <div class="input-wrapper">
                <input #inputField
                    [id]="getInputId()"
                    [name]="name"
                    [ngClass]="{ 'primary': true, 'error': isValid === false }"
                    type="text"
                    (change)="handleChange($event)"
                    (blur)="handleBlur($event)" 
                    (focus)="handleFocus($event)" 
                    (keyup)="handleKeyUp($event)"
                    (keydown)="handleKeyDown($event)" 
                    (input)="handleInputEvent($event)"
                    [disabled]="disabled"
                    [required]="required"
                    autocomplete="off"
                    [readonly]="value"
                />
                <div #suggestionList class="suggestion-list" *ngIf="showSuggestions">
                    <ul>
                        <li *ngFor="let item of list; let i = index" [ngClass]="{ 'active': i === activeIndex }" (click)="applySelection(item)">{{ item.taskName }}</li>
                        <li *ngIf="list.length === 0" class="no-results">{{ noResultsMessage || "No items available." }}</li>
                    </ul>
                </div>
                <div class="selected-item" *ngIf="value">{{ displayValue }}<span class="remove" (click)="removeSelection()"></span></div>
            </div>
        </div>
    `,
    styleUrls: [ './autocomplete.component.css' ],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => FsEsAutocomplete),
            multi: true
        }
    ],
    encapsulation: ViewEncapsulation.None
})
export class FsEsAutocomplete implements OnInit, ControlValueAccessor {

    @ViewChild('inputField') inputField;
    @ViewChild('suggestionList') suggestionList;

    private _value: any;

    @Input()
    private formControl: FormControl;

    @Input() control: FormControl;
    @Input() name: string;
    @Input() label: string;
    @Input() required: any;
    @Input() disabled: any;
    @Input('no-results-message') noResultsMessage: string;

    private _list: Array<any>;

    get list(): Array<any> {
        return this._list;
    }
    @Input()
    set list(value: Array<any>) {
        this._list = value;
        this._list.createShadow();
    }

    @Input() initialDisplayValue: string;
    @Input('id-attribute') idAttribute: string;
    @Input('name-attribute') nameAttribute: string;

    @Output() keyup = new EventEmitter();
    @Output() keydown = new EventEmitter();
    @Output() blur = new EventEmitter();
    @Output() focus = new EventEmitter();
    @Output() input = new EventEmitter();

    public suggestionText: String;
    public suggestionValue: String;
    public isValid: boolean;

    private inputIsFocused = false;
    private showSuggestions = false;
    private activeIndex = null;
    private displayValue = null;

    propegateChange = (_: any) => { }

    constructor(private zone: NgZone) {
        this.suggestionText = "";
        this.suggestionValue = "";
    }

    ngOnInit() {
        if(this.initialDisplayValue && this.value) {
            this.displayValue = this.initialDisplayValue
        }
        this.formControl.setValidators((control: FormControl) => {
            if(isNaN(control.value)
                && typeof control.value !== 'undefined'
                && typeof control.value !== 'object'
                && control.value !== null)
            {
                return { error: "No option selected." };
            }
            return null;
        })
    }

    getInputId() {
        if(!this.name || this.name.length === 0) {
            return void 0;
        }
        let inputId = "";
        if(this.inputField.nativeElement.form.name && this.inputField.nativeElement.form.name != "undefined") {
            inputId += this.inputField.nativeElement.form.name;
            inputId += "__";
        }
        else {
            inputId += "anonymous-form__";
        }
        inputId += this.name;
        return inputId;
    }

    get value() {
        return this._value;
    }

    set value(value) {
        if(isNaN(value) && this.inputField.nativeElement.value.length) { this._value = NaN; }
        else if(isNaN(value) && !this.inputField.nativeElement.value.length) { this._value = void 0; }
        else { this._value = value; }
        this.propegateChange(this._value);
    }

    writeValue(value: any) {
        if(typeof value !== 'undefined') {
            this.value = value;
            this.displayValue = this.displayValue || this.initialDisplayValue || this.value;
        }
    }

    registerOnChange(fn) {
        this.propegateChange = fn;
    }

    registerOnTouched(fn) {

    }

    handleChange($event) {
       
    }

    handleBlur($event) {
        this.inputIsFocused = false;
        this.zone.runOutsideAngular(() => {
            setTimeout(() => {
                this.zone.run(() => {
                    this.showSuggestions = false;
                })
            }, 400)
        });
        this.blur.emit($event);
    }

    handleFocus($event) {
        if(!this.value) {
            this.inputIsFocused = true;
            this.activeIndex = null;
            this.showSuggestions = this.list.length && this.inputField.nativeElement.value.length;
        }
        this.focus.emit($event);
    }

    handleKeyUp($event) {
        this.keyup.emit($event);
    }

    handleKeyDown($event) {
        switch($event.keyCode) {
            case 13:
                if(typeof this.activeIndex === 'number') {
                    $event.preventDefault();
                    this.applySelection(this.list[this.activeIndex]);
                }
                break;
            case 27:
                if(this.showSuggestions) {
                    $event.preventDefault();
                    this.showSuggestions = false;
                }
                break;
            case 38:
                $event.preventDefault();
                this.activeIndex = typeof this.activeIndex === 'number' ? 
                    ((this.activeIndex - 1 % this.list.length) + this.list.length) % this.list.length 
                    : this.list.length - 1;
                if(SUGGESTION_LIST_ITEM_HEIGHT * this.activeIndex > this.suggestionList.nativeElement.scrollTop + this.suggestionList.nativeElement.clientHeight) {
                    this.suggestionList.nativeElement.scrollTop = SUGGESTION_LIST_ITEM_HEIGHT * (this.activeIndex + 1) - this.suggestionList.nativeElement.clientHeight - 1;
                }
                else if(SUGGESTION_LIST_ITEM_HEIGHT * this.activeIndex < this.suggestionList.nativeElement.scrollTop) {
                    this.suggestionList.nativeElement.scrollTop = SUGGESTION_LIST_ITEM_HEIGHT * this.activeIndex;
                }
                break;
            case 40:
            case 9:
                $event.preventDefault();
                this.activeIndex = typeof this.activeIndex === 'number' ? (this.activeIndex + 1) % this.list.length : 0;
                if(SUGGESTION_LIST_ITEM_HEIGHT * this.activeIndex > this.suggestionList.nativeElement.scrollTop + this.suggestionList.nativeElement.clientHeight) {
                    this.suggestionList.nativeElement.scrollTop = SUGGESTION_LIST_ITEM_HEIGHT * (this.activeIndex + 1) - this.suggestionList.nativeElement.clientHeight - 1;
                }
                else if(SUGGESTION_LIST_ITEM_HEIGHT * this.activeIndex < this.suggestionList.nativeElement.scrollTop) {
                    this.suggestionList.nativeElement.scrollTop = SUGGESTION_LIST_ITEM_HEIGHT * this.activeIndex;
                }
                break;
            default:
                break;
        }
        this.keydown.emit($event);
    }

    handleInputEvent($event) {
        this.list.removePropertyFilter(this.nameAttribute);
        if($event.target.value.length) { this.list.addPropertyFilter(this.nameAttribute, $event.target.value); }
        this.showSuggestions = this.inputIsFocused && $event.target.value.length;
        this.value = NaN;
        this.input.emit($event);
    }

    applySelection(item) {
        this.value = item[this.idAttribute];
        this.displayValue = item[this.nameAttribute];
        this.showSuggestions = false;
        this.inputField.nativeElement.blur();
    }

    removeSelection() {
        this.value = void 0;
        this.displayValue = void 0;
        this.inputField.nativeElement.focus();
    }

}