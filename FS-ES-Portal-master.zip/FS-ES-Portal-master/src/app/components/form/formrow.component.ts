import { Component, Input, Output, EventEmitter, ViewChildren } from '@angular/core';

import { FsEsInput } from './input.component';

@Component({
    selector: 'fs-es-formrow',
    template: `
        <div class="form-row"><div class="wrapper"><ng-content></ng-content></div></div>
    `
})
export class FsEsFormrow {

    constructor() {

    }
}