import { Component, ViewChild, Input, ElementRef } from '@angular/core';
import { FormControl } from '@angular/forms';

@Component({
    selector: 'fs-es-hiddeninput',
    template: `
        <input #input
            [formControl]="control"
            [name]="name"
            type="hidden"
        />
    `
})
export class FsEsHiddenInput {

    @ViewChild('input') input: ElementRef;

    @Input() control: FormControl;
    @Input() name: string;

    public suggestionText: String;
    public suggestionValue: String;
    public isValid: boolean;

    public setValue(value: any) {
        this.input.nativeElement.value = value;
    }
}