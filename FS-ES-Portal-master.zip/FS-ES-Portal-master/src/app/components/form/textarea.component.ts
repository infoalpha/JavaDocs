import { Component, forwardRef, ViewChild, Input, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { FormControl, ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
    selector: 'fs-es-textarea',
    template: `
        <div [ngClass]="{ 'form-input': true, 'form-input__textarea': true, 'hasSuggestions': suggestionText.length }" [style.width]="width">
            <div class="label-wrapper">
                <label [ngClass]="{ 'required': required }" [for]="getInputId()">{{ label }}</label>
            </div>
            <div class="input-wrapper">
                <textarea #inputField
                    [id]="getInputId()"
                    [name]="name"
                    [ngClass]="{ 'primary': true, 'error': isValid === false }"
                    (change)="handleChange($event)"
                    (blur)="handleBlur($event)" 
                    (focus)="handleFocus($event)" 
                    (keyup)="handleKeyUp($event)"
                    (keydown)="handleKeyDown($event)" 
                    (input)="handleInputEvent($event)"
                    [attr.maxlength]="maxlength" 
                    [attr.minlength]="minlength"
                    ngDefaultControl
                ></textarea>
            </div>
        </div>
    `,
    styleUrls: ['textarea.component.css'],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => FsEsTextarea),
            multi: true
        }
    ],
    encapsulation: ViewEncapsulation.None
})
export class FsEsTextarea implements ControlValueAccessor {
    @ViewChild('inputField') inputField;

    private _value: any;

    @Input()
    private formControl: FormControl;

    @Input() control: FormControl;
    @Input() name: string;
    @Input() type: string;
    @Input() maxlength: string;
    @Input() minlength: string;
    @Input() label: string;
    @Input() validation: any;
    @Input() required: any;

    @Output() change = new EventEmitter();
    @Output() keyup = new EventEmitter();
    @Output() keydown = new EventEmitter();
    @Output() blur = new EventEmitter();
    @Output() focus = new EventEmitter();
    @Output() input = new EventEmitter();

    public suggestionText: String;
    public suggestionValue: String;
    public isValid: boolean;

    propegateChange = (_: any) => { }

    constructor() {
        this.suggestionText = "";
        this.suggestionValue = "";
    }

    getInputId() {
        if(!this.name || this.name.length === 0) {
            return void 0;
        }
        let inputId = "";
        if(this.inputField.nativeElement.form.name) {
            inputId += this.inputField.nativeElement.form.name;
            inputId += "__";
        }
        else {
            inputId += "anonymous-form__";
        }
        inputId += this.name;
        return inputId;
    }

    get value() {
        return this._value;
    }

    set value(val) {
        this._value = val;
        this.propegateChange(this._value);
    }

    writeValue(value: any) {
        if(typeof value !== 'undefined') {
            this.value = value;
            this.inputField.nativeElement.value = value;
        }
    }

    registerOnChange(fn) {
        this.propegateChange = fn;
    }

    registerOnTouched(fn) {

    }

    handleChange($event) {
        this.value = $event.target.value;
        this.change.emit($event);
        //this.validate($event.target.value);
    }

    handleBlur($event) {
        this.blur.emit($event);
    }

    handleFocus($event) {
        this.focus.emit($event);
    }

    handleKeyUp($event) {
        this.keyup.emit($event);
        //this.validate($event.target.value);
    }

    handleKeyDown($event) {
        this.keydown.emit($event);
    }

    handleInputEvent($event) {
        this.value = $event.target.value;
        this.input.emit($event);
    }
}