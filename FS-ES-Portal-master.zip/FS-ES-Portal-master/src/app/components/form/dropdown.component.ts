import { Component, ViewChild, Input, Output, EventEmitter, forwardRef, ViewEncapsulation } from '@angular/core';
import { FormControl, ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
    selector: 'fs-es-dropdown',
    template: `
        <div [ngClass]="{ 'form-input': true, 'form-input__dropdown': true, 'expanded': expanded }" [style.width]="width">
            <div class="label-wrapper">
                <label [ngClass]="{ 'required': required }" [for]="getInputId()">{{ label }}</label>
            </div>
            <div class="input-wrapper">
                <div class="select-wrapper">
                    <select #input
                        [id]="getInputId()"
                        [name]="name"
                        (change)="handleChange($event)"
                        (focus)="handleFocus($event)"
                        (blur)="handleBlur($event)"
                        [disabled]="disabled"
                        ngDefaultControl
                    >
                    <ng-content></ng-content>
                    </select>
                </div>
                <div class="form-input__dropdown-arrow"></div>
            </div>
        </div>
    `,
    styleUrls: [ './dropdown.component.css' ],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => FsEsDropdown),
            multi: true
        }
    ],
    encapsulation: ViewEncapsulation.None
})
export class FsEsDropdown implements ControlValueAccessor {

    private expanded: boolean;

    private _value: any;

    @ViewChild('input') input;

    @Input()
    private formControl: FormControl;

    @Input() control: FormControl;
    @Input() name: string;
    @Input() label: string;
    @Input() required: any;
    @Input() width: string;
    @Input() disabled:boolean;

    //@Output() change = new EventEmitter();
    @Output() blur = new EventEmitter();
    @Output() focus = new EventEmitter();

    propegateChange = (_: any) => { }

    constructor() {
        this.expanded = false;
    }

    getInputId() {
        if(!this.name || this.name.length === 0) {
            return void 0;
        }
        let inputId = "";
        if(this.input.nativeElement.form && typeof this.input.nativeElement.form.name !== 'undefined' && this.input.nativeElement.form.name !== 'undefined') {
            inputId += this.input.nativeElement.form.name;
            inputId += "__";
        }
        else {
            inputId += "anonymous-form__";
        }
        inputId += this.name;
        return inputId;
    }

    get value() {
        return this._value;
    }

    set value(val) {
        this._value = val;
        this.propegateChange(this._value);
    }

    writeValue(value: any) {
        if(typeof value !== 'undefined') {
            this.value = value;
        }
    }

    registerOnChange(fn) {
        this.propegateChange = fn;
    }

    registerOnTouched(fn) {

    }

    toggleExpanded() {
        this.expanded = !this.expanded;
    }

    handleChange($event) {
        //this.change.emit($event);
        this.value = $event.target.value;
        this.input.nativeElement.blur();
    }

    handleFocus($event) {
        this.toggleExpanded();
        this.focus.emit($event);
    }

    handleBlur($event) {
        this.toggleExpanded();
        this.blur.emit($event);
    }

}