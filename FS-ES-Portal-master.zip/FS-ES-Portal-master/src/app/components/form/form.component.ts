import { Component, OnInit, Input, Output, EventEmitter, Inject, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms'
import { Http, Response, RequestOptions, Headers } from '@angular/http';

import 'rxjs/add/operator/toPromise';

import { FsEsInput } from './input.component';
import { FsEsFormrow } from './formrow.component';

@Component({
    selector: 'fs-es-form',
    template: `
        <div class="m-form">
            <form [name]="name" [action]="action" [method]="method" [target]="target" [formGroup]="form" (ngSubmit)="formSubmit(form.value, form.valid)">
                <ng-content></ng-content>
            </form>
        </div>
    `,
    inputs: [ 'submit' ],
    styleUrls: [ './form.component.css' ],
    encapsulation: ViewEncapsulation.None
})
export class FsEsForm implements OnInit {

    @Input() name: string;
    @Input() action: string;
    @Input() method: string;
    @Input() target: string;
    @Input() headers: Headers;

    @Input() form: FormGroup;

    @Output() ngSubmit = new EventEmitter();
    @Output() success = new EventEmitter();
    @Output() error = new EventEmitter();
    
    public inputs;

    constructor(
        private http: Http
    ) {
        this.target = this.target || "_self";
    }

    public ngOnInit() {
    }

    formSubmit(formValue, formValid) {

        this.ngSubmit.emit();

        const method = this.method.toUpperCase();
        const action = this.action;

        const callback = (response) => {
            this.success.emit({ response: response, value: formValue });
        }
        const catchCallback = (response) => {
            this.error.emit({ response: response, value: formValue });
        }
   
        let options = new RequestOptions({ headers: this.headers, withCredentials: true })

        switch(method) {
            case "GET":
                this.http.get(action, options).toPromise()
                    .then(callback).catch(catchCallback);
            break;
            case "PUT":
                this.http.put(action, JSON.stringify(formValue), options).toPromise()
                    .then(callback).catch(catchCallback);
            break;
            case "DELETE":
                this.http.delete(action, options).toPromise()
                    .then(callback).catch(catchCallback);
            break;
            case "POST":
            default:
                this.http.post(action, JSON.stringify(formValue), options).toPromise()
                    .then(callback).catch(catchCallback);
            break;
        }
    }
}

function getInputArray(inputs: Array<any>) {
    const returnArray = [];
    for(let i = 0; i < inputs.length; i++) {
        if(inputs[i] instanceof FsEsFormrow) {
            const arr = getInputArray(inputs[i].formInputs)
            for(let i = 0; i < arr.length; i++) {
                returnArray.push(arr[i]);
            }
        }
        else {
            returnArray.push(inputs[i]);
        }
    }
    return returnArray;
}