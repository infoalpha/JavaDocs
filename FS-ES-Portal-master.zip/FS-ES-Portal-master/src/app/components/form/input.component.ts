import { Component, forwardRef, ViewChild, Input, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { FormControl, ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
    selector: 'fs-es-input',
    template: `
        <div [ngClass]="{ 'form-input': true, 'hasSuggestions': suggestionText.length }" [style.width]="width">
            <div class="label-wrapper">
                <label [ngClass]="{ 'required': required }" [for]="getInputId()">{{ label }}</label>
            </div>
            <div class="input-wrapper">
                <input #inputField
                    [id]="getInputId()"
                    [name]="name"
                    [ngClass]="{ 'primary': true, 'error': isValid === false }"
                    [type]="type || 'text'"
                    (change)="handleChange($event)"
                    (blur)="handleBlur($event)" 
                    (focus)="handleFocus($event)" 
                    (keyup)="handleKeyUp($event)"
                    (keydown)="handleKeyDown($event)" 
                    (input)="handleInputEvent($event)"
                    [attr.maxlength]="maxlength" 
                    [attr.minlength]="minlength"
                    [disabled]="disabled"
                    [required]="required"
                    ngDefaultControl
                />
                <input 
                    *ngIf="suggestionText.length" 
                    class="suggestion" 
                    type="text" 
                    disabled="disabled" 
                    [value]="suggestionText" 
                    [attr.data-value]="suggestionValue" 
                />
            </div>
        </div>
    `,
    styleUrls: [ './input.component.css' ],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => FsEsInput),
            multi: true
        }
    ],
    encapsulation: ViewEncapsulation.None
})
export class FsEsInput implements ControlValueAccessor {

    @ViewChild('inputField') inputField;

    private _value: any;

    @Input()
    private formControl: FormControl;

    @Input() control: FormControl;
    @Input() name: string;
    @Input() type: string;
    @Input() maxlength: string;
    @Input() minlength: string;
    @Input() label: string;
    @Input() validation: any;
    @Input() required: any;
    @Input() disabled: any;

    @Output() keyup = new EventEmitter();
    @Output() keydown = new EventEmitter();
    @Output() blur = new EventEmitter();
    @Output() focus = new EventEmitter();
    @Output() input = new EventEmitter();

    public suggestionText: String;
    public suggestionValue: String;
    public isValid: boolean;

    propegateChange = (_: any) => { }

    constructor() {
        this.suggestionText = "";
        this.suggestionValue = "";
    }

    getInputId() {
        if(!this.name || this.name.length === 0) {
            return void 0;
        }
        let inputId = "";
        if(this.inputField.nativeElement.form.name) {
            inputId += this.inputField.nativeElement.form.name;
            inputId += "__";
        }
        else {
            inputId += "anonymous-form__";
        }
        inputId += this.name;
        return inputId;
    }

        get value() {
        return this._value;
    }

    set value(val) {
        this._value = val;
        this.propegateChange(this._value);
    }

    writeValue(value: any) {
        if(typeof value !== 'undefined') {
            this.value = value;
            this.inputField.nativeElement.value = value;
        }
    }

    registerOnChange(fn) {
        this.propegateChange = fn;
    }

    registerOnTouched(fn) {

    }

    handleChange($event) {
       
    }

    handleBlur($event) {
        this.blur.emit($event);
    }

    handleFocus($event) {
        this.focus.emit($event);
    }

    handleKeyUp($event) {
        this.keyup.emit($event);
        //this.validate($event.target.value);
    }

    handleKeyDown($event) {
        this.keydown.emit($event);
    }

    handleInputEvent($event) {
        this.value = $event.target.value;
        this.input.emit($event);
    }

}