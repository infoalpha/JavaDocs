import { FsEsTable } from '../table.component';
import { FsEsTableRow } from '../tablerow.component';

const defaultParams = {
    identifier: void 0,
    zone: void 0
}

export default function(availableTable: FsEsTable, availableData: Array<any>, selectedTable: FsEsTable, selectedData: Array<any>, params: any = defaultParams) {

    params = Object.assign({}, defaultParams, params);

    availableData.createShadow();

    const availableRowChange = (row: FsEsTableRow) => {
        let identifier = {};
        if(params.identifier && row.data) {
            if(Array.isArray(identifier)) {
                (<Array<string>>identifier).forEach((key) => {
                    identifier[key] = row.data[key];
                })
            }
            else if(typeof params.identifier === 'string') {
                identifier[params.identifier] = row.data[params.identifier];
            }

            row.change.subscribe((e) => {
                let pushData = Object.assign({}, row.data);
                pushData["__filterId"] = availableData.addPropertyFilter(params.identifier, row.data[params.identifier], false);
                selectedData.push(pushData);
                const sRC = () => {
                    let r = selectedTable.rows.filter(aRow => { return aRow.data && aRow.data[params.identifier] === row.data[params.identifier] })[0];
                    selectedRowChange(r);
                }
                if(params.zone) {
                    params.zone.runOutsideAngular(() => {
                        setTimeout(() => { params.zone.run(sRC) }, 0)
                    });
                }
                else {
                    setTimeout(sRC, 0);
                }
            })
        }
    }

    const subscribeToAvailableRowChanges = () => {
        availableTable.rows.forEach(availableRowChange)
    }

    subscribeToAvailableRowChanges();

    const selectedRowChange = (row: FsEsTableRow) => {
        let identifier = {};
        if(params.identifier && row.data) {
            if(Array.isArray(identifier)) {
                (<Array<string>>identifier).forEach((key) => {
                    identifier[key] = row.data[key];
                })
            }
            else if(typeof params.identifier === 'string') {
                identifier[params.identifier] = row.data[params.identifier];
            }

            row.change.subscribe((e) => {
                availableData.removePropertyFilter(row.data["__filterId"]);
                let rowData = Object.assign({}, row.data);
                selectedData.removeItem(identifier || row.data);
                const aRC = () => {
                    let r = availableTable.rows.filter(aRow => { return aRow.data && aRow.data[params.identifier] === rowData[params.identifier] })[0];
                    availableRowChange(r);
                }
                if(params.zone) {
                    params.zone.runOutsideAngular(() => {
                        setTimeout(() => { params.zone.run(aRC) }, 0)
                    });
                }
                else {
                    setTimeout(aRC, 0);
                }
            })
        }
    }

    const subscribeToSelectedRowChanges = () => {
        selectedTable.rows.forEach(selectedRowChange)
        selectedData.forEach(d => {
            let id = availableData.addPropertyFilter(params.identifier, d[params.identifier], false);
            let query = {};
            query[params.identifier] = d[params.identifier];
            selectedData.getItem(query)["__filterId"] = id;
        });
    }

    subscribeToSelectedRowChanges();

}