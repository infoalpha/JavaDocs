import { FsEsTable } from '../table.component';

const TABLE_ROW_HEIGHT = 37;

const defaultParams = {
    count: 25,
    initialLoad: void 0,
    table: void 0,
    changeDetectorRef: void 0
}

export default function(inputArray: Array<any>, params: any = defaultParams) {
    params = Object.assign({}, defaultParams, params);

    let startIndex;
    let loadCount = 40;
    let expectedLength;

    const simpleDynamicLoad = () => {

        inputArray.subset(startIndex, loadCount);

        // else if(outputArray.length) {

        //     outputArray = inputArray.slice(0, expectedLength);
        // }
        // else
            //outputArray.splice(outputArray.length, 0, ...inputArray.slice(outputArray.length, outputArray.length + (outputArray.length ? params.count : params.initialLoad || params.count)));
    }
    if(!startIndex) {
        startIndex = 0;
        simpleDynamicLoad();
    }
    if(params.table) {
        let doScroll = true;
        const scrollFn = (e) => {
            doScroll = false;
            let nextStartIndex = Math.floor(e.target.scrollTop / TABLE_ROW_HEIGHT - 20);
            if(nextStartIndex < 0) { nextStartIndex = 0; }
            if(!startIndex) { startIndex = nextStartIndex; }
            // else if(nextStartIndex < startIndex + 5 && nextStartIndex > startIndex - 5 && startIndex >= 5 && startIndex <= inputArray.length - 6) {
            //     return;
            // }
            startIndex = nextStartIndex;
            console.log(e);
            //if(e.target.offsetHeight + e.target.scrollTop >= (outputArray.length - .2 * params.count) * TABLE_ROW_HEIGHT) {
            //    expectedLength = Math.floor((e.target.offsetHeight + e.target.scrollTop) / TABLE_ROW_HEIGHT + 1);
                simpleDynamicLoad();
                if(params.changeDetectorRef) {
                    params.changeDetectorRef.detectChanges();
                }
                //params.table.tBodyEl.style.marginBottom = (inputArray.length - outputArray.length) * TABLE_ROW_HEIGHT + "px";
                params.table.setFiller(startIndex * TABLE_ROW_HEIGHT, (inputArray.length - (startIndex + loadCount)) * TABLE_ROW_HEIGHT);
                // params.table.tBodyEl.style.marginBottom = (inputArray.length - (startIndex + loadCount)) * TABLE_ROW_HEIGHT + "px";
                // params.table.tBodyEl.style.paddingTop = startIndex * TABLE_ROW_HEIGHT + "px";
            //}
            setTimeout(() => { doScroll = true; }, 750)
            
        }
        params.table.onscroll = (e) => {
            if(doScroll) { scrollFn(e); }
        };
        // params.table.scroll.subscribe((e) => {
        //     console.log("expectedLength: " + Math.floor((e.target.offsetHeight + e.target.scrollTop) / TABLE_ROW_HEIGHT + 1));
        //     console.log("e.scrollTop: " + e.target.scrollTop);

        //     if(e.target.offsetHeight + e.target.scrollTop >= (outputArray.length - .2 * params.count) * TABLE_ROW_HEIGHT) {
        //         expectedLength = Math.floor((e.target.offsetHeight + e.target.scrollTop) / TABLE_ROW_HEIGHT + 1);
        //         simpleDynamicLoad();
        //         if(params.changeDetectorRef) {
        //             params.changeDetectorRef.detectChanges();
        //         }
        //         params.table.tBodyEl.style.marginBottom = (inputArray.length - outputArray.length) * TABLE_ROW_HEIGHT + "px";
        //     }
        // })
    }
    else {
        simpleDynamicLoad();
    }
}