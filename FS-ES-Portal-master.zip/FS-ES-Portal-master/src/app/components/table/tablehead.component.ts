import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'fs-es-th',
    template: `<span class="sort-header" (click)="handleSortHeaderClick($event)"><ng-content></ng-content></span><span *ngIf="activeSort" [ngClass]="{ 'sort-arrow': true, 'desc': sortOrder === 'DESC' }"></span>`
})
export class FsEsTh {

    @Input() sortProperties: Array<Object>;

    @Output() change = new EventEmitter();

    private activeSort: boolean;
    private sortOrder: string;
    private sortProperty: Object;
    private sortPropertyIndex: number;

    constructor() {
        this.activeSort = false;
    }
    
    handleSortHeaderClick($event) {
        let nextIndex;
        if(!this.sortPropertyIndex) {
            nextIndex = 0;
        }
        else if((this.sortPropertyIndex + 1) % this.sortProperties.length === 0) {
            nextIndex = void 0;
        }
        else {
            nextIndex = this.sortPropertyIndex + 1;
        }
        this.sortPropertyIndex = nextIndex;
        this.sortProperty = this.sortProperties[nextIndex];

        this.change.emit({
            sortProperty: this.sortProperties[nextIndex],
            sortOrder: this.sortOrder
        })
    }

    handleSortArrowClick($event) {
        this.sortOrder = this.sortOrder === "ASC" ? "DESC" : "ASC";

        this.change.emit({
            sortProperty: this.sortProperty,
            sortOrder: this.sortOrder
        })
    }
}