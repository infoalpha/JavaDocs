import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FsEsTable } from './table.component';
import { FsEsTableRow } from './tablerow.component';


@NgModule({
  declarations: [
    FsEsTable,
    FsEsTableRow
  ],
  imports: [
    CommonModule
  ],
  exports: [
    FsEsTable,
    FsEsTableRow
  ],
  entryComponents: [FsEsTableRow]
})
export class FsEsTableModule { }