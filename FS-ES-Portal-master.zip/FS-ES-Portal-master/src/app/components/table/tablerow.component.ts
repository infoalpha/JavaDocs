import { Component, ViewEncapsulation, Input, Output, EventEmitter, ViewChildren, ViewContainerRef, QueryList, ElementRef, AfterViewInit, AfterViewChecked, ChangeDetectorRef, NgZone, Renderer } from '@angular/core';
import { Observable } from 'rxjs/Observable';

@Component({
    selector: 'fs-es-tr',
    encapsulation: ViewEncapsulation.None,
    template: `
        <td *ngIf="_showSelection && isDataRow" (click)="handleClick($event)" [ngClass]="{ 'entity-check-container': true, 'entity-check-is-selected': _selected }"></td>
        <th *ngIf="_showSelection && !isDataRow" (click)="handleClick($event)" [ngClass]="{ 'entity-check-container': true, 'entity-check-is-selected': _selected }"></th>
        <ng-content></ng-content>
    `
    
})
export class FsEsTableRow implements AfterViewInit, AfterViewChecked {

    private _showSelection: boolean;

    public isDataRow: boolean = true;
    

    @Input('data') private _data: any;

    @Input('selected') _selected: boolean;

    @Input('fs-es-highlighted') fsEsHighlighted;

    @Output() change = new EventEmitter();

    constructor(private elRef:ElementRef, private cdRef: ChangeDetectorRef, private zone: NgZone, private renderer: Renderer) {
    }

    public get data() {
        return this._data;
    }

    public set data(value: any) {
        this._data = value;
    }

    set selected(value) {
        //this._selected = value;
        this.zone.run(() => this._selected = value);
        //this.cdRef.detectChanges();
    }

    get selected() {
        return this._selected;
    }

    @Input("show-selection")
    set showSelection(value) {
        this._showSelection = value;
        this.cdRef.detectChanges();
    }

    get showSelection() {
        return this._showSelection;
    }

    ngAfterViewInit() {
        const th = this.elRef.nativeElement.querySelectorAll('th');
        let isHeader = th.length ? true : false;

        this.isDataRow = !isHeader;
        this.cdRef.detectChanges();
    }

    ngAfterViewChecked() {
        this.renderer.setElementClass(this.elRef.nativeElement, 'fs-es-highlighted', false);
    }

    handleClick($event) {
        this.selected = !this.selected && typeof this.data === 'object';
        if(typeof this.data === 'object') {
            let e = { };
            if(this.isDataRow) {
                e = {
                    target: this,
                    selected: this.selected,
                    applyToAll: false,
                    data: this.data
                };
            }
            else {
                e = {
                    target: this,
                    selected: this.selected,
                    applyToAll: true
                }
            }
            this.change.emit(e);
        }
    }
}