import { Component, ViewEncapsulation, Input, Output, EventEmitter, ContentChild, ContentChildren, ViewChild, QueryList, ElementRef, forwardRef, OnInit, AfterContentInit, AfterViewInit, OnDestroy, ChangeDetectorRef, ViewContainerRef, NgZone } from '@angular/core';
import { FormControl, ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import {Observable} from 'rxjs/Observable';

import { FsEsTableRow } from './tablerow.component';

const SUGGESTION_FILTER_LIST_ITEM_HEIGHT = 33;

@Component({
    selector: 'fs-es-table',
    encapsulation: ViewEncapsulation.None,
    styleUrls: [
        './table.component.css'
    ],
    template: `
        <div #filterList *ngIf="filters" [ngClass]="{ 'm-table__filter-list': true, 'expanded': appliedFilters.length }">
            <ul>
                <li *ngFor="let filter of appliedFilters"><div class="wrapper"><div class="property-label">{{ filter.displayName }}</div>{{ filter.value }}<div class="remove" (click)="removeFilter(filter.id)"></div></div></li>
            </ul>
        </div>
        <div class="m-table">
            <div *ngIf="filters" [ngClass]="{ 'm-table__filter': true, 'minimized': options.minimizeFilter, 'expanded': options.minimizeFilter && filterExpanded }">
                <div class="wrapper">
                    <div class="input-wrapper">
                        <input #filterInputField
                            type="text"
                            (blur)="handleFilterBlur($event)" 
                            (focus)="handleFilterFocus($event)" 
                            (keyup)="handleFilterKeyUp($event)"
                            (keydown)="handleFilterKeyDown($event)" 
                            (input)="handleFilterInput($event)"
                            autocomplete="off"
                        />
                        <div #filterSuggestionList class="suggestion-list" *ngIf="showFilterSuggestions">
                            <ul>
                                <li *ngFor="let filter of filters; let i = index" [ngClass]="{ 'active': i === filterActiveIndex }" (click)="applyFilter(filter.property)"><span class="suggestion-property-label">{{ filter.displayName }}</span><span>{{ filterInputValue }}</span></li>
                            </ul>
                        </div>
                        <div class="search-icon" (click)="expandFilter()"></div>
                    </div>
                </div>
            </div>
            <div class="m-table__header__container">
                <div class="wrapper">
                    <table class="m-table__header">
                        <colgroup [innerHTML]="colGroupInnerHtml"></colgroup>
                        <thead *ngIf="headerData">
                            <fs-es-tr [show-selection]="showSelection">
                                <th *ngFor="let head of headerData; let i = index" [ngClass]="{ 'sortable': head.sorting }" (click)="sort(i)">{{ head.text }}<span *ngIf="head.sorting && head.sorting === sortProperty" [ngClass]="{ 'sort-label': true, 'desc': sortOrder === 'DESC' }"></span></th>
                            </fs-es-tr>
                        </thead>
                        <ng-content *ngIf="!headerData" select="thead"></ng-content>
                    </table>
                </div>
            </div>
            <div class="m-table__body__container">
                <div class="wrapper">
                    <div #tbodywrapper class="wrapper l-scrollable">
                        <div #fillerTop></div>
                        <table #tbody class="m-table__body">
                            <colgroup [innerHTML]="colGroupInnerHtml"></colgroup>
                            <ng-content select="tbody" *ngIf="true || !data && !template"></ng-content>
                        </table>
                        <div #fillerBottom></div>
                    </div>
                </div>
            </div>
        </div>
    `,
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => FsEsTable),
            multi: true
        }
    ]
})
export class FsEsTable implements ControlValueAccessor, OnInit, AfterContentInit, AfterViewInit, OnDestroy {

    @Input()
    private _selectedItems: Array<any> = [ ];

    @Input()
    private formControl: FormControl;

    @Input() enableSelection: boolean;

    @ContentChild('colGroup')
    private colGroup: ElementRef;

    private colGroupInnerHtml: string;

    @ContentChildren(FsEsTableRow) rows: QueryList<FsEsTableRow>;

    @ViewChild('thead')
    private tHead: ElementRef;

    @ViewChild('tbody')//, { read: ViewContainerRef })
    private tBody: ElementRef;

    public tBodyEl: HTMLTableElement;

    @ViewChild('tbodywrapper')//, { read: ViewContainerRef })
    private tBodyWrapper: ElementRef;

    public tBodyWrapperEl: HTMLDivElement;

    @ViewChild('fillerTop')
    private fillerTop: ElementRef;

    @ViewChild('fillerBottom')
    private fillerBottom: ElementRef;

    private tableData: Array<any> = [];

    private showSelection;

    private sortProperty: string | Array<string>;

    private sortOrder: string;

    private dataValue: Array<any>;

    @Output() dataChange = new EventEmitter();

    @Input()
    get data(): Array<any> {
        return this.dataValue;
    }

    set data(value: Array<any>) {
        if(this.dataValue !== value) {
            this.appliedFilters.forEach(f => this.removeFilter(f.id));
        }
        this.dataValue = value;
        this.dataValue.createShadow();
    }

    @Input("header-data") headerData: Array<any>;
    /*
        {
            text: "",
            sorting: [
                {
                    property: "",
                    displayName: ""
                }
            ]
        }
     */

    @Input() filters: Array<any>;
    /*
        {
            property: "",
            displayName: ""
        }
    */

    @Input() options: any;
    /*
        {
            minimizeFilter: false
        }
    */

    @ViewChild('filterInputField') filterInputField;
    @ViewChild('filterSuggestionList') filterSuggestionList;
    @ViewChild('filterList') filterList;
    private filterInputIsFocused;
    private showFilterSuggestions;
    private filterInputValue;
    private filterActiveIndex;
    private filterExpanded;
    private appliedFilters: Array<any> = [];

    @Input() template: Function;

    //@Output() scroll = new EventEmitter();

    public setFiller(top: number, bottom: number) {
        if(top) { this.fillerTop.nativeElement.style.height = top + "px"; }
        if(bottom) { this.fillerBottom.nativeElement.style.height = bottom + "px"; }
    }

    public set onscroll(value: any) {
        this.zone.runOutsideAngular(() => {
            this.tBodyWrapperEl.onscroll = value;
        })
    }

    handleChange = (value) => {
        // this.change.emit({
        //     target: {
        //         value: value
        //     }
        // })
        this.propegateChange(value);
    }

    propegateChange = (_: any) => { }

    // @Output() change = new EventEmitter();

    constructor(private zone: NgZone, private _vcr: ViewContainerRef, private cdr: ChangeDetectorRef) {
    }

    ngOnInit() {
    }

    ngAfterContentInit() {

        let showSelection = this.formControl instanceof FormControl || this.enableSelection;

        this.colGroupInnerHtml = (showSelection ? "<col width=\"35px\"/>" : "") + this.colGroup.nativeElement.innerHTML;
    
        if(showSelection) {
            this.rows.changes.subscribe((e) => {
                this.showRows(showSelection);
                this.handleChange(this._selectedItems);
            })
        }
        // this.rows.forEach((row) => {
        //     if(row.data._hidden) {
        //         row
        //     }
        // })
        this.showRows(showSelection);
    }

    ngAfterViewInit() {
        this.tBodyWrapperEl = this.tBodyWrapper.nativeElement;
        this.tBodyEl = this.tBody.nativeElement;
        //let rows: Array<FsEsTableRow> = this.rows.toArray().slice(1);
        // for(let i = 0; i < 20; i++) { 
        //     let factory = this._cfr.resolveComponentFactory(FsEsTableRow);
        //     let res = this._vcr.createComponent(factory, i, this.tBody.injector)
        // }
        // this.tBodyWrapperEl.onscroll = (e) => {
        //     let eTarget: HTMLElement = <HTMLElement>e.target;
        //     // if(eTarget.offsetHeight - eTarget.scrollTop <= this.tBodyEl.offsetHeight) {
        //         // this.scroll.emit({
        //         //     timeStamp: e.timeStamp,
        //         //     target: eTarget
        //         // });
        //     // }

        //     this.scroll.emit(e);
        // }
    }

    private showRows(showSelection) {
        this.tableData = [];
        this._selectedItems = [];
        this.rows.forEach((row, index) => {
            if(row.isDataRow) { this.tableData.push(row.data); }
            if(row.selected) { this._selectedItems.push(row.data); }
            row.showSelection = showSelection;
            if(showSelection) {
                row.change.subscribe(($event) => {
                    if($event.applyToAll) {
                        this.toggleSelectAll($event);
                    }
                    else if($event.selected) {
                        this.addItem($event.data);
                    }
                    else {
                        this.removeItem($event.data);
                    }
                })
            }
        })
    }

    writeValue(value: any) {
        this.clearAll();
        if(typeof value !== 'undefined') {
            this.addItem(value);
        }
    }

    registerOnChange(fn) {
        this.propegateChange = fn;
    }

    registerOnTouched(fn) {

    }

    get value() {
        return this._selectedItems;
    }

    set value(value: Object | Array<Object>) {
        this.writeValue(value);
    }

    sort(headerIndex: number) {
        let nextSortProperty = this.headerData[headerIndex].sorting;
        if(!nextSortProperty) {
            return;
        }
        let nextSortOrder;
        switch(this.sortOrder) {
            case 'ASC':
                nextSortOrder = 'DESC';
                break;
            case 'DESC':
                nextSortOrder = void 0;
                break;
            case void 0:
            case null:
            case '':
            default:
                nextSortOrder = 'ASC';
                break;
        }
        if(this.sortProperty !== nextSortProperty) {
            nextSortOrder = 'ASC';
        }
        if(nextSortOrder) {
            this.dataValue.sortByProperty(nextSortProperty, nextSortOrder);
            this.sortProperty = this.dataValue._sortProperty;
            this.sortOrder = this.dataValue._sortOrder;
        }
        else {
            this.dataValue.removeSort();
            this.sortProperty = void 0;
            this.sortOrder = void 0;
        }
    }

    handleFilterInput($event) {
        this.filterInputValue = $event.target.value;
        this.showFilterSuggestions = this.filterInputIsFocused && $event.target.value.length;
    }
    handleFilterKeyDown($event) {
        console.log($event);
        switch($event.keyCode) {
            case 13: // enter
                if(typeof this.filterActiveIndex === 'number') {
                    $event.preventDefault();
                    this.applyFilter(this.filters[this.filterActiveIndex].property);
                }
                break;
            case 27: // escape
                $event.preventDefault();
                if(this.showFilterSuggestions) {
                    this.showFilterSuggestions = false;
                }
                else
                    this.filterInputField.nativeElement.blur();
                break;
            case 38: // up arrow
                $event.preventDefault();
                this.filterActiveIndex = typeof this.filterActiveIndex === 'number' ? 
                    ((this.filterActiveIndex - 1 % this.filters.length) + this.filters.length) % this.filters.length 
                    : this.filters.length - 1;
                if(SUGGESTION_FILTER_LIST_ITEM_HEIGHT * this.filterActiveIndex > this.filterSuggestionList.nativeElement.scrollTop + this.filterSuggestionList.nativeElement.clientHeight) {
                    this.filterSuggestionList.nativeElement.scrollTop = SUGGESTION_FILTER_LIST_ITEM_HEIGHT * (this.filterActiveIndex + 1) - this.filterSuggestionList.nativeElement.clientHeight - 1;
                }
                else if(SUGGESTION_FILTER_LIST_ITEM_HEIGHT * this.filterActiveIndex < this.filterSuggestionList.nativeElement.scrollTop) {
                    this.filterSuggestionList.nativeElement.scrollTop = SUGGESTION_FILTER_LIST_ITEM_HEIGHT * this.filterActiveIndex;
                }
                break;
            case 40: // down arrow
            case 9: // tab
                $event.preventDefault();
                this.filterActiveIndex = typeof this.filterActiveIndex === 'number' ? (this.filterActiveIndex + 1) % this.filters.length : 0;
                if(SUGGESTION_FILTER_LIST_ITEM_HEIGHT * this.filterActiveIndex > this.filterSuggestionList.nativeElement.scrollTop + this.filterSuggestionList.nativeElement.clientHeight) {
                    this.filterSuggestionList.nativeElement.scrollTop = SUGGESTION_FILTER_LIST_ITEM_HEIGHT * (this.filterActiveIndex + 1) - this.filterSuggestionList.nativeElement.clientHeight - 1;
                }
                else if(SUGGESTION_FILTER_LIST_ITEM_HEIGHT * this.filterActiveIndex < this.filterSuggestionList.nativeElement.scrollTop) {
                    this.filterSuggestionList.nativeElement.scrollTop = SUGGESTION_FILTER_LIST_ITEM_HEIGHT * this.filterActiveIndex;
                }
                break;
            default:
                break;
        }
    }
    handleFilterKeyUp($event) {

    }
    handleFilterBlur($event) {
        this.filterInputIsFocused = false;
        if((!$event.target.value || !$event.target.value.length) && this.filterExpanded)
            this.filterExpanded = false;
        this.zone.runOutsideAngular(() => {
            setTimeout(() => {
                this.zone.run(() => {
                    this.showFilterSuggestions = false;
                })
            }, 400)
        });
    }
    handleFilterFocus($event) {
        this.filterInputIsFocused = true;
        this.filterActiveIndex = null;
        this.showFilterSuggestions = this.filters.length && this.filterInputField.nativeElement.value.length;
    }

    expandFilter() {
        if(!this.filterExpanded) {
            this.filterExpanded = true;
            this.filterInputField.nativeElement.focus();
        }
    }

    applyFilter(property: string) {
        let filterProperty = property;
        let filterDisplayName = this.filters.filter((f) => { return f.property === filterProperty; })[0].displayName;
        let filterValue = this.filterInputField.nativeElement.value;
        let filterId = this.dataValue.addPropertyFilter(filterProperty, filterValue);
        this.appliedFilters.push({ property: filterProperty, displayName: filterDisplayName, value: filterValue, id: filterId });
        this.filterInputField.nativeElement.value = '';
        this.showFilterSuggestions = false;
        this.filterActiveIndex = null;
        this.zone.runOutsideAngular(() =>{
            setTimeout(() => {
                let filterList = <HTMLElement>this.filterList.nativeElement.children.item(0);
                let filterItem = (<HTMLElement>filterList.children.item(filterList.children.length - 1));
                filterItem.classList.add('prop-check');
                let filterItemWidth = filterItem.offsetWidth;
                filterItem.classList.remove('prop-check');
                setTimeout(() => {
                    filterItem.style.width = filterItemWidth + 1 + "px";
                filterItem.classList.add('initialized');
                })
            }, 0)
        })
        // this.filterInputField.nativeElement.blur();
    }

    removeFilter(filterId) {
        let filterIndex = this.appliedFilters.getItem({ id: filterId }, true);
        let filterList = <HTMLElement>this.filterList.nativeElement.children.item(0);
        let filterItem = (<HTMLElement>filterList.children.item(filterIndex));
        filterItem.classList.remove('initialized');
        filterItem.style.width = "";
        filterItem.style.opacity = "";
        filterItem.classList.add('destroy');
        this.zone.runOutsideAngular(() => {
            setTimeout(() => {
                this.zone.run(() => {
                    this.dataValue.removePropertyFilter(filterId);
                    this.appliedFilters.removeItem({ id: filterId });
                })
            }, 300)
        })
    }

    /* not working */
    toggleSelectAll($event) {
        if($event.selected) {
            this._selectedItems = this.tableData;
        }
        else {
            this._selectedItems = [];
        }
        this.rows.forEach((row) => {
            row.selected = $event.selected;
        });
        this.handleChange(this._selectedItems);
    }

    addItem(item: any | Array<any>, _index?: number) {
        if(Array.isArray(item)) {
            for(let i = 0; i < item.length; i++) {
                this.addItem(item[i]);
            }
        }
        else {
            this._selectedItems.push(item);
            this.handleChange(this._selectedItems);
        }
    }

    clearAll() {
        this.removeItem(this._selectedItems);
    }

    /**
     * Removes an object or objects from the selectedItems array.
     * 
     * If a number is passed, the item at index [number] will be removed. If an object is passed, all items that contain the object will be removed.
     * Arrays of numbers and/or objects may be passed as well.
     */
    removeItem(query: number | Object | Array< number | Object >) {
        if(typeof query === 'number' && query < this._selectedItems.length) {
            this._selectedItems = this._selectedItems.splice(query, 1);
        }
        else if(typeof query === 'object') {
            for(let i = 0; i < this._selectedItems.length; i++) {
                let remove = true;
                const keys = Object.keys(query);
                for(let j = 0; j < keys.length; j++) {
                    let key = keys[j];
                    if(Array.isArray(query[key]) || typeof query[key] === 'object') {
                        console.log('array or object')
                        continue;
                    }
                    remove = remove && this._selectedItems[i][key] === query[key];
                    if(!remove) { break; }
                }
                if(remove) {
                    this._selectedItems.splice(i, 1);
                }
            }
        }
        else if(Array.isArray(query)) {
            for(let i = 0; i < query.length; i++) {
                this.removeItem(query[i]);
            }
        }
        this.handleChange(this._selectedItems);
    }

    ngOnDestroy() {
        this.rows.forEach((row) => {
            row.change.unsubscribe();
        });
    }

}