import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SubMenu } from './submenu.component';

@NgModule({
  declarations: [
      SubMenu
  ],
  imports: [
      CommonModule
  ],
  exports: [
      SubMenu
  ]
})
export class SubMenuModule { }