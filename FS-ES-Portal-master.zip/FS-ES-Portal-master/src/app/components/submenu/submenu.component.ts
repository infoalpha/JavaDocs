import { Component, ViewEncapsulation, Renderer } from '@angular/core';
import { AppState } from '../../app.service';

@Component({
    selector: 'sub-menu',
    encapsulation: ViewEncapsulation.None,
    styleUrls: [
        './submenu.component.css'
    ],
    template: `
        <div [ngClass]="{ 'm-global-subnav': true, 'hidden': this.appState.state.submenuIsHidden }">
            <ng-content></ng-content>
        </div>
    `
})
export class SubMenu {

    private lastScrollPosition: number;

    constructor(
        private renderer: Renderer,
        private appState: AppState
    ) {
        this.toggleHidden = this.toggleHidden.bind(this);
        this.renderer.listenGlobal('document', 'scroll', this.toggleHidden);
        this.lastScrollPosition = window.pageYOffset;
        this.appState.set('submenuIsHidden', false);
    }

    toggleHidden(e) {
        let newScrollPosition = window.pageYOffset;
        if(newScrollPosition > this.lastScrollPosition) {
            this.appState.set('submenuIsHidden', true);
        }
        else {
            this.appState.set('submenuIsHidden', false);
        }
        this.lastScrollPosition = newScrollPosition;
    }

}