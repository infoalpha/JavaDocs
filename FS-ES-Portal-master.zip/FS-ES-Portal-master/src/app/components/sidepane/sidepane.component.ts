import { Input, Component, AfterViewInit, ViewEncapsulation, ViewChild, ElementRef, NgZone, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { PathLocationStrategy, Location, LocationStrategy } from '@angular/common';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { AppState } from '../../app.service';

@Component({
    selector: 'side-pane',
    template:`
        <div #sidePane [ngClass]="{ 'm-global-sidepane' : true, 'expanded': expanded }" (click)="closeSidePane($event)" [style.left]="(this.appState.state.showNavigation ? '298px' : null)">
            <div #sidePaneContents class="m-global-sidepane__bar">
                <div class="wrapper">
                    <div class="m-global-sidepane__title"><ng-content select="header"></ng-content><span class="close-side-pane glyphicon glyphicon-remove" (click)="closeSidePane()"></span></div>
                    <div class="m-global-sidepane__content"><ng-content select="main"></ng-content></div>
                    <div class="m-global-sidepane__footer"><ng-content select="footer"></ng-content></div>
                </div>
            </div>
        </div>
    `,
    providers: [ Location, { provide: LocationStrategy, useClass: PathLocationStrategy } ],
    styleUrls: [ './sidepane.component.css' ],
    encapsulation: ViewEncapsulation.None
})
export class SidePane implements AfterViewInit {

    public expanded: boolean;

    private previousUrl: string;

    @ViewChild('sidePane') sidePane: ElementRef;

    constructor(public appState: AppState, private location: Location, private activatedRoute: ActivatedRoute, private router: Router, private zone: NgZone, private cdr: ChangeDetectorRef){
        this.expanded = false;
    }

    ngAfterViewInit() {
        this.zone.runOutsideAngular(() => {
            setTimeout(() => {
                this.zone.run(() => { this.expanded = true; });
            }, 0)
        })
    }

    closeSidePane($event?: any) {
        if(typeof $event === 'undefined' || typeof $event.target === 'undefined' || $event.target === this.sidePane.nativeElement) {
            let pathroots = this.activatedRoute.parent.pathFromRoot;
            let parentpath = [];
            pathroots.forEach(path => {
                let pathurl = '';
                path.url.forEach((url) => {
                    url.forEach(e => {
                        pathurl += e + '/';
                    });
                });
                parentpath.push(pathurl);
            });
            this.router.navigate([parentpath.join('')])
            this.location.replaceState(parentpath.join(''));
            if(this.location.path() === localStorage.getItem('previousRoute')) {
                this.location.back();
            }
        }
    }

}