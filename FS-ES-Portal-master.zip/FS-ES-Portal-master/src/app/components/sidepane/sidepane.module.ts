import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';
import { NgModule } from '@angular/core';

import { SidePane } from './sidepane.component';
import { SidePaneAccordion } from './sidepaneaccordion.component';
import { SidePaneSection } from './sidepanesection.component';

@NgModule({
  declarations: [
      SidePane,
      SidePaneAccordion,
      SidePaneSection
  ],
  imports: [
    CommonModule,
    HttpModule
  ],
  exports: [
      SidePane,
      SidePaneAccordion,
      SidePaneSection
  ]
})
export class SidePaneModule { }
