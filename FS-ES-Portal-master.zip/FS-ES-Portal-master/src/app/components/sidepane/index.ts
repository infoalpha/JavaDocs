export { SidePaneModule } from './sidepane.module';
export { SidePane } from './sidepane.component';