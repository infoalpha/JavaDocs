import { Component, OnDestroy, ContentChildren, QueryList, ElementRef, ViewEncapsulation, Renderer, AfterContentInit } from '@angular/core';

import { SidePaneSection } from './sidepanesection.component';

@Component({
    selector: 'side-pane-accordion',
    template:`
        <div class="m-global-sidepane__accordion">
            <ng-content></ng-content>
        </div>
    `,
    styleUrls: [ './sidepaneaccordion.component.css' ],
    encapsulation: ViewEncapsulation.None
})
export class SidePaneAccordion implements AfterContentInit, OnDestroy {

    public expanded: boolean;

    private expandedSection: SidePaneSection;

    @ContentChildren(SidePaneSection) sections: QueryList<SidePaneSection>;

    constructor( ){
        this.expanded = false;
    }

    ngAfterContentInit() {
        this.sections.forEach((section) => {
            if(!this.expandedSection) {
                section.expand();
                this.expandedSection = section;
            }
            else {
                section.collapse();
                this.expandedSection = section;
            }
            section.change.subscribe((e) => {
                this.sections.forEach(s => {
                    if(e.action === "EXPAND") {
                        if(section !== s) {
                            s.collapse()
                        }
                    }
                })
            })
        });
    }

    ngOnDestroy() {
        this.sections.forEach((section) => {
            section.change.unsubscribe();
        })
    }

}