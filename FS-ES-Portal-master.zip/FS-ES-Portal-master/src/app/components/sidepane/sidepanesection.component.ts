import { Component, Input, Output, EventEmitter, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';

@Component ({
    selector: 'side-pane-section',
    encapsulation: ViewEncapsulation.None,
    template: `
        <div class="l-side-pane__section-header" (click)="toggleExpanded()"><div class="wrapper">{{ header }}</div></div>
        <div class="l-side-pane__section-body">
            <div class="wrapper">
                <div class="content">
                <ng-content></ng-content>
                </div>
            </div>
        </div>
    `,
    host: { '[class.expanded]': '_expanded' }
})
export class SidePaneSection {

    @Input() header: string;
    @Input() name: string;

    @Input() expanded: boolean | string;

    @Output() change = new EventEmitter();

    private _expanded: boolean;

    constructor(private cdRef: ChangeDetectorRef) {
        this._expanded = this.expanded === true || this.expanded === "true";
    }

    public expand() {
        this._expanded = true;
        this.cdRef.detectChanges();
    }

    public collapse() {
        this._expanded = false;
        this.cdRef.detectChanges();
    }

    toggleExpanded() {
        this.change.emit({
            name: this.name,
            action: this._expanded ? "COLLAPSE" : "EXPAND"
        });
        this._expanded = !this._expanded;
    }

    public isExpanded() {
        return this._expanded;
    }

}