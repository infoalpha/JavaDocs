// Angular 2
import {
  enableDebugTools,
  disableDebugTools
} from '@angular/platform-browser';
import {
  ApplicationRef,
  enableProdMode
} from '@angular/core';
// Environment Providers
let PROVIDERS: any[] = [
  // common env directives
];

let VARS: any = {
  defaultHeaders: {
    "Accept": "application/json",
    "Content-Type": "application/json",
    "Api-Key": "RTM"
  },
  ssoRedirectFn: (error, env, url, appState) => {
      let errorData = error.json();
      if (error.status === 307 && errorData.id == 200008) {
          var redirectUrl = errorData.developerText;
          var currentUrl = url;
          // if(appState && appState.get('appModule')) {
          //   let appModuleAsString;
          //   try {
          //     appModuleAsString = JSON.stringify(appState.get('appModule'));
          //     localStorage.setItem('FsEsPortalAppModule', appModuleAsString);
          //   }
          //   catch(e) { }
          // }
          localStorage.setItem("SSORedirect", "true");
          window.location.href =
              redirectUrl +
              encodeURIComponent(
                  env.ssoRedirectUri["TargetResource"] + 
                  currentUrl
              );
      }
  }
  // common env variables
}

let _decorateModuleRef = <T>(value: T): T => { return value; };

if ('production' === ENV) {
  enableProdMode();

  // Production
  _decorateModuleRef = (modRef: any) => {
    disableDebugTools();

    return modRef;
  };

  PROVIDERS = [
    ...PROVIDERS,
    // custom providers in production
  ];
  VARS = Object.assign(VARS, {
    baseAPIPath: "http://fs-portal.clouddqt.capitalone.com:11400/profile-mgmt-web/tools",
    ssoRedirectUri: {
      _base: 'https://webaccessdev.kdc.capitalone.com/pf/adapter2adapter.ping',
      // client_id: 'ThickClientOAuthwPingSSO4DREAMPORTAL',
      TargetResource: 'http://fs-portal.clouddqt.capitalone.com'
    }
  });

} else {

  VARS = Object.assign(VARS, {
    baseAPIPath: "http://localhost:9090/profile-mgmt-web/tools",
    defaultHeaders: Object.assign({}, VARS.defaultHeaders, {
      "Api-Key": "RTM",
      "User-Id": "TEST"
    }),
    ssoRedirectUri: {
      _base: 'https://webaccessdev.kdc.capitalone.com/pf/adapter2adapter.ping',
      // client_id: 'ThickClientOAuthwPingSSO4DREAMPORTAL',
      TargetResource: 'http://fs-portal.clouddqt.capitalone.com'
    }
  });

  _decorateModuleRef = (modRef: any) => {
    const appRef = modRef.injector.get(ApplicationRef);
    const cmpRef = appRef.components[0];

    let _ng = (<any> window).ng;
    enableDebugTools(cmpRef);
    (<any> window).ng.probe = _ng.probe;
    (<any> window).ng.coreTokens = _ng.coreTokens;
    return modRef;
  };

  // Development
  PROVIDERS = [
    ...PROVIDERS,
    // custom providers in development
  ];

}

export const decorateModuleRef = _decorateModuleRef;

export const ENV_PROVIDERS = [
  ...PROVIDERS
];

export const ENV_VARS = VARS;
