#!/bin/sh
cd /prod/msp/app/dock_apps/access_portal

npm run build:prod
npm run server:prod
