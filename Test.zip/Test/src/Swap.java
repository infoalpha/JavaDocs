import java.util.*;
  
public class Swap
{
   public static void main(String args[])
   {
       
      int a=10,b=20;
      int temp;
       
     /* Scanner bf = new Scanner(System.in);
       
      System.out.print("Input first number (a): ");
      a=bf.nextInt();
      System.out.print("Input second number(b): ");
      b=bf.nextInt();*/
       
 
      System.out.println("Before Swapping\na = "+a+"\nb = "+b);
  
      temp = a;
      a = b;
      b = temp;
  
      System.out.println("After Swapping\na = "+a+"\nb = "+b);
   }
}