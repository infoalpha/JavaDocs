import java.util.NoSuchElementException;

public class QueueExample {

	protected int Queue[];
	protected int front, rear, size,len;
	
	//Constructor
	public QueueExample(int n){
		size=n;
		len=0;
		Queue = new int[size];
		front=-1;
		rear=-1;
	}
	
	//to check if Queue is empty
	public boolean isEmpty(){
		return front == -1;
	}
	
	//to check if Queue is full
	public boolean isFull(){
	return front ==0 && rear ==size-1;
	}
	
	//to get size of Queue
	public int getSize(){
		return len;
	}
	
	
	//to check front element of Queue
	public int peek(){
		if(isEmpty()){
			throw new NoSuchElementException("Underflow Exception");
		}
		return Queue[front];
	}
	
	//to insert element to Queue
	public void insert(int i){
		if(rear == -1){
			front = 0;
			rear = 0;
			Queue[rear] = i;
		}else if(rear+1 >=size)
			throw new IndexOutOfBoundsException("Overflow exception");
		else if(rear+1 <size)
			Queue[++rear] = i;
		len++;
	}
	
	//to remove element from Queue
	public int remove(){
		if(isEmpty()){
			throw new NoSuchElementException("Underflow exception");
		}
		else{
			len--;
			int ele = Queue[front];
			if(front == rear){
				front =-1;
				rear =-1;
			}
			else
				front++;
			return ele;
		}
	}
	
	public void display(){
		 System.out.print("\nQueue = ");
		 if(len==0){
			 System.out.print("Empty\n");
	            return ;
		 }
		 for(int i=front;i<=rear;i++){
			 System.out.print(Queue[i]+" ");
		        System.out.println();     
		 }
	}
	
}
