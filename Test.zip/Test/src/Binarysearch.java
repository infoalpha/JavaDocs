
public class Binarysearch {
public static void binarySearch(int arr[], int first, int last, int key){
	
	int mid = (first+last)/2;
	
	
}
}
