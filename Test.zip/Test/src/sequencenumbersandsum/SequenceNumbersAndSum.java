package sequencenumbersandsum;

import java.util.*;

public class SequenceNumbersAndSum
{
	public static void main(String[] args)
	{
		// 1.
		ArrayList<ArrayList<Integer>> res = printNonIncreasingSequenece(5);
		// printUtil(res);

		// 2.
		generate(3);
	}

	// 1. Not good.
	static ArrayList<ArrayList<Integer>> printNonIncreasingSequenece(int x)
	{
		if (x == 1)
		{
			ArrayList<ArrayList<Integer>> list = new ArrayList<ArrayList<Integer>>();
			ArrayList<Integer> newEle = new ArrayList<Integer>();
			newEle.add(1);
			list.add(newEle);

			return list;
		}
		else
		{
			ArrayList<ArrayList<Integer>> lastList = printNonIncreasingSequenece(x - 1);
			ArrayList<ArrayList<Integer>> newList = new ArrayList<ArrayList<Integer>>();

			ArrayList<Integer> newEle = new ArrayList<Integer>();
			newEle.add(x);
			newList.add(newEle);

			for (ArrayList<Integer> list : lastList)
			{
				ArrayList<Integer> newElement = new ArrayList<Integer>();
				newElement.addAll(list);
				newElement.add(1);
				newList.add(newElement);

				// add 1 to element
				for (int i = 0; i < list.size(); i++)
				{
					ArrayList<Integer> addOneOnElement = new ArrayList<Integer>();

					if (i == 0)
					{
						addOneOnElement.addAll(list);
						int tmp = (int)list.get(i);
						addOneOnElement.remove(i);
						addOneOnElement.add(i, tmp + 1);
						newList.add(addOneOnElement);
					}
					else
					{
						if ((int)list.get(i) + 1 <= list.get(i - 1))
						{
							addOneOnElement.addAll(list);
							int tmp2 = (int)list.get(i) + 1;
							addOneOnElement.remove(i);
							addOneOnElement.add(i, tmp2);
							newList.add(addOneOnElement);
						}
						else
						{
							continue;
						}
					}
				}
			}

			return newList;
		}
	}

	static void printUtil(ArrayList<ArrayList<Integer>> list)
	{
		HashSet<String> set = new HashSet<String>();

		for (ArrayList<Integer> subList : list)
		{
			StringBuffer sb = new StringBuffer();
			for (Integer i : subList)
			{
				sb.append((int)i + " ");
			}

			set.add(sb.toString());
		}

		for (String s: set)
		{
			System.out.println(s);
		}
	}

	// 2. Good.
	static void generate(int x)
	{
		int[] arr = new int[x];
		generateUtil(x, arr, 0, 0);
	}

	static void generateUtil(int x, int[] arr, int curSum, int index)
	{
		if (x == curSum)
		{
			printResult(arr, index);
		}

		int num = 1;

		while (curSum + num <= x && (index == 0 || arr[index - 1] >= num))
		{
			arr[index] = num;

			generateUtil(x, arr, curSum + num, index + 1);

			num++;
		}
	}

	static void printResult(int[] arr, int index)
	{
		for (int i = 0; i < index; i++)
		{
			System.out.println(arr[i]);
		}

		System.out.println("----------------------");
	}
}