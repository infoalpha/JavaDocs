import java.util.Scanner;

public class PalindromeStringExample {
	/*public static void main(String[] args){
		String originalString ="";
		String reverseString="";
		
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a string to check if it is a palindrome");
		originalString = input.nextLine();
		
		int length = originalString.length();
		
		for(int i =length-1;i>=0;i--)
			reverseString= reverseString+originalString.charAt(i);
			
			if(originalString.equals(reverseString))
				System.out.println("Entered String is a Palindrome");
			else
				System.out.println("Entered String is Not Palindrome");
			
		
		
	}*/
	
	public static void main(String [] args){

		PalindromeStringExample pn = new PalindromeStringExample();

		if(pn.isPalindrome("ABBA")){

		System.out.println("Palindrome");

		} else {

		System.out.println("Not Palindrome");

		}

		}

		public boolean isPalindrome(String original){
			
			String reverseString="";

		/*int i = original.length()-1;

		int j=0;

		while(i > j){

		if(original.charAt(i) != original.charAt(j)){

		return false;

		}

		i-- ;

		j++;

		}*/
			
			for(int i =original.length()-1;i>=0;i--)
				if(original.equals(reverseString)){
					System.out.println("Entered String is a Palindrome");

					return false;

					}


		return true;

		}

		}


