package com.duplicate;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;


public class DuplicateElements {
	//Using ArrayList and HasSet
/*	public static void main(String[] arr) {

	    int [] intarray = {1,2,3,2};

	    sort(intarray);
	}
	public static void sort(int [] arr){
		ArrayList<Integer> list = new ArrayList<Integer>();
		for (int i:arr) {
			list.add(i);
		}
		Set<Integer>set =new HashSet<Integer>(list);
		for(Integer integer :set){
			System.out.println(integer+" ");
		}
	}*/
	
	//Using Arrays
	public static void printDistinctElements(int[] arr){
        
        for(int i=0;i<arr.length;i++){
            boolean isDistinct = false;
            for(int j=0;j<i;j++){
                if(arr[i] == arr[j]){
                    isDistinct = true;
                    break;
                }
            }
            if(!isDistinct){
                System.out.print(arr[i]+" ");
            }
        }
    }
     
    public static void main(String a[]){
         
        int[] nums = {5,2,7,2,4,7,8,2,3};
        DuplicateElements.printDistinctElements(nums);
    }
}