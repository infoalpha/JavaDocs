package com.largestnumberinarray;

public class LargestNumberInArray {
public static int getSecondLargest(int a[], int total){
	int temp;
	for(int i = 0;i<total;i++){
		for(int j=i+1;j<total;j++){
			System.out.println("Initial a[i]:::"+a[i]);
			System.out.println("Initial a[j]:::"+a[j]);

			if(a[i] > a[j]){
				temp = a[i];
				System.out.println("Initial temp:::"+temp);

				a[i] = a[j];
				System.out.println("later a[i]:::"+a[i]);
				a[j] = temp;
				System.out.println("later a[j]:::"+a[j]);
				
			}
		}
	}
	return a[total-2];//2nd largest
	
}

public static void main(String[] args){
	int a[]={1,2,5,6,3,2};  
	
	System.out.println("Second Largest: "+getSecondLargest(a,6));  
 }
}
