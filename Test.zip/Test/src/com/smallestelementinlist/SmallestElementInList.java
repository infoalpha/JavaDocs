package com.smallestelementinlist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SmallestElementInList {

	public static int getSmallestElement(int a[], int total){
		int temp;
		//using Array
		/*for(int i=0;i<total;i++){
			for(int j=i+1;j<total;j++){
				if (a[i] > a[j]){
					temp = a[i];
					a[i] = a[j];
					a[j] = temp;
				}
			}
		}
		return a[1];*/
		//Using list
		List<Integer> list = new ArrayList<Integer>();
		list.add(1);
		list.add(2);
		list.add(3);
		Collections.sort(list);
		
		int element = list.get(1);
		
		return element;
	}
	
	public static void main(String[] args){
		int a[] = {1,2,3,4,5,6};
		System.out.println("Second smallest element:::"+getSmallestElement(a, 6));
	}
}
