package com.reversString;

public class ReverseString {
	static String reverseStr = "";
	public static String reverseString(String str){
		if(str.length() == 1){
			return str;
		}else{
			reverseStr = reverseStr + str.charAt(str.length()-1) + reverseString(str.substring(0, str.length()-1));
//			reverseStr = reverseStr + str.charAt(str.length()-1);
		}
		return reverseStr;
	}

	public static void main(String[] args){
		System.out.println("Reverse String:::"+reverseString("Vijay"));
		
	}
}
