import java.util.Scanner;

/* Class QueueImplement  */
public class QueueTest
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);  
        
        System.out.println("Queue test");
        System.out.println("Enter size of Queue");
        
        int n= scan.nextInt();
        
        QueueExample queueExample = new QueueExample(n);
        
        //perform Queue operations
        char ch;
        do{
        	System.out.println("\nQueue Operations");
            System.out.println("1. insert");
            System.out.println("2. remove");
            System.out.println("3. peek");
            System.out.println("4. check empty");
            System.out.println("5. check full");
            System.out.println("6. size");
            int choice = scan.nextInt();
            switch(choice){
            case 1:
            	System.out.println("Enter element to insert");
            	try{
            		queueExample.insert(scan.nextInt());
            	} catch(Exception e)
                {
                    System.out.println("Error : " +e.getMessage());
                }                         
                break;
            case 2 : 
                try
                {
                    System.out.println("Removed Element = "+queueExample.remove());
                }
                catch(Exception e)
                {
                    System.out.println("Error : " +e.getMessage());
                }
                break;                         
            case 3 : 
                try
                {
                    System.out.println("Peek Element = "+queueExample.peek());
                }
                catch(Exception e)
                {
                    System.out.println("Error : "+e.getMessage());
                }
                break;                            
            case 4 : 
                System.out.println("Empty status = "+queueExample.isEmpty());
                break;                
            case 5 : 
                System.out.println("Full status = "+queueExample.isFull());
                break;                          
            case 6 : 
                System.out.println("Size = "+ queueExample.getSize());
                break;                         
            default : System.out.println("Wrong Entry \n ");
                break;
            }
            
            //display Queue
            queueExample.display();
            System.out.println("\nDo you want to continue (Type y or n) \n");
            ch = scan.next().charAt(0);
        }while(ch =='Y' || ch=='y');
    }    
}