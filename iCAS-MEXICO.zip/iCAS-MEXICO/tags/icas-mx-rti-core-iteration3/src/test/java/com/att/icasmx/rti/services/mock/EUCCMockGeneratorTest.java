package com.att.icasmx.rti.services.mock;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.att.icasmx.rti.core.data.AdditionalDocumentation;
import com.att.icasmx.rti.core.data.EUCC_RSP;

public class EUCCMockGeneratorTest {
	
	@Test
	public void testCreditClassEUCCMock() {
		EUCCMockGenerator euccmockGenerator = new EUCCMockGenerator();		
		String dealerName ="XROCK-CREDIT:HH";
		EUCC_RSP euccresp = euccmockGenerator.generateEUCCMock(dealerName);
		assertEquals("HH", euccresp.getCreditClass());
		assertEquals("CA", euccresp.getStatus());		
	}
	
	
	@Test
	public void testAlertTypeEUCCMock() {
		EUCCMockGenerator euccmockGenerator = new EUCCMockGenerator();	
		String dealerName = "XROCK-ALERT:F1";
		EUCC_RSP euccresp = euccmockGenerator.generateEUCCMock(dealerName);
		assertEquals("AR", euccresp.getStatus());
	}
	
	
	@Test
	public void testDEBTTypeEUCCMock() {
		EUCCMockGenerator euccmockGenerator = new EUCCMockGenerator(); 		
		String dealerName ="XROCK-DEBT:200";
		EUCC_RSP euccresp = euccmockGenerator.generateEUCCMock(dealerName);
		assertEquals("200", euccresp.getOutstandingDebtMinAmountDue());
	}
	
	
	@Test
	public void testDocTypeEUCCMock() {
		EUCCMockGenerator euccmockGenerator = new EUCCMockGenerator(); 		
		String dealerName = "XROCK-DOC:OOW";
		EUCC_RSP euccresp = euccmockGenerator.generateEUCCMock(dealerName);
		assertEquals("Out-Of-Wallet Documentation missing", ((AdditionalDocumentation)euccresp.getAdditionalDoc().get(0)).getReasonText_en());
		assertEquals(null, euccresp.getWorkListIndicator());
	}
	
	
	
	@Test
	public void testDocAndDebtTypeEUCCMock() {
		EUCCMockGenerator euccmockGenerator = new EUCCMockGenerator();		
		String dealerName ="XROCK-DOC:OOW-DEBT:500";
		EUCC_RSP euccresp = euccmockGenerator.generateEUCCMock(dealerName);
		assertEquals("Out-Of-Wallet Documentation missing", euccresp.getAdditionalDoc().get(0).getReasonText_en());
		assertEquals("500", euccresp.getOutstandingDebtMinAmountDue());
		assertEquals("DBTFR",euccresp.getStatusReason());
		assertEquals("AR",euccresp.getStatus());
	}

	@Test
	public void testErrorTypeEUCCMock() {
		EUCCMockGenerator euccmockGenerator = new EUCCMockGenerator(); 		
		String dealerName ="XROCK-ERROR";
		EUCC_RSP euccresp = euccmockGenerator.generateEUCCMock(dealerName);
		assertEquals("999", euccresp.getErrorCode());
		
		String dealerName1 ="XMOCK-INPUTERR";
		EUCC_RSP euccresp1 = euccmockGenerator.generateEUCCMock(dealerName1);
		assertEquals("100", euccresp1.getErrorCode());
		
	}
	
	@Test
	public void testErrorTypeEUCCDocMock() {
		EUCCMockGenerator euccmockGenerator = new EUCCMockGenerator(); 		
		String dealerName ="XMOCK-DOC:PCF-DEBT:400";
		EUCC_RSP euccresp = euccmockGenerator.generateEUCCMock(dealerName);
		assertEquals("100", euccresp.getErrorCode());
				
	}
	
	


}
