package com.att.icasmx.workflow;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;
import com.att.icasmx.base.BaseSpringTest;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowException;
import com.att.icasmx.rti.workflow.WorkflowManager;
import com.att.icasmx.rti.workflow.WorkflowResult;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXCreditCheckRequest;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXCreditCheckResponse;

public class EUCCWorkflowTest extends BaseSpringTest {
	private static Logger  logger = LogManager.getLogger(EUCCWorkflowTest.class.getName());	
	
	@Test
	public void testEUCCValidDebtInput() {
		String workflowId = "ExecuteUnifiedCreditCheck";
		
		// run workflow and obtain the result object
		WorkflowResult resultData = null;
		WorkflowManager workflowManager = (WorkflowManager) super.getBean("workflowManager");
		ExecuteUnifiedMXCreditCheckRequest dummyObj = new ExecuteUnifiedMXCreditCheckRequest();
		dummyObj.setDealerName("XMOCK-DEBT:400");
				
		try {
		
			resultData = workflowManager
					.execute(
							WorkflowConstants.EXECUTE_UNIFIED_CREDIT_CHECK_WORKFLOW_ID,
							WorkflowConstants.EXECUTE_UNIFIED_CREDIT_CHECK_REQUEST,
							dummyObj);
			ExecuteUnifiedMXCreditCheckResponse euccschemresp = (ExecuteUnifiedMXCreditCheckResponse) resultData.getResult();			
			if(null != euccschemresp.getOutstandingDebt() && euccschemresp.getOutstandingDebt().size() >0 ){
			assertEquals(400, euccschemresp.getOutstandingDebt().get(0).getMinimumAmountDue().intValue());
			assertEquals(400, euccschemresp.getOutstandingDebt().get(0).getPastDueAmount().intValue());			
			}
			else
			{
				assertFalse("Debt Value not found in Output",true);
			}
			
		} catch (WorkflowException e) {
			logger.debug("inside workflow exception");
			e.printStackTrace();
		}	
		
	}

	
	@Test
	public void testEUCCInvalidDocInput() {
		
		// run workflow and obtain the result object
		WorkflowResult resultData = null;
		WorkflowManager workflowManager = (WorkflowManager) super.getBean("workflowManager");
		ExecuteUnifiedMXCreditCheckRequest dummyObj = new ExecuteUnifiedMXCreditCheckRequest();
		dummyObj.setDealerName("XMOCK-DOC:OTS");
		
		try {
		
			resultData = workflowManager
					.execute(
							WorkflowConstants.EXECUTE_UNIFIED_CREDIT_CHECK_WORKFLOW_ID,
							WorkflowConstants.EXECUTE_UNIFIED_CREDIT_CHECK_REQUEST,
							dummyObj);
			ExecuteUnifiedMXCreditCheckResponse euccschemresp = (ExecuteUnifiedMXCreditCheckResponse) resultData.getResult();
			assertEquals("100", euccschemresp.getError().get(0).getErrorCode());
		} catch (WorkflowException e) {
			logger.debug("inside workflow exception");
			e.printStackTrace();
		}	
		
	}
	
	
	@Test
	public void testEUCCInvalidClassInput() {
		
		// run workflow and obtain the result object
		WorkflowResult resultData = null;
		WorkflowManager workflowManager = (WorkflowManager) super.getBean("workflowManager");
		ExecuteUnifiedMXCreditCheckRequest dummyObj = new ExecuteUnifiedMXCreditCheckRequest();
		dummyObj.setDealerName("XMOCK-CREDIT:OTS");
		
		try {
		
			resultData = workflowManager
					.execute(
							WorkflowConstants.EXECUTE_UNIFIED_CREDIT_CHECK_WORKFLOW_ID,
							WorkflowConstants.EXECUTE_UNIFIED_CREDIT_CHECK_REQUEST,
							dummyObj);
			ExecuteUnifiedMXCreditCheckResponse euccschemresp = (ExecuteUnifiedMXCreditCheckResponse) resultData.getResult();
			assertEquals("100", euccschemresp.getError().get(0).getErrorCode());
		} catch (WorkflowException e) {
			logger.debug("inside workflow exception");
			e.printStackTrace();
		}	
		
	}
	
	
	@Test
	public void testEUCCInvalidInput() {
		
		// run workflow and obtain the result object
		WorkflowResult resultData = null;
		WorkflowManager workflowManager = (WorkflowManager) super.getBean("workflowManager");
		ExecuteUnifiedMXCreditCheckRequest dummyObj = new ExecuteUnifiedMXCreditCheckRequest();
		dummyObj.setDealerName("XMOCK-DOC5965565");
		
		try {
		
			resultData = workflowManager
					.execute(
							WorkflowConstants.EXECUTE_UNIFIED_CREDIT_CHECK_WORKFLOW_ID,
							WorkflowConstants.EXECUTE_UNIFIED_CREDIT_CHECK_REQUEST,
							dummyObj);
			ExecuteUnifiedMXCreditCheckResponse euccschemresp = (ExecuteUnifiedMXCreditCheckResponse) resultData.getResult();
			assertEquals("100", euccschemresp.getError().get(0).getErrorCode());
		} catch (WorkflowException e) {
			logger.debug("inside workflow exception");
			e.printStackTrace();
		}	
		
	}
	
	
	public void setUp() throws Exception {
		//super.setContextLocation(springConfigFiles);
		super.setUp();
	}
	public void tearDown() throws Exception {
		super.tearDown();
	}
}
