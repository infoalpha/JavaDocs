package com.att.icasmx.workflow;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;

import com.att.icasmx.base.BaseSpringTest;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowException;
import com.att.icasmx.rti.workflow.WorkflowManager;
import com.att.icasmx.rti.workflow.WorkflowResult;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXCreditCheckRequest;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXCreditCheckResponse;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXPolicyCheckRequest;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXPolicyCheckResponse;
import com.att.icasmx.rti.ws.SubmitUnifiedMXCreditUpdateResponse;
import com.att.icasmx.rti.ws.SubmitUnifiedMXPolicyUpdateRequest;
import com.att.icasmx.rti.ws.SubmitUnifiedMXPolicyUpdateResponse;

public class SUPUWorkflowTest extends BaseSpringTest {
	private static Logger  logger = LogManager.getLogger(SUPUWorkflowTest.class.getName());	
	
	@Test
	public void testSUPULineRejected() {
		// run workflow and obtain the result object
		WorkflowResult resultData = null;
		WorkflowManager workflowManager = (WorkflowManager) super.getBean("workflowManager");
		SubmitUnifiedMXPolicyUpdateRequest dummyObj = new SubmitUnifiedMXPolicyUpdateRequest();
		dummyObj.setDealerName("XMOCK-POL-LN1-REJ");
				
		try {
		
			resultData = workflowManager
					.execute(
							WorkflowConstants.SUBMIT_UNIFIED_POLICY_UPDATE_WORKFLOW_ID,
							WorkflowConstants.SUBMIT_UNIFIED_POLICY_UPDATE_REQUEST,
							dummyObj);
			SubmitUnifiedMXPolicyUpdateResponse submitUnifiedMXPolicyUpdateResponse = (SubmitUnifiedMXPolicyUpdateResponse) resultData.getResult();			
			assertEquals("0",submitUnifiedMXPolicyUpdateResponse.getPolicyCheckResult().getNumberOfLinesApproved());
			
		} catch (WorkflowException e) {
			logger.debug("inside workflow exception");
			e.printStackTrace();
		}	
		
	}

		
	public void setUp() throws Exception {
		//super.setContextLocation(springConfigFiles);
		super.setUp();
	}
	public void tearDown() throws Exception {
		super.tearDown();
	}
}
