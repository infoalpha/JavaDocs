/**
 * 
 */
package com.att.icasmx.rti.core.events.dupcheck;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;

/**
 * @author vk4235
 *
 */
public class DuplicateCreditCheckUverseEOrderTest {
		
	
	@InjectMocks
	DuplicateCreditCheckUverseEOrder duplicateCreditCheckUverseEOrder;
	@Mock 
	EventManager eventManager;
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test method for {@link com.att.icasmx.rti.core.events.dupcheck.DuplicateCreditCheckUverseEOrder#execute(com.att.icasmx.rti.workflow.EventManager)}.
	 */
	@Test
	public void testExecute() {
		
	 assertEquals("DuplicateCreditCheckUverseEOrderTest testExecute Successs", WorkflowConstants.WORKFLOW_RESULT_SUCCESS, duplicateCreditCheckUverseEOrder.execute(eventManager));
	}

}
