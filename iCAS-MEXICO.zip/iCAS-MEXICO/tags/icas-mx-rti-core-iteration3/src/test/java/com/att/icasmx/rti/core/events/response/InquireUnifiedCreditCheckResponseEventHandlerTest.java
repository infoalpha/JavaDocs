package com.att.icasmx.rti.core.events.response;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class InquireUnifiedCreditCheckResponseEventHandlerTest {
	
	@Before
	public void setUp() throws Exception {
	}
	
	@Test
	public void testExecute() {
		
	}

}
