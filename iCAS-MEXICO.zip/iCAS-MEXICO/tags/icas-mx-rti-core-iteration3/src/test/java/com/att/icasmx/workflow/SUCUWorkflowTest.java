package com.att.icasmx.workflow;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;

import com.att.icasmx.base.BaseSpringTest;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowException;
import com.att.icasmx.rti.workflow.WorkflowManager;
import com.att.icasmx.rti.workflow.WorkflowResult;
import com.att.icasmx.rti.ws.ConfirmUnifiedMXCreditDebtPaymentRequest;
import com.att.icasmx.rti.ws.ConfirmUnifiedMXCreditDebtPaymentResponse;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXCreditCheckRequest;
import com.att.icasmx.rti.ws.SubmitUnifiedMXCreditUpdateRequest;
import com.att.icasmx.rti.ws.SubmitUnifiedMXCreditUpdateResponse;

public class SUCUWorkflowTest extends BaseSpringTest {
	private static Logger  logger = LogManager.getLogger(SUCUWorkflowTest.class.getName());	
	
	@Test
	public void testSUCUWorkflow() {
				
		// run workflow and obtain the result object
		WorkflowResult resultData = null;
		WorkflowManager workflowManager = (WorkflowManager) super.getBean("workflowManager");
		SubmitUnifiedMXCreditUpdateRequest sucuReq = new SubmitUnifiedMXCreditUpdateRequest();
		sucuReq.setDealerName("XMOCK-DOC:BCF");
		
		try {
		
			resultData = workflowManager
					.execute(
							WorkflowConstants.SUBMIT_UNIFIED_CREDIT_UPDATE_WORKFLOW_ID,
							WorkflowConstants.SUBMIT_UNIFIED_CREDIT_UPDATE_REQUEST,
							sucuReq);
			SubmitUnifiedMXCreditUpdateResponse sucuschemresp = (SubmitUnifiedMXCreditUpdateResponse) resultData.getResult();
			System.out.println("Reason text"+sucuschemresp.getAdditionalDocumentationRequired().get(0).getReasonText());
			assertEquals(1, sucuschemresp.getAdditionalDocumentationRequired().size());
		} catch (WorkflowException e) {
			logger.debug("inside workflow exception");
			e.printStackTrace();
		}
	
		if (logger.isDebugEnabled()) {
			//logger.debug("output result name: " + resultData.getResultName());
			//logger.debug("output is: " + resultData.getResult().toString());
			//logger.debug("workflow history: " + resultData.getWorkflowHistory());
		}
	}
	
	
	@Test
	public void testSUCUWorkflowBadDocDealer() {
				
		// run workflow and obtain the result object
		WorkflowResult resultData = null;
		WorkflowManager workflowManager = (WorkflowManager) super.getBean("workflowManager");
		SubmitUnifiedMXCreditUpdateRequest sucuReq = new SubmitUnifiedMXCreditUpdateRequest();
		sucuReq.setDealerName("XMOCK-DOC:TEST");
		
		try {
		
			resultData = workflowManager
					.execute(
							WorkflowConstants.SUBMIT_UNIFIED_CREDIT_UPDATE_WORKFLOW_ID,
							WorkflowConstants.SUBMIT_UNIFIED_CREDIT_UPDATE_REQUEST,
							sucuReq);
			SubmitUnifiedMXCreditUpdateResponse sucuschemresp = (SubmitUnifiedMXCreditUpdateResponse) resultData.getResult();			
			assertEquals("100", sucuschemresp.getError().get(0).getErrorCode());
		} catch (WorkflowException e) {
			logger.debug("inside workflow exception");
			e.printStackTrace();
		}
	
		if (logger.isDebugEnabled()) {
			//logger.debug("output result name: " + resultData.getResultName());
			//logger.debug("output is: " + resultData.getResult().toString());
			//logger.debug("workflow history: " + resultData.getWorkflowHistory());
		}
	}
	
	
	//@Test
	public void testSUCUWorkflowNoDebt() {
				
		// run workflow and obtain the result object
		WorkflowResult resultData = null;
		WorkflowManager workflowManager = (WorkflowManager) super.getBean("workflowManager");
		SubmitUnifiedMXCreditUpdateRequest sucuReq = new SubmitUnifiedMXCreditUpdateRequest();
		sucuReq.setDealerName("XMOCK-DOC:TT");
		
		try {
		
			resultData = workflowManager
					.execute(
							WorkflowConstants.SUBMIT_UNIFIED_CREDIT_UPDATE_WORKFLOW_ID,
							WorkflowConstants.SUBMIT_UNIFIED_CREDIT_UPDATE_REQUEST,
							sucuReq);
			SubmitUnifiedMXCreditUpdateResponse sucuschemresp = (SubmitUnifiedMXCreditUpdateResponse) resultData.getResult();			
			assertEquals("100", sucuschemresp.getError().get(0).getErrorCode());
		} catch (WorkflowException e) {
			logger.debug("inside workflow exception");
			e.printStackTrace();
		}
	
		if (logger.isDebugEnabled()) {
			//logger.debug("output result name: " + resultData.getResultName());
			//logger.debug("output is: " + resultData.getResult().toString());
			//logger.debug("workflow history: " + resultData.getWorkflowHistory());
		}
	}
	
	
	
	
	public void setUp() throws Exception {
		//super.setContextLocation(springConfigFiles);
		super.setUp();
	}
	public void tearDown() throws Exception {
		super.tearDown();
	}
}
