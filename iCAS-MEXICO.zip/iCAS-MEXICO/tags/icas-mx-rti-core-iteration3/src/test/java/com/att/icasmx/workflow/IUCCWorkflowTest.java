package com.att.icasmx.workflow;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;

import com.att.icasmx.base.BaseSpringTest;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowException;
import com.att.icasmx.rti.workflow.WorkflowManager;
import com.att.icasmx.rti.workflow.WorkflowResult;
import com.att.icasmx.rti.ws.InquireUnifiedMXCreditCheckResultRequest;
import com.att.icasmx.rti.ws.InquireUnifiedMXCreditCheckResultResponse;

/**
 * @author bb047p
 * 
 * class IUCCWorkflowTest
 *
 */
public class IUCCWorkflowTest extends BaseSpringTest {
	private static Logger logger = LogManager.getLogger(IUCCWorkflowTest.class.getName());

	
	public void testIUCCWorkflow() {
		
		WorkflowResult resultData = null;
		WorkflowManager workflowManager = (WorkflowManager) super.getBean("workflowManager");
		
		InquireUnifiedMXCreditCheckResultRequest request = new InquireUnifiedMXCreditCheckResultRequest();
		request.setDealerName("XMOCK-DOC:BCF");

		try {
			resultData = workflowManager.execute(WorkflowConstants.INQUIRE_UNIFIED_CREDIT_CHECK_WORKFLOW_ID,
					WorkflowConstants.INQUIRE_UNIFIED_CREDIT_CHECK_REQUEST, request);
			InquireUnifiedMXCreditCheckResultResponse response = (InquireUnifiedMXCreditCheckResultResponse) resultData.getResult();
			assertEquals(1, response.getAdditionalDocumentationRequired().size());
		} catch (WorkflowException e) {
			logger.debug("IUCC Test Workflow Exception");
			e.printStackTrace();
		}
	}

	public void setUp() throws Exception {
		super.setUp();
	}

	public void tearDown() throws Exception {
		super.tearDown();
	}
}
