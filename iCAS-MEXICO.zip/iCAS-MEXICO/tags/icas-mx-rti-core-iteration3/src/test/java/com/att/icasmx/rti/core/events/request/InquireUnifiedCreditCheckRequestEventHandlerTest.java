package com.att.icasmx.rti.core.events.request;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class InquireUnifiedCreditCheckRequestEventHandlerTest {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testExecute() {
		
	}

}
