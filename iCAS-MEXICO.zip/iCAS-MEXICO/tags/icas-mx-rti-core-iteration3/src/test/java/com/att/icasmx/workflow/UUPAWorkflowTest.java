package com.att.icasmx.workflow;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;

import com.att.icasmx.base.BaseSpringTest;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowException;
import com.att.icasmx.rti.workflow.WorkflowManager;
import com.att.icasmx.rti.workflow.WorkflowResult;
import com.att.icasmx.rti.ws.UpdateUnifiedMXPolicyApplicationRequest;
import com.att.icasmx.rti.ws.UpdateUnifiedMXPolicyApplicationResponse;

public class UUPAWorkflowTest extends BaseSpringTest {
	private static Logger  logger = LogManager.getLogger(UUPAWorkflowTest.class.getName());	
	

	public void testUUPAMessageTest() {	
		// run workflow and obtain the result object
		WorkflowResult resultData = null;
		WorkflowManager workflowManager = (WorkflowManager) super
				.getBean("workflowManager");
		UpdateUnifiedMXPolicyApplicationRequest dummyObj = new UpdateUnifiedMXPolicyApplicationRequest();		
		dummyObj.setDealerCode("XMOCK-MSG");
		try {

			resultData = workflowManager.execute(
					WorkflowConstants.UPDATE_UNIFIED_POLICY_WORKFLOW_ID,
					WorkflowConstants.UPDATE_UNIFIED_POLICY_REQUEST, dummyObj);
			UpdateUnifiedMXPolicyApplicationResponse unifiedMXPolicyApplicationResponse = (UpdateUnifiedMXPolicyApplicationResponse) resultData
					.getResult();
			assertEquals("SUCCESS",
					unifiedMXPolicyApplicationResponse.getMessage().getMessageText());

		} catch (WorkflowException e) {
			logger.debug("inside workflow exception");
		e.printStackTrace();
	}
		
	}

		
	public void setUp() throws Exception {
		//super.setContextLocation(springConfigFiles);
		super.setUp();
	}
	public void tearDown() throws Exception {
		super.tearDown();
	}
}
