package com.att.icasmx.workflow;

import static com.att.icasmx.rti.workflow.WorkflowConstants.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;

import com.att.icasmx.base.BaseSpringTest;
import com.att.icasmx.rti.workflow.WorkflowException;
import com.att.icasmx.rti.workflow.WorkflowManager;
import com.att.icasmx.rti.workflow.WorkflowResult;
import com.att.icasmx.rti.ws.InquireUnifiedMXPolicyCheckResultRequest;
import com.att.icasmx.rti.ws.InquireUnifiedMXPolicyCheckResultResponse;

/**
 * @author bb047p
 * 
 * class IUPCWorkflowTest
 *
 */
public class IUPCWorkflowTest extends BaseSpringTest {
	private static Logger logger = LogManager.getLogger(IUPCWorkflowTest.class.getName());

	
	public void testIUPCWorkflow() {
		
		WorkflowResult resultData = null;
		WorkflowManager workflowManager = (WorkflowManager) super.getBean("workflowManager");
		
		InquireUnifiedMXPolicyCheckResultRequest request = new InquireUnifiedMXPolicyCheckResultRequest();
		request.setDealerName("XMOCK-ALERT:F1");

		try {
			resultData = workflowManager.execute(INQUIRE_UNIFIED_POLICY_CHECK_WORKFLOW_ID, INQUIRE_UNIFIED_POLICY_CHECK_REQUEST, request);
			InquireUnifiedMXPolicyCheckResultResponse response = (InquireUnifiedMXPolicyCheckResultResponse) resultData.getResult();
			assertEquals(1, response.getWorklistAlert().size());
		} catch (WorkflowException e) {
			logger.debug("IUPC Test Workflow Exception");
			e.printStackTrace();
		}
	}

	public void setUp() throws Exception {
		super.setUp();
	}

	public void tearDown() throws Exception {
		super.tearDown();
	}
}
