package com.att.icasmx.rti.util;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;

import org.junit.Test;

import com.att.icasmx.rti.core.data.EUCC_RSP;
import com.att.icasmx.rti.ws.AccountDetailInfo;

public class MockUtilsTest {
		
	@Test
	public void testPopulateDeb() {			
		EUCC_RSP euccRsp = new EUCC_RSP();
		euccRsp.setOutstandingDebtMinAmountDue("300");
		euccRsp.setOutstandingDebtPastAmountDue("400");		
		AccountDetailInfo accDtlInfo = MockUtils.populateDebt(euccRsp);
		assertEquals(accDtlInfo.getMinimumAmountDue(), new BigDecimal(euccRsp.getOutstandingDebtMinAmountDue()));
		assertEquals(accDtlInfo.getPastDueAmount(), new BigDecimal(euccRsp.getOutstandingDebtPastAmountDue()));
		//assertEquals(accDtlInfo.getServiceStartDate().)
	}

}
