package com.att.icasmx.workflow;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;

import com.att.icasmx.base.BaseSpringTest;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowException;
import com.att.icasmx.rti.workflow.WorkflowManager;
import com.att.icasmx.rti.workflow.WorkflowResult;
import com.att.icasmx.rti.ws.ConfirmUnifiedMXCreditDebtPaymentRequest;
import com.att.icasmx.rti.ws.ConfirmUnifiedMXCreditDebtPaymentResponse;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXCreditCheckRequest;

public class CUCDPWorkflowTest extends BaseSpringTest {
	private static Logger  logger = LogManager.getLogger(CUCDPWorkflowTest.class.getName());	
	
	@Test
	public void testCUCDPWorkflow() {
				
		// run workflow and obtain the result object
		WorkflowResult resultData = null;
		WorkflowManager workflowManager = (WorkflowManager) super.getBean("workflowManager");
		ConfirmUnifiedMXCreditDebtPaymentRequest cudpReq = new ConfirmUnifiedMXCreditDebtPaymentRequest();
		cudpReq.setDealerName("XMOCK-DOC:BCF");
		cudpReq.setUnifiedCreditTransactionId("111");
		try {
		
			resultData = workflowManager
					.execute(
							WorkflowConstants.CONFIRM_UNIFIED_CREDITDEBT_PAYMENT_WORKFLOW_ID,
							WorkflowConstants.CONFIRM_UNIFIED_CREDIT_DEBT_REQUEST,
							cudpReq);
			ConfirmUnifiedMXCreditDebtPaymentResponse cudpschemresp = (ConfirmUnifiedMXCreditDebtPaymentResponse) resultData.getResult();
			System.out.println("Reason text"+cudpschemresp.getAdditionalDocumentationRequired().get(0).getReasonText());
			assertEquals(true, cudpschemresp.isAdditionalDocumentationRequiredIndicator());
			//assertEquals(null, cudpschemresp.isWorklistIndicator());
		} catch (WorkflowException e) {
			logger.debug("inside workflow exception");
			e.printStackTrace();
		}
			
	}
	
	
	@Test
	public void testCUCDPNoDebtWorkflow() {
				
		// run workflow and obtain the result object
		WorkflowResult resultData = null;
		WorkflowManager workflowManager = (WorkflowManager) super.getBean("workflowManager");
		ConfirmUnifiedMXCreditDebtPaymentRequest cudpReq = new ConfirmUnifiedMXCreditDebtPaymentRequest();
		cudpReq.setDealerName("XMOCK-DEBT:200");
		cudpReq.setUnifiedCreditTransactionId("494928sds");
		try {
		
			resultData = workflowManager
					.execute(
							WorkflowConstants.CONFIRM_UNIFIED_CREDITDEBT_PAYMENT_WORKFLOW_ID,
							WorkflowConstants.CONFIRM_UNIFIED_CREDIT_DEBT_REQUEST,
							cudpReq);
			ConfirmUnifiedMXCreditDebtPaymentResponse cudpschemresp = (ConfirmUnifiedMXCreditDebtPaymentResponse) resultData.getResult();			
			assertEquals("100", cudpschemresp.getError().get(0).getErrorCode());
		} catch (WorkflowException e) {
			logger.debug("inside workflow exception");
			e.printStackTrace();
		}
		
	}
	
	
	public void setUp() throws Exception {
		//super.setContextLocation(springConfigFiles);
		super.setUp();
	}
	public void tearDown() throws Exception {
		super.tearDown();
	}
}
