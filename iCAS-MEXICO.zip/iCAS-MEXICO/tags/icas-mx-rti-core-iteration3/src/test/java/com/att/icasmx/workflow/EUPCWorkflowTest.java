package com.att.icasmx.workflow;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;

import com.att.icasmx.base.BaseSpringTest;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowException;
import com.att.icasmx.rti.workflow.WorkflowManager;
import com.att.icasmx.rti.workflow.WorkflowResult;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXCreditCheckRequest;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXCreditCheckResponse;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXPolicyCheckRequest;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXPolicyCheckResponse;

public class EUPCWorkflowTest extends BaseSpringTest {
	private static Logger  logger = LogManager.getLogger(EUPCWorkflowTest.class.getName());	
	

	public void testEUPCLineRejected() {
		// run workflow and obtain the result object
		WorkflowResult resultData = null;
		WorkflowManager workflowManager = (WorkflowManager) super.getBean("workflowManager");
		ExecuteUnifiedMXPolicyCheckRequest dummyObj = new ExecuteUnifiedMXPolicyCheckRequest();
		dummyObj.setDealerName("XMOCK-POL-LN1-DEPEQ:600-DEPSVC:1000");
				
		try {		
			resultData = workflowManager
					.execute(
							WorkflowConstants.EXECUTE_UNIFIED_POLICY_CHECK_WORKFLOW_ID,
							WorkflowConstants.EXECUTE_UNIFIED_POLICY_CHECK_REQUEST,
							dummyObj);
			ExecuteUnifiedMXPolicyCheckResponse executeUnifiedMXPolicyCheckResponse = (ExecuteUnifiedMXPolicyCheckResponse) resultData.getResult();			
			assertEquals("PLDEC",executeUnifiedMXPolicyCheckResponse.getStatusReason());			
		} catch (WorkflowException e) {
			logger.debug("inside workflow exception");
			e.printStackTrace();
		}	
		
	}

		
	public void setUp() throws Exception {
		//super.setContextLocation(springConfigFiles);
		super.setUp();
	}
	public void tearDown() throws Exception {
		super.tearDown();
	}
}
