package com.att.icasmx.base;

import junit.framework.TestCase;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.junit.Ignore;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


@Ignore
public class BaseSpringTest extends TestCase {
	private static Logger  logger = LogManager.getLogger(BaseSpringTest.class.getName());	
	private static long startTime;
	
	public BaseSpringTest() {
	}
	
	public static final String[] DEFAULT_CONFIG = {"classpath*:springcontext/context-core.xml"};
	
	private static ApplicationContext appCtx;

	private static String applicationContextFiles[] = DEFAULT_CONFIG;
	
    public static Object getBean(String beanName) {
      return appCtx.getBean(beanName);
    }
    
    public static void setContextLocation(String[] configLocations) {
        applicationContextFiles = configLocations;
    }
    
    public ApplicationContext getApplicationContext() {
    	return appCtx;
    }
    
    
    
    public void setUp() throws Exception {
		
		if (logger.isDebugEnabled()) {
			logger.debug("BaseSpringTest setUp...");
		}
    	startTimer();
        super.setUp();
        appCtx = new ClassPathXmlApplicationContext(applicationContextFiles);	
        logger.debug("testing:"+  appCtx);
    }
    
    
    
    
    public void tearDown() throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("BaseSpringTest tearDown...");
		}
        super.tearDown();
        endTimer();
    }

    private static void startTimer() {
        startTime = System.currentTimeMillis();
    }
    
    protected static void endTimer() {
    	long endTime = System.currentTimeMillis();
		if (logger.isDebugEnabled()) {
			logger.debug("TOTAL TEST TIME: "+(endTime-startTime)+" MILLISECONDS");
		}
  	}
    
    public void printDivider() {
		if (logger.isDebugEnabled()) {
			logger.debug("--------------------------------------------");
		}
    }
}
