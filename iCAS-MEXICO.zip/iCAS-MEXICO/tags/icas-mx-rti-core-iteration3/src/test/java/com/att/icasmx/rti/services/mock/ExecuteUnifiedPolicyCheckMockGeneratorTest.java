package com.att.icasmx.rti.services.mock;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.junit.Test;

import com.att.icasmx.rti.core.data.EUPC_RESPONSE;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXCreditCheckRequest;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXPolicyCheckRequest;
import com.att.icasmx.rti.ws.UpdateUnifiedMXPolicyApplicationRequest;


public class ExecuteUnifiedPolicyCheckMockGeneratorTest {
	

	@Test
	public void testCreateECUPCMockUpResponse(){
		ExecuteUnifiedPolicyCheckMockGenerator policyCheckMockGenerator=new ExecuteUnifiedPolicyCheckMockGenerator();
		
		String dealerName ="XMOCK-POL-LN1-REJ";
		ExecuteUnifiedMXPolicyCheckRequest executeUnifiedMXPolicyCheckRequest=new ExecuteUnifiedMXPolicyCheckRequest();
		executeUnifiedMXPolicyCheckRequest.setDealerName(dealerName);		
		EUPC_RESPONSE response = policyCheckMockGenerator.createECUPCMockUpResponse(executeUnifiedMXPolicyCheckRequest);
		assertEquals("0", response.getNumberOfLinesApproved());
		
	}
	
	
	
	public void testCreateUUPApplicationMockUpResponse(){
		ExecuteUnifiedPolicyCheckMockGenerator policyCheckMockGenerator=new ExecuteUnifiedPolicyCheckMockGenerator();
		
		String dealerName ="XMOCK-MSG";
		UpdateUnifiedMXPolicyApplicationRequest unifiedMXPolicyApplicationRequest=new UpdateUnifiedMXPolicyApplicationRequest();
		unifiedMXPolicyApplicationRequest.setDealerCode(dealerName);
		EUPC_RESPONSE response = policyCheckMockGenerator.createECUPCMockUpResponse(unifiedMXPolicyApplicationRequest);
		
		assertEquals("000", response.getMessageCode());
		assertEquals("SUCCESS", response.getMessageText());
	}
	

	
    public void testpopulatePolicyDetails(){
    	
    }

}
