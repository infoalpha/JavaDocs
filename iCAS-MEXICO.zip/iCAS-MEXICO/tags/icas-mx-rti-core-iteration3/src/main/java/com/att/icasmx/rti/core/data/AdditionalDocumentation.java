package com.att.icasmx.rti.core.data;

/**
 * 
 * @author mp157q
 * 
 */
public class AdditionalDocumentation {

	String documentationType;
	String reasonCode;
	String reasonText_en;
	String reasonText_es;

	public String getDocumentationType() {
		return documentationType;
	}

	public void setDocumentationType(String documentationType) {
		this.documentationType = documentationType;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getReasonText_en() {
		return reasonText_en;
	}

	public void setReasonText_en(String reasonText_en) {
		this.reasonText_en = reasonText_en;
	}

	public String getReasonText_es() {
		return reasonText_es;
	}

	public void setReasonText_es(String reasonText_es) {
		this.reasonText_es = reasonText_es;
	}

	

}
