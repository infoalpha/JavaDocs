package com.att.icasmx.rti.core.events.mock;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.icasmx.rti.core.data.EUPC_RESPONSE;
import com.att.icasmx.rti.exception.ICASException;
import com.att.icasmx.rti.services.mock.ExecuteUnifiedPolicyCheckMockGenerator;
import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowEventHandler;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXPolicyCheckRequest;

public class ExecuteUnifiedPolicyCheckMockEventHandler implements
WorkflowEventHandler {

	private static final Logger LOGGER=LogManager.getLogger(ExecuteUnifiedPolicyCheckMockEventHandler.class.getName());
	
	@Autowired
	ExecuteUnifiedPolicyCheckMockGenerator eupcMockGenarator;   
	
	public String execute(EventManager eventManager) {
		LOGGER.debug("Entering ExecuteUnifiedPolicyCheckMockEventHandler");
	    EUPC_RESPONSE ecupcResponse;
		ExecuteUnifiedMXPolicyCheckRequest executeUnifiedMXPolicyCheckRequest = (ExecuteUnifiedMXPolicyCheckRequest) eventManager
				.getWorkflowData(WorkflowConstants.EXECUTE_UNIFIED_POLICY_CHECK_REQUEST);
		LOGGER.debug("Dealer Name:"+executeUnifiedMXPolicyCheckRequest.getDealerName());
		System.out.println("*********Dealer Name:**********EUPC*****"+executeUnifiedMXPolicyCheckRequest.getDealerName()+"******************");	
		try{
		ecupcResponse= eupcMockGenarator.createECUPCMockUpResponse(executeUnifiedMXPolicyCheckRequest);
		}catch(RuntimeException icasException){
			LOGGER.error(icasException.getStackTrace());
			ecupcResponse=null;
		}
		//populateWSHeaderInformation(executeUnifiedMXPolicyCheckRequest,ecupcResponse);
		eventManager.putWorkflowData(WorkflowConstants.EUPC_MOCK_RESPONSE_DATA, ecupcResponse);
		LOGGER.debug("Exiting ExecuteUnifiedPolicyCheckMockEventHandler");
		return WorkflowConstants.WORKFLOW_RESULT_SUCCESS;
      }

	
	
	
	
}
