package com.att.icasmx.rti.core.events.response;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.att.icasmx.rti.constants.ICASConstants;
import com.att.icasmx.rti.core.data.AdditionalDocumentation;
import com.att.icasmx.rti.core.data.EUCC_RSP;
import com.att.icasmx.rti.util.MockUtils;
import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowEventHandler;
import com.att.icasmx.rti.workflow.WorkflowException;
import com.att.icasmx.rti.ws.CreditClassInfo;
import com.att.icasmx.rti.ws.DocumentationRequiredInfo;
import com.att.icasmx.rti.ws.DocumentationStatusCodeInfo;
import com.att.icasmx.rti.ws.DocumentationTypeInfo;
import com.att.icasmx.rti.ws.InquireUnifiedMXCreditCheckResultRequest;
import com.att.icasmx.rti.ws.InquireUnifiedMXCreditCheckResultResponse;
import com.att.icasmx.rti.ws.StatusInfo;
import com.att.icasmx.rti.ws.WorklistAlertInfo;

/**
 * @author bb047p
 * 
 *         class InquireUnifiedCreditCheckResponseHandler
 * 
 */
public class InquireUnifiedCreditCheckResponseEventHandler implements WorkflowEventHandler {

	private static final Logger LOGGER = LogManager.getLogger(
			InquireUnifiedCreditCheckResponseEventHandler.class.getName());
	
	private final String IUCC_RESULT = "IUCC_RESULT";
	
	/**
	 * Execute IUCC response event handler
	 * 
	 * @param EventManager
	 * @return String event result
	 */
	@Override
	public String execute(EventManager eventManager) {
		LOGGER.info("IUCC - ResponseEventHandler called");
		
		InquireUnifiedMXCreditCheckResultResponse response = new InquireUnifiedMXCreditCheckResultResponse();
		InquireUnifiedMXCreditCheckResultRequest request = (InquireUnifiedMXCreditCheckResultRequest) 
				eventManager.getWorkflowData(WorkflowConstants.INQUIRE_UNIFIED_CREDIT_CHECK_REQUEST);
		
		EUCC_RSP euccResponse = (EUCC_RSP) eventManager.getWorkflowData(WorkflowConstants.WORKFLOW_EUCC_RESP);
		String workflowResult = WorkflowConstants.WORKFLOW_RESULT_SUCCESS;
		
		response.setUnifiedCreditTransactionId(request.getUnifiedCreditTransactionId());
		if (request.getWSHeader() != null) {
			response = (InquireUnifiedMXCreditCheckResultResponse) MockUtils.populateHeaders(request, response);
		}
		
		if (euccResponse != null && euccResponse.getErrorCode() != null && !euccResponse.getErrorCode().isEmpty()) {
			response.getError().add(MockUtils.generateError(euccResponse));
			response.setStatus(StatusInfo.fromValue(euccResponse.getStatus()));
			response.setStatusReason(euccResponse.getStatusReason());
			return eventManager.eventEnd(workflowResult, IUCC_RESULT, response);
		}
		
		try {
			response = constructIUCCResponse(euccResponse, response);
		} catch (WorkflowException wfe) {
			euccResponse.setErrorCode("100");
			response.getError().add(MockUtils.generateError(euccResponse));
		}

		return eventManager.eventEnd(workflowResult, IUCC_RESULT, response);
	}

	/**
	 * Construct IUCC response from mock returned EUCC object
	 * 
	 * @param EUCC_RES
	 * @return InquireUnifiedMXCreditCheckResultResponse
	 */
	private InquireUnifiedMXCreditCheckResultResponse constructIUCCResponse(EUCC_RSP euccResponse,
			InquireUnifiedMXCreditCheckResultResponse response) {
		
		if (euccResponse != null) {
			/** Debt indicators */
			if (euccResponse.getOutstandingDebtIndicator() != null
					&& !euccResponse.getOutstandingDebtIndicator().equals(ICASConstants.EMPTY_STRING))
				response.setOutstandingDebtIndicator(new Boolean(euccResponse.getOutstandingDebtIndicator()));
			
			if (euccResponse.getOutstandingDebtMinAmountDue() != null
					&& !euccResponse.getOutstandingDebtMinAmountDue().equals(ICASConstants.EMPTY_STRING)) {
				response.getOutstandingDebt().add(MockUtils.populateDebt(euccResponse));
			}
			
			/** Worklist indicator */
			if (euccResponse.getWorkListIndicator() != null
					&& !euccResponse.getWorkListIndicator().equals(ICASConstants.EMPTY_STRING))
				response.setWorklistIndicator(new Boolean(euccResponse.getWorkListIndicator()));
			
			if (euccResponse.getWorkListAlertSeverity() != null) {
				WorklistAlertInfo workAlertInfo = MockUtils.getWorklistAlertInfo(euccResponse);
				response.getWorklistAlert().add(workAlertInfo);
			}
			
			/** Status indicators */
			if (euccResponse.getStatus() != null && !euccResponse.getStatus().equals(ICASConstants.EMPTY_STRING))
				response.setStatus(StatusInfo.fromValue(euccResponse.getStatus()));

			if (euccResponse.getStatusReason() != null
					&& !euccResponse.getStatusReason().equals(ICASConstants.EMPTY_STRING))
				response.setStatusReason(euccResponse.getStatusReason());
			
			/** Credit class */
			if (euccResponse.getCreditClass() != null)
				response.setCreditClass(CreditClassInfo.fromValue(euccResponse.getCreditClass()));

			/** Additional Documentation indicators */
			String additionalDoc = euccResponse.getAdditionalDocumentationReqIndicator();

			if (additionalDoc != null && !additionalDoc.equals(ICASConstants.EMPTY_STRING))
				response.setAdditionalDocumentationRequiredIndicator(new Boolean(euccResponse
						.getAdditionalDocumentationReqIndicator()));
			
			if (euccResponse.getAdditionalDoc() != null) {
				List<DocumentationRequiredInfo> additionalDocList = response.getAdditionalDocumentationRequired();
				for (AdditionalDocumentation obj : euccResponse.getAdditionalDoc()) {
					DocumentationRequiredInfo temp = new DocumentationRequiredInfo();
					temp.setDocumentationType(DocumentationTypeInfo.fromValue(obj.getDocumentationType()));
					temp.setReasonCode(DocumentationStatusCodeInfo.fromValue(obj.getReasonCode()));
					temp.setReasonText(obj.getReasonText_en());
					additionalDocList.add(temp);
				}
			}

		}

		return response;
	}

}
