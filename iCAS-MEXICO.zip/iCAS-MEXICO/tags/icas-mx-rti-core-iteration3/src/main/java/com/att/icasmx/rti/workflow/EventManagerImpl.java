package com.att.icasmx.rti.workflow;

import java.util.HashMap;
import java.util.Map;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


/**
 * The Class EventManagerImpl.
 */
@Component
public class EventManagerImpl implements EventManager {
	
	/** The event handler. */

	private WorkflowEventHandler eventHandler;
	
	/** The results. */
	private Map results;
	
	/** The inputs. */
	private Map inputs;
	
	/** The outputs. */
	private Map outputs;
	
	/** The workflow data map. */
	private Map workflowDataMap;
	
	/** The logger. */
	private static Logger  LOGGER = LogManager.getLogger(EventManagerImpl.class.getName());	

	/* (non-Javadoc)
	 * @see com.att.icas.workflow.EventManager#setResults(java.util.Map)
	 */
	public void setResults(Map results) {
		this.results = (HashMap) results;
	}

	/* (non-Javadoc)
	 * @see com.att.icas.workflow.EventManager#getResults()
	 */
	public Map getResults() {
		return results;
	}

	/* (non-Javadoc)
	 * @see com.att.icas.workflow.EventManager#getInputs()
	 */
	public Map getInputs() {
		return inputs;
	}

	/* (non-Javadoc)
	 * @see com.att.icas.workflow.EventManager#setInputs(java.util.Map)
	 */
	public void setInputs(Map inputs) {
		this.inputs = inputs;
	}

	/* (non-Javadoc)
	 * @see com.att.icas.workflow.EventManager#getOutputs()
	 */
	public Map getOutputs() {
		return outputs;
	}

	/* (non-Javadoc)
	 * @see com.att.icas.workflow.EventManager#setOutputs(java.util.Map)
	 */
	public void setOutputs(Map outputs) {
		this.outputs = outputs;
	}

	/* (non-Javadoc)
	 * @see com.att.icas.workflow.EventManager#getNextEvent(java.lang.String)
	 */
	public String getNextEvent(String result) {
		return  (String) results.get(result);
	}

	/* (non-Javadoc)
	 * @see com.att.icas.workflow.EventManager#isInputValid(com.att.icas.workflow.WorkflowDataValidator)
	 */
	public boolean isInputValid(WorkflowDataValidator validator) {
		// verify that the input objects specified in this event descriptor
		// are actually in the workflow data HashMap 
		return validator.isValid(workflowDataMap, getInputs());
	}

	/* (non-Javadoc)
	 * @see com.att.icas.workflow.EventManager#isOutputValid(com.att.icas.workflow.WorkflowDataValidator)
	 */
	public boolean isOutputValid(WorkflowDataValidator validator) {
		// verify that the output objects specified in this event descriptor
		// are actually in the workflow data HashMap 
		return validator.isValid(workflowDataMap, getOutputs());
	}
	
	// allow the Event to check to see if it is at the end of the workflow
	/* (non-Javadoc)
	 * @see com.att.icas.workflow.EventManager#isWorkflowEnd(java.lang.String)
	 */
	public boolean isWorkflowEnd(String result) {
		String nextEvent = (String) results.get(result);
		if (nextEvent != null && nextEvent.compareTo(WorkflowConstants.WORKFLOW_END) == 0) {
			return true;
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see com.att.icas.workflow.EventManager#eventEnd(java.lang.String, java.lang.String, java.lang.Object)
	 */
	public String eventEnd(String result, String key, Object data) {
		workflowDataMap.put(key, data);
		
		// If we're at the end of the workflow, set WORKFLOW_RESULT_NAME to point to 
		// the key of this data
		if (isWorkflowEnd(result) == true) {
			workflowDataMap.put(WorkflowConstants.WORKFLOW_RESULT_NAME, key);
		}
		return result;
	}

	/* (non-Javadoc)
	 * @see com.att.icas.workflow.EventManager#eventEnd(java.lang.String)
	 */
	public String eventEnd(String result) {
		return result;
	}

	/* (non-Javadoc)
	 * @see com.att.icas.workflow.EventManager#setWorkflowDataMap(java.util.Map)
	 */
	public void setWorkflowDataMap(Map workflowDataMap) {
		this.workflowDataMap = workflowDataMap;
	}
	
	/* (non-Javadoc)
	 * @see com.att.icas.workflow.EventManager#getWorkflowDataMap()
	 */
	public Map getWorkflowDataMap() {
		return this.workflowDataMap;
	}

	/* (non-Javadoc)
	 * @see com.att.icas.workflow.EventManager#getWorkflowData(java.lang.String)
	 */
	public Object getWorkflowData(String key) {
		return this.workflowDataMap.get(key);
	}

	/* (non-Javadoc)
	 * @see com.att.icas.workflow.EventManager#putWorkflowData(java.lang.String, java.lang.Object)
	 */
	public void putWorkflowData(String key, Object data) {
		this.workflowDataMap.put(key, data);
	}

	/* (non-Javadoc)
	 * @see com.att.icas.workflow.EventManager#getEvent()
	 */
	public WorkflowEventHandler getEvent() {
		return eventHandler;
	}

	/* (non-Javadoc)
	 * @see com.att.icas.workflow.EventManager#setEventHandler(com.att.icas.workflow.WorkflowAbstractEventHandler)
	 */
	public void setEventHandler(WorkflowEventHandler eventHandler) {
		this.eventHandler = eventHandler;
	}

	/* (non-Javadoc)
	 * @see com.att.icas.workflow.EventManager#executeEvent()
	 */
	public String executeEvent() {
		return this.getEvent().execute(this);
	}

}
