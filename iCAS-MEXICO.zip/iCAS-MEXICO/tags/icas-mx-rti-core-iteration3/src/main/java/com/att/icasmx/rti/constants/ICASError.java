package com.att.icasmx.rti.constants;

/**
 * The Enum ICASError.
 */
public enum ICASError {

	// general errors
	/** The AUT h_ failur e_70000. */
	AUTH_FAILURE_70000(100, 70000, ICASConstants.AUTHORIZATION_AUTHENTICATION_FAILURE,
			"ICAS", 70000, "Login failed"),

	/** The AUT h_ failur e_70001. */
	AUTH_FAILURE_70001(100, 70001,ICASConstants.AUTHORIZATION_AUTHENTICATION_FAILURE,
			"ICAS", 70001, "Operation not permitted for user"),

	/** The SERVIC e_ no t_ availabl e_70002. */
	SERVICE_NOT_AVAILABLE_70002(200, 70002, "SERVICE NOT AVAILABLE", "ICAS",
			70002, "Security exception"),

	/** The SERVIC e_ no t_ availabl e_70010. */
	SERVICE_NOT_AVAILABLE_70010(200, 70010, "SERVICE NOT AVAILABLE", "ICAS",
			70010, "Database Error - {$}"),

	/** The SERVIC e_ no t_ availabl e_70020. */
	SERVICE_NOT_AVAILABLE_70020(200, 70020, "SERVICE NOT AVAILABLE", "ICAS",
			70020, "Configuration Error"),

	/** The DAT a_ erro r_70030. */
	DATA_ERROR_70030(300, 70030, "DATA ERROR", "ICAS", 70030,
			"Data  Validation Error"),

	/** The DAT a_ erro r_70031. */
	DATA_ERROR_70031(300, 70031, "DATA ERROR", "ICAS", 70031,
			"Data Error: invalid field - {$}"),

	/** The DAT a_ erro r_70032. */
	DATA_ERROR_70032(300, 70032, "DATA ERROR", "ICAS", 70032,
			"Data Error: missing required field - {$}"),

	/** The DAT a_ erro r_70033. */
	DATA_ERROR_70033(300, 70033, "DATA ERROR", "ICAS", 70033,
			"Data Error: unknown UnifiedCreditTransactionId"),

	/** The DAT a_ erro r_70034. */
	DATA_ERROR_70034(300, 70034, "DATA ERROR", "ICAS", 70034,
			"Messages out of sequence. Unexpected message ID � {$}"),

	/** The DAT a_ erro r_70035. */
	DATA_ERROR_70035(300, 70035, "DATA ERROR", "ICAS", 70035,
			"Data Error: Unknown CAS Application #"),

	/** The DAT a_ erro r_70036. */
	DATA_ERROR_70036(300, 70036, "DATA ERROR", "ICAS", 70036,
			"Data Error: No CAS Application # for transaction Id"),

	/** The DAT a_ erro r_70037. */
	DATA_ERROR_70037(300, 70037, "DATA ERROR", "ICAS", 70037,
			"Original UVerse Application Expired"),

	/** The DAT a_ erro r_70038. */
	DATA_ERROR_70038(300, 70038, "DATA ERROR", "ICAS", 70038,
			"Original UVerse Application Cancelled"),

	/** The SCHEM a_ erro r_70040. */
	SCHEMA_ERROR_70040(400, 70040, "SCHEMA ERROR", "ICAS", 70040,
			"Schema Validation Error - {$}"),

	/** The RESOURC e_ no t_ availabl e_70050. */
	RESOURCE_NOT_AVAILABLE_70050(200, 70050,
			"A RESOURCE REQUIRED BY SERVICE IS NOT AVAILABLE", "ICAS", 70050,
			"Connection Issue"),

	/** The RESOURC e_ no t_ availabl e_70051. */
	RESOURCE_NOT_AVAILABLE_70051(200, 70051,
			"A RESOURCE REQUIRED BY SERVICE IS NOT AVAILABLE", "ICAS", 70051,
			"Service Timeout"),

	/** The UNKNOW n_ erro r_79999. */
	UNKNOWN_ERROR_79999(900, 79999, "UNKNOWN ERROR", "ICAS", 79999,
			"Unexpected error. Available details: [{$}]"),

	// specific to interconnect
	/** The AUT h_ failur e_10001. */
	AUTH_FAILURE_10001(100, 10001,ICASConstants.AUTHORIZATION_AUTHENTICATION_FAILURE,
			"INTERCONNECT", 10001, "Invalid user id or password"),

	/** The DAT a_ erro r_10002. */
	DATA_ERROR_10002(300, 10002, "DATA ERROR", "INTERCONNECT", 10002,
			"Messages out of sequence. Unexpected message ID � {$}"),

	/** The DAT a_ erro r_10003. */
	DATA_ERROR_10003(300, 10003, "DATA ERROR", "INTERCONNECT", 10003,
			"Original transaction ID not found"),

	/** The DAT a_ erro r_10004. */
	DATA_ERROR_10004(300, 10004, "DATA ERROR", "INTERCONNECT", 10004,
			"Request data cannot be parsed"),

	/** The DAT a_ erro r_10005. */
	DATA_ERROR_10005(300, 10005, "DATA ERROR", "INTERCONNECT", 10005, "{$}"),

	/** The RESOURC e_ no t_ availabl e_20001. */
	RESOURCE_NOT_AVAILABLE_20001(200, 20001,
			"A RESOURCE REQUIRED BY SERVICE IS NOT AVAILABLE", "INTERCONNECT",
			20001,
			"The time allowed for this data source to respond has expired"),

	/** The DAT a_ erro r_20002. */
	DATA_ERROR_20002(300, 20002, "DATA ERROR", "INTERCONNECT", 20002,
			"The data received from this data source was not able to be parsed"),

	/** The RESOURC e_ no t_ availabl e_20003. */
	RESOURCE_NOT_AVAILABLE_20003(200, 20003,
			"A RESOURCE REQUIRED BY SERVICE IS NOT AVAILABLE", "INTERCONNECT",
			20003,
			"The bureau has given an error. Available bureau error message: [{$}]"),

	/** The RESOURC e_ no t_ availabl e_20005. */
	RESOURCE_NOT_AVAILABLE_20005(
			200,
			20005,
			"A RESOURCE REQUIRED BY SERVICE IS NOT AVAILABLE",
			"INTERCONNECT",
			20005,
			"Both commercial data source yielded errors while performing the business lookups. Specific error for D&B: [{$}]. Specific error for XPB: [{$}]"),

	/** The RESOURC e_ no t_ availabl e_20006. */
	RESOURCE_NOT_AVAILABLE_20006(200, 20006,
			"A RESOURCE REQUIRED BY SERVICE IS NOT AVAILABLE", "INTERCONNECT",
			20006, "Unable to make decision"),

	/** The RESOURC e_ no t_ availabl e_20007. */
	RESOURCE_NOT_AVAILABLE_20007(
			200,
			20007,
			"A RESOURCE REQUIRED BY SERVICE IS NOT AVAILABLE",
			"INTERCONNECT",
			20007,
			"The bureau has given an error.  Available bureau error message:[AV Correction]can't run eID."),

	/** The RESOURC e_ no t_ availabl e_20008. */
	RESOURCE_NOT_AVAILABLE_20008(200, 20008,
			"A RESOURCE REQUIRED BY SERVICE IS NOT AVAILABLE", "INTERCONNECT",
			20008, "eID is already processed"),

	/** The UNKNOW n_ erro r_29999. */
	UNKNOWN_ERROR_29999(900, 29999, "UNKNOWN ERROR", "INTERCONNECT", 29999,
			"An unexpected error has occurred. Available details: [{$}]"),

	// specific to CAS
	/** The SYSTE m_ configuratio n_ erro r_50001. */
	SYSTEM_CONFIGURATION_ERROR_50001(200, 50001, "SYSTEM CONFIGURATION ERROR",
			"CAS", 50001, "An unknown transaction/message was received"),

	/** The DAT a_ erro r_50002. */
	DATA_ERROR_50002(300, 50002, "DATA ERROR", "CAS", 50002,
			"A duplicate transaction was received for this request"),

	/** The DAT a_ erro r_50003. */
	DATA_ERROR_50003(300, 50003, "DATA ERROR", "CAS", 50003,
			"No matching credit request was found for this transaction"),

	/** The DAT a_ erro r_50004. */
	DATA_ERROR_50004(300, 50004, "DATA ERROR", "CAS", 50004,
			"Required data is missing or not valid"),

	/** The DAT a_ erro r_50005. */
	DATA_ERROR_50005(300, 50005, "DATA ERROR", "CAS", 50005,
			"No account was found for existing customer credit check"),

	/** The DAT a_ erro r_50006. */
	DATA_ERROR_50006(300, 50006, "DATA ERROR", "CAS", 50006,
			"The account submitted for the existing customer credit request is not active"),

	/** The DAT a_ erro r_50007. */
	DATA_ERROR_50007(300, 50007, "DATA ERROR", "CAS", 50007,
			"CAS rejected the transaction for this request"),

	/** CAS IUCCR Error Codes */
	CAS_IUCCR_ERROR_891(300, 891, "APPLICATION NOT APPROVED", "CAS", 891,
			"The requested CAS order number is not approved."),

	CAS_IUCCR_ERROR_892(300, 892, "DATA ERROR", "CAS", 892,
			"Business name not matching."),

	CAS_IUCCR_ERROR_893(300, 893, "DATA ERROR", "CAS", 893,
			"Consumer name not matching."),

	CAS_IUCCR_ERROR_894(300, 894, "DATA ERROR", "CAS", 894,
			"Address mismatch for UC application."),

	CAS_IUCCR_ERROR_895(300, 895, "DATA ERROR", "CAS", 895,
			"Service Address mismatch for Non-UC application."),

	CAS_IUCCR_ERROR_896(300, 896, "DATA ERROR", "CAS", 896,
			"Affiliate id is NOT MATCHING."),

	CAS_IUCCR_ERROR_990(300, 990, "DATA ERROR", "CAS", 990,
			"Wireline/Uverse CAS order # not found in CAS."),

	CAS_IUCCR_ERROR_991(300, 991, "DATA ERROR", "CAS", 991,
			"Wireline/uverse request (Submit app request 1000) not found."),

	CAS_IUCCR_ERROR_992(300, 992, "DATA ERROR", "CAS", 992,
			"Credit decision record not found for the requested CAS order #."),

	CAS_IUCCR_ERROR_998(300, 998, "DATA ERROR", "CAS", 998,
			"No cas order # found in the request."),

	CAS_IUCCR_ERROR_999(300, 999, "DATA ERROR", "CAS", 999,
			"No data present in the inbound request."),

	CAS_IUCCR_ERROR_888(300, 888, "DATA ERROR", "CAS", 888,
			"system error (issues with CAS files/Database)."),

	/** The UNKNOW n_ erro r_59999. */
	UNKNOWN_ERROR_59999(900, 59999, "UNKNOWN ERROR", "CAS", 59999,
			"An unexpected error has occurred. Available details: [{$}] ");

	/** The error category. */
	private final int errorCategory;

	/** The error code. */
	private final int errorCode;

	/** The error message. */
	private final String errorMessage;

	// The defaults may be overridden by the user of this Enum
	/** The default error source. */
	private final String defaultErrorSource;

	/** The default source error code. */
	private final int defaultSourceErrorCode;

	/** The default source error message. */
	private final String defaultSourceErrorMessage;

	/**
	 * Instantiates a new iCAS error.
	 * 
	 * @param errorCategory
	 *            the error category
	 * @param errorCode
	 *            the error code
	 * @param errorMessage
	 *            the error message
	 * @param defaultErrorSource
	 *            the default error source
	 * @param defaultSourceErrorCode
	 *            the default source error code
	 * @param defaultSourceErrorMessage
	 *            the default source error message
	 */
	private ICASError(int errorCategory, int errorCode, String errorMessage,
			String defaultErrorSource, int defaultSourceErrorCode,
			String defaultSourceErrorMessage) {
		this.errorCategory = errorCategory;
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.defaultErrorSource = defaultErrorSource;
		this.defaultSourceErrorCode = defaultSourceErrorCode;
		this.defaultSourceErrorMessage = defaultSourceErrorMessage;
	}

	/**
	 * Gets the iCAS error by source error code.
	 * 
	 * @param sourceErrorCode
	 *            the source error code
	 * @return the iCAS error by source error code
	 */
	public static ICASError getICASErrorBySourceErrorCode(int sourceErrorCode) {
		for (ICASError icasError : ICASError.values()) {
			if (sourceErrorCode == icasError.defaultSourceErrorCode) {
				return icasError;
			}
		}
		return null;
	}

	/**
	 * Gets the error category.
	 * 
	 * @return the error category
	 */
	public int getErrorCategory() {
		return errorCategory;
	}

	/**
	 * Gets the error code.
	 * 
	 * @return the error code
	 */
	public int getErrorCode() {
		return errorCode;
	}

	/**
	 * Gets the error message.
	 * 
	 * @return the error message
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * Gets the default error source.
	 * 
	 * @return the default error source
	 */
	public String getDefaultErrorSource() {
		return defaultErrorSource;
	}

	/**
	 * Gets the default source error code.
	 * 
	 * @return the default source error code
	 */
	public int getDefaultSourceErrorCode() {
		return defaultSourceErrorCode;
	}

	/**
	 * Gets the default source error message.
	 * 
	 * @return the default source error message
	 */
	public String getDefaultSourceErrorMessage() {
		return defaultSourceErrorMessage;
	}
}
