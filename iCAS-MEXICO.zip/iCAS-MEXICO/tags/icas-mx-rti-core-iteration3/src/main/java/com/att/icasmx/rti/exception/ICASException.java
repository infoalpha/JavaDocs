package com.att.icasmx.rti.exception;

import java.io.Serializable;
import org.apache.commons.lang3.StringUtils;
import com.att.icasmx.rti.constants.ICASError;


/**
 * The Class ICASException.
 */
public class ICASException extends RuntimeException  implements Serializable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The category. */
	private String  category = ""; 			// Error Category: e.g. 100, 200, 300
	
	/** The error code. */
	private String errorCode = "";			// Error Code: e.g 2000001
	
	/** The error message. */
	private String errorMessage = "";		// Error Message: e.g Invalid Address
	
	/** The error source. */
	private String errorSource = ""; 		// Error Source: ICAS, Interconnect, CAS, CCR
	
	/** The source error code. */
	private String sourceErrorCode = "";	// Error Code from source application
	
	/** The source error message. */
	private String sourceErrorMessage = "";	// Error Description from source application	
	
	/** The environment name. */
	private String environmentName = "";	// Environment name which throws this Exception	
	
	/** The server name. */
	private String serverName = "";			// Server name which throws this Exception	
	
	/** The exception. */
	private RuntimeException exception;			// For convenience; optionally hold a real exception associated with this ICASException 
	
	/**
	 * Instantiates a new iCAS exception.
	 */
	public ICASException() {
    }
	
	/**
	 * Instantiates a new iCAS exception.
	 *
	 * @param category the category
	 * @param errorCode the error code
	 * @param errorMessage the error message
	 */
	public ICASException(String category, String errorCode, String errorMessage) {
		super (category+":"+errorCode+":"+errorMessage);
    }	
	
	/**
	 * Instantiates a new iCAS exception.
	 *
	 * @param category the category
	 * @param errorCode the error code
	 * @param errorMessage the error message
	 * @param errorSource the error source
	 * @param sourceErrorCode the source error code
	 * @param sourceErrorMessage the source error message
	 * @param environmentName the environment name
	 * @param serverName the server name
	 */
	public ICASException(String category, String errorCode, String errorMessage, String errorSource, 
			String sourceErrorCode, String sourceErrorMessage, String environmentName, String serverName) {
		super (category+":"+errorCode+":"+errorMessage+":"+errorSource+":"+sourceErrorCode+":"+
				sourceErrorMessage+":"+environmentName+":"+serverName);
    }

	// convenience methods
	/**
	 * Instantiates a new iCAS exception.
	 *
	 * @param error the error
	 */
	public ICASException(ICASError error) {
		this.setICASExceptionInformation(error, null, null, null);
	}
	
	/**
	 * Instantiates a new iCAS exception.
	 *
	 * @param error the error
	 * @param sourceErrorMessageInsertionText the source error message insertion text
	 */
	public ICASException(ICASError error, String sourceErrorMessageInsertionText) {
		this.setICASExceptionInformation(error, null, sourceErrorMessageInsertionText, null);
	}

	/**
	 * Instantiates a new iCAS exception.
	 *
	 * @param error the error
	 * @param newErrorSource the new error source
	 * @param sourceErrorMessageInsertionText the source error message insertion text
	 */
	public ICASException(ICASError error, String newErrorSource, String sourceErrorMessageInsertionText) {
		this.setICASExceptionInformation(error, newErrorSource, sourceErrorMessageInsertionText, null);
	}
	
	/**
	 * Instantiates a new iCAS exception.
	 *
	 * @param error the error
	 * @param newErrorSource the new error source
	 * @param sourceErrorMessageInsertionText the source error message insertion text
	 * @param e the e
	 */
	public ICASException(ICASError error, String newErrorSource, String sourceErrorMessageInsertionText, RuntimeException e) {
		this.setICASExceptionInformation(error, newErrorSource, sourceErrorMessageInsertionText, e);
	}
	
	/**
	 * Sets the icas exception information.
	 *
	 * @param error the error
	 * @param newErrorSource the new error source
	 * @param sourceErrorMessageInsertionText the source error message insertion text
	 * @param e the e
	 */
	private void setICASExceptionInformation (ICASError error, String newErrorSource, String sourceErrorMessageInsertionText, RuntimeException e) {
		this.category = Integer.toString(error.getErrorCategory());
		this.errorCode = Integer.toString(error.getErrorCode());
		this.errorMessage = error.getErrorMessage();
		this.sourceErrorCode = Integer.toString(error.getDefaultSourceErrorCode());
		
		if (newErrorSource != null)
			this.errorSource = newErrorSource;
		else
			this.errorSource = error.getDefaultErrorSource();
		
		// replace the {$} placeholder with the sourceErrorMessageInsertionText string
		if (sourceErrorMessage != null) {
			this.sourceErrorMessage =  StringUtils.replace(error.getDefaultSourceErrorMessage(), "{$}", sourceErrorMessageInsertionText);
			if (this.sourceErrorMessage.length() > 255) {	// don't exceed length of db column
				this.sourceErrorMessage =  this.sourceErrorMessage.substring(0, 255);
			}
		}
		else
			this.sourceErrorMessage =  error.getDefaultSourceErrorMessage();
		
		if (e != null)
			this.setException(e);
	}

	/**
	 * Gets the category.
	 *
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * Sets the category.
	 *
	 * @param category the new category
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 * Gets the error code.
	 *
	 * @return the error code
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * Sets the error code.
	 *
	 * @param errorCode the new error code
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * Gets the error message.
	 *
	 * @return the error message
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * Sets the error message.
	 *
	 * @param errorMessage the new error message
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * Gets the error source.
	 *
	 * @return the error source
	 */
	public String getErrorSource() {
		return errorSource;
	}

	/**
	 * Sets the error source.
	 *
	 * @param errorSource the new error source
	 */
	public void setErrorSource(String errorSource) {
		this.errorSource = errorSource;
	}

	/**
	 * Gets the source error code.
	 *
	 * @return the source error code
	 */
	public String getSourceErrorCode() {
		return sourceErrorCode;
	}

	/**
	 * Sets the source error code.
	 *
	 * @param sourceErrorCode the new source error code
	 */
	public void setSourceErrorCode(String sourceErrorCode) {
		this.sourceErrorCode = sourceErrorCode;
	}

	/**
	 * Gets the source error message.
	 *
	 * @return the source error message
	 */
	public String getSourceErrorMessage() {
		return sourceErrorMessage;
	}

	/**
	 * Sets the source error message.
	 *
	 * @param sourceErrorMessage the new source error message
	 */
	public void setSourceErrorMessage(String sourceErrorMessage) {
		this.sourceErrorMessage = sourceErrorMessage;
	}

	/**
	 * Gets the environment name.
	 *
	 * @return the environment name
	 */
	public String getEnvironmentName() {
		return environmentName;
	}

	/**
	 * Sets the environment name.
	 *
	 * @param environmentName the new environment name
	 */
	public void setEnvironmentName(String environmentName) {
		this.environmentName = environmentName;
	}

	/**
	 * Gets the server name.
	 *
	 * @return the server name
	 */
	public String getServerName() {
		return serverName;
	}

	/**
	 * Sets the server name.
	 *
	 * @param serverName the new server name
	 */
	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	/**
	 * Gets the exception.
	 *
	 * @return the exception
	 */
	public RuntimeException getException() {
		return exception;
	}

	/**
	 * Sets the exception.
	 *
	 * @param exception the new exception
	 */
	public void setException(RuntimeException exception) {
		this.exception = exception;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Throwable#toString()
	 */
	public String toString() {
		String info = "category=" + category + 
		", errorCode=" + errorCode +
		", errorMessage=" + errorMessage +
		", errorSource=" + errorSource +
		", sourceErrorCode=" + sourceErrorCode +
		", sourceErrorMessage=" + sourceErrorMessage +
		", environmentName=" + environmentName +
		", serverName=" + serverName;
		return info;
	}

}
