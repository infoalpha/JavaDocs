package com.att.icasmx.rti.constants;

/**
 * The Class ICASWorkflowConstants.
 *
 */
public class ICASMXWorkflowConstants {

    /**
     * Workflow IDs
     */
	/** The Constant EXECUTE_UNIFIED_CREDIT_CHECK_WORKFLOW_ID. */
    public static final String EXECUTE_UNIFIED_CREDIT_CHECK_WORKFLOW_ID = "ExecuteUnifiedCreditCheck";
    
    
    /** The Constant EXECUTE_UNIFIED_CREDIT_CHECK_WORKFLOW_ID. */
    public static final String EXECUTE_UNIFIED_POLICY_CHECK_WORKFLOW_ID = "ExecuteUnifiedPolicyCheck";
    
    /** The Constant ICAS_UC_XCHGSEL_REQ. */
	public static final String EXECUTE_UNIFIED_POLICY_CHECK_REQUEST = "ICASMX_EUPC_REQ";
			
	/** The Constant WORKFLOW_RESULT_NAME_CREDIT_RESULT_MOCKUP. */
	public static final String WORKFLOW_RESULT_NAME_POLICY_RESULT_MOCKUP = "WorkflowResultMockupPolicyResult";
	
	/** The Constant ICAS_EXCEPTION. */
	public static final String ICAS_EXCEPTION = "ICASException";
    
    
	
	
	
}
