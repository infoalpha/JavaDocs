package com.att.icasmx.rti.constants;
/**
 * The Class ICASConstants.
 */
public class ICASConstants {
	
	/*
	 * Utility classes should not have public constructors
	 * */
	private ICASConstants(){
		
	}
	
	public static final String  AUTHORIZATION_AUTHENTICATION_FAILURE ="AUTHORIZATION/AUTHENTICATION FAILURE";
	
	/** The Constant ICAS_SYSTEM_ID. */
	public static final String ICAS_SYSTEM_ID = "ICAS";
	
	/** The Constant ICAS_YES. */
	public static final String ICAS_YES = "Y";
	
	/** The Constant ICAS_NO. */
	public static final String ICAS_NO = "N";	
	
	/** The Constant TRANSACTION_ID. */
	public static final String TRANSACTION_ID = "TRANSACTION_ID";	
	
	/** The Constant TRANSACTION_NAME. */
	public static final String TRANSACTION_NAME = "TRANSACTION_NAME";
	
	/** The Constant THREAD_NAME. */
	public static final String THREAD_NAME = "THREAD_NAME";	
	
	/** The Constant SIMULATOR_INDICATOR. */
	public static final String SIMULATOR_INDICATOR = "SIM";	
	
	/** The Constant UTC. */
	public static final String UTC = "UTC";	
	
	/** The Constant NUMBER_ONE. */
	public static final String NUMBER_ONE = "1";	
	
	/** The Constant NUMBER_ONE. */
	public static final String CSI_TO_SIMULATOR_INDICATOR = "CSI2SIM";
	
	public static final String EMPTY_STRING = "";	
	
    public static final String ERROR_CODE="999";
    
    public static final String SCHEMA_ERROR_CODE="AR";
    
    public static final String SCHEMA_ERROR_REASON="ERROR";
	    
    public static final String INPUT_ERROR_CODE="100";
	    
    public static final String ERROR_MSG="Unknown Error Occurred";
	    
    public static final String INPUT_ERROR_MSG="Invalid Request";
	
    public static final String XMOCK_DEALER_PATTERN = "XMOCK-";
	
    public static final String XMOCK_DEBT = "DEBT";
		
}
