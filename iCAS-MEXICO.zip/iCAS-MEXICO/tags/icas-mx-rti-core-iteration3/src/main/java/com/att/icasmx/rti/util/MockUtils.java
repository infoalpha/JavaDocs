package com.att.icasmx.rti.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.att.icasmx.rti.constants.ICASConstants;
import com.att.icasmx.rti.core.data.AdditionalDocumentation;
import com.att.icasmx.rti.core.data.EUCC_RSP;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.ws.AccountDetailInfo;
import com.att.icasmx.rti.ws.AddressInfo;
import com.att.icasmx.rti.ws.ConfirmUnifiedMXCreditDebtPaymentRequest;
import com.att.icasmx.rti.ws.ConfirmUnifiedMXCreditDebtPaymentResponse;
import com.att.icasmx.rti.ws.ErrorInfo;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXCreditCheckRequest;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXCreditCheckResponse;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXPolicyCheckRequest;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXPolicyCheckResponse;
import com.att.icasmx.rti.ws.InquireUnifiedMXCreditCheckResultRequest;
import com.att.icasmx.rti.ws.InquireUnifiedMXCreditCheckResultResponse;
import com.att.icasmx.rti.ws.InquireUnifiedMXPolicyCheckResultRequest;
import com.att.icasmx.rti.ws.InquireUnifiedMXPolicyCheckResultResponse;
import com.att.icasmx.rti.ws.SubmitUnifiedMXCreditUpdateRequest;
import com.att.icasmx.rti.ws.SubmitUnifiedMXCreditUpdateResponse;
import com.att.icasmx.rti.ws.SubmitUnifiedMXPolicyUpdateRequest;
import com.att.icasmx.rti.ws.SubmitUnifiedMXPolicyUpdateResponse;
import com.att.icasmx.rti.ws.UpdateUnifiedMXPolicyApplicationRequest;
import com.att.icasmx.rti.ws.UpdateUnifiedMXPolicyApplicationResponse;
import com.att.icasmx.rti.ws.WSContext;
import com.att.icasmx.rti.ws.WSResponseHeader;
import com.att.icasmx.rti.ws.WorklistAlertInfo;
import com.att.icasmx.rti.ws.WorklistAlertReasonInfo;
import com.att.icasmx.rti.ws.WorklistAlertSeverityInfo;
import com.att.icasmx.rti.ws.WSContext.Version;

public class MockUtils {

	private static final Logger Logger = LogManager.getLogger(MockUtils.class
			.getName());

	private static final String CREDIT = "C";

	private static final String POLICY = "P";

	/**
	 * 
	 * @param docTypeList
	 * @return
	 */
	public static List<AdditionalDocumentation> populateDocments(
			String docTypeList) {
		String[] docTypeToken = StringUtils.split(docTypeList, ",");
		List<AdditionalDocumentation> addDoc = new ArrayList<AdditionalDocumentation>();
		for (int i = 0; i < docTypeToken.length; i++) {
			if (null != docTypeToken[i] && !docTypeToken[i].equals("")) {
				AdditionalDocumentation docType = populateIndividualDoc(docTypeToken[i]);
				if (null != docType.getReasonCode()
						&& !docType.getReasonCode().equals("INPUTERR"))
					addDoc.add(docType);
				else {
					addDoc.clear();
					addDoc.add(docType);
					break;
				}

			}
		}
		return addDoc;
	}

	/**
	 * 
	 * @param docType
	 * @return
	 */
	public static AdditionalDocumentation populateIndividualDoc(String docType) {
		AdditionalDocumentation tempAddDoc = new AdditionalDocumentation();
		String reasonCode = "";
		String reasonText_en = "";

		switch (docType) {
		case "BCF":
			reasonCode = "EXP";
			reasonText_en = "Bureau Consent Form Expired";
			break;
		case "IDP":
			reasonCode = "MIS";
			reasonText_en = "Proof of Identity Documentation missing";
			break;
		case "IPD":
			reasonCode = "MIS";
			reasonText_en = "Proof of Income Documentation missing";
			break;
		case "SID":
			reasonCode = "MIS";
			reasonText_en = "Customer Sub-Identification Documentation missing";
			break;
		case "AOI":
			reasonCode = "MIS";
			reasonText_en = "Articles of Incorporation Documentation missing";
			break;
		case "DOF":
			reasonCode = "MIS";
			reasonText_en = "Donor Form Documentation missing";
			break;
		case "EID":
			reasonCode = "MIS";
			reasonText_en = "Executive Identification/Authenticity Format Documentation missing";
			break;
		case "OOW":
			reasonCode = "MIS";
			reasonText_en = "Out-Of-Wallet Documentation missing";
			break;
		default:
			reasonCode = "INPUTERR";
			reasonText_en = "Unknown Doc TYpe";

		}

		tempAddDoc.setDocumentationType(docType);
		tempAddDoc.setReasonCode(reasonCode);
		tempAddDoc.setReasonText_en(reasonText_en);
		tempAddDoc.setReasonText_es("");
		return tempAddDoc;

	}

	/**
	 * 
	 * @param severity
	 * @return
	 */
	public static List<String> getWorkListAlertReason(String severity) {
		List<String> workList = new ArrayList<String>();
		String workListAlertReasonCode = "";
		String workListAlertMessage = "";
		switch (severity) {
		case "F1":
			workListAlertReasonCode = "BLH";
			workListAlertMessage = "Estimated wait time less than 30 minutes";
			break;
		case "F2":
			workListAlertReasonCode = "AIH";
			workListAlertMessage = "Estimated wait time less than 1 hour";
			break;
		case "F3":
			workListAlertReasonCode = "EFH";
			workListAlertMessage = "Estimated wait time less than 4 hours";
			break;
		case "F4":
			workListAlertReasonCode = "OOW";
			workListAlertMessage = "Customer will be notified when issue is resolved";
			break;
		default:
			workListAlertReasonCode = "ERR";
			workListAlertMessage = "Unknown WorkList Type";

		}

		workList.add(workListAlertReasonCode);
		workList.add(workListAlertMessage);

		return workList;
	}

	/**
	 * 
	 * @param severity
	 * @return
	 */
	public static boolean validateCreditClass(String creditClass) {

		boolean isValidCreditClass = false;
		switch (creditClass) {
		case "HH":
		case "HM":
		case "HL":
		case "MH":
		case "MM":
		case "ML":
		case "LH":
		case "LM":
		case "LL":
			isValidCreditClass = true;
			break;

		default:
			isValidCreditClass = false;
			break;

		}
		return isValidCreditClass;
	}

	/**
	 * 
	 * @param eucc_resp
	 * @return
	 */
	public static AccountDetailInfo populateDebt(EUCC_RSP eucc_resp) {

		AccountDetailInfo acctDtl = new AccountDetailInfo();
		acctDtl.setMinimumAmountDue(new BigDecimal(eucc_resp
				.getOutstandingDebtMinAmountDue()));
		acctDtl.setPastDueAmount(new BigDecimal(eucc_resp
				.getOutstandingDebtPastAmountDue()));
		acctDtl.setAcccountNumber("0000000000");
		acctDtl.setAcccountType("ZZZ");
		acctDtl.setAcccountSubType("YYY");
		acctDtl.setAcccountStatus("X");
		acctDtl.setBillingFullName("HUERTO LOYOLA CALOR EDUARDO");
		acctDtl.setAccountBalanceAmount(new BigDecimal(199));
		Calendar c1 = Calendar.getInstance();
		c1.set(2012, 0, 01);
		XMLGregorianCalendar xmlDate1 = DateUtil.dateToXml(c1.getTime());
		acctDtl.setServiceStartDate(xmlDate1);
		Calendar c2 = Calendar.getInstance();
		c2.set(2015, 9, 10);
		XMLGregorianCalendar xmlDate2 = DateUtil.dateToXml(c2.getTime());
		acctDtl.setBillRenderDate(xmlDate2);
		AddressInfo addrInfo = new AddressInfo();
		addrInfo.setAddressLine1("CIPRES EUROPEO 1464");
		addrInfo.setExternalStreetNumber("1464");
		addrInfo.setMunicipality("QUERETARO");
		addrInfo.setCity("QUERETARO");
		addrInfo.setState("QUERETARO");
		addrInfo.setPostalCode("55555");
		addrInfo.setNeighborhood("CIPRES");
		addrInfo.setCountry("MX");
		acctDtl.setCustomerAddress(addrInfo);
		return acctDtl;
	}

	 /**
	  * 
	  * @param euccRes
	  * @return
	  */
	public static WorklistAlertInfo getWorklistAlertInfo(EUCC_RSP euccRes) {
		WorklistAlertInfo workAlertInfo = new WorklistAlertInfo();
		workAlertInfo.setMessage(euccRes.getWorkListAlertMessage_en());
		workAlertInfo.setSeverity(WorklistAlertSeverityInfo.fromValue(euccRes
				.getWorkListAlertSeverity()));
		workAlertInfo.setReasonCode(WorklistAlertReasonInfo.fromValue(euccRes
				.getWorkListAlertReasonCode()));
		
		return workAlertInfo;

	}

	/**
	 * 
	 * @return String
	 */
	public static String getMockUnifiedTransactionId(String type) {
		Calendar now = Calendar.getInstance();
		int year = now.get(Calendar.YEAR);
		int month = now.get(Calendar.MONTH) + 1; // Note: zero based!
		int day = now.get(Calendar.DAY_OF_MONTH);
		String monthString = Integer.toString(month).length() > 1 ? Integer
				.toString(month) : "0" + Integer.toString(month);
		String dayString = Integer.toString(day).length() > 1 ? Integer
				.toString(day) : "0" + Integer.toString(day);
		// MOCK UnifiedPolicyTransactionId C/P +13 DIGIT RANDOM NUMBER+ DDMMYY
		return ((WorkflowConstants.CREDIT_TYPE.equals(type) ? CREDIT : POLICY)
				+ ThreadLocalRandom.current().nextLong(1000000000000L,
						10000000000000L) + dayString + monthString + Integer
				.toString(year).substring(2, 4));
	}

	/**
	 * 
	 * @param eucc_resp
	 * @return
	 */
	public static ErrorInfo generateError(EUCC_RSP eucc_resp) {

		ErrorInfo errInfo = new ErrorInfo();
		if (null != eucc_resp) {
			errInfo.setErrorCode(eucc_resp.getErrorCode());
			errInfo.setErrorMessage(eucc_resp.getErrorMessage());
			errInfo.setErrorSource(eucc_resp.getErrorSource());
		}

		return errInfo;
	}

	/**
	 * 
	 * @return
	 */
	public static EUCC_RSP generateInputError() {

		EUCC_RSP euccRes = new EUCC_RSP();
		euccRes.setErrorCode("100");
		euccRes.setErrorMessage("Invalid Request");
		euccRes.setErrorSource("ICAS");
		euccRes.setStatus("PA");
		euccRes.setStatusReason("ICINP");
		return euccRes;
	}

	/**
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	public static Object populateHeaders(Object request, Object response) {

		if (request instanceof ExecuteUnifiedMXCreditCheckRequest) {
			System.out
					.println("Inside ExecuteUnifiedMXCreditCheckRequest type ");
			ExecuteUnifiedMXCreditCheckRequest euccRqs = (ExecuteUnifiedMXCreditCheckRequest) request;
			ExecuteUnifiedMXCreditCheckResponse euccRsp = (ExecuteUnifiedMXCreditCheckResponse) response;
			WSResponseHeader wsHeader = new WSResponseHeader();
			wsHeader.setWSConversationId(euccRqs.getWSHeader()
					.getWSConversationId());
			if (null != euccRqs.getWSHeader().getWSCallback())
				wsHeader.setWSCorrelationId(euccRqs.getWSHeader()
						.getWSCallback().getWSCorrelationId());

			if (null != euccRqs.getWSHeader().getWSContext()) {
				WSContext wsContext = populateWSContextApp(euccRqs
						.getWSHeader().getWSContext().getFromAppId(), euccRqs
						.getWSHeader().getWSContext().getToAppId());
				if (null != euccRqs.getWSHeader().getWSContext().getVersion())
					populateWSContextVersion(wsContext, euccRqs.getWSHeader()
							.getWSContext().getVersion().getMajor(), euccRqs
							.getWSHeader().getWSContext().getVersion()
							.getMinor());

				wsHeader.setWSContext(wsContext);
			}

			euccRsp.setWSResponseHeader(wsHeader);
			return euccRsp;
		}

		if (request instanceof SubmitUnifiedMXCreditUpdateRequest) {
			System.out
					.println("Inside ExecuteUnifiedMXCreditCheckRequest type ");
			SubmitUnifiedMXCreditUpdateRequest sucuRqs = (SubmitUnifiedMXCreditUpdateRequest) request;
			SubmitUnifiedMXCreditUpdateResponse sucuRsp = (SubmitUnifiedMXCreditUpdateResponse) response;
			WSResponseHeader wsHeader = new WSResponseHeader();
			wsHeader.setWSConversationId(sucuRqs.getWSHeader()
					.getWSConversationId());
			if (null != sucuRqs.getWSHeader().getWSCallback())
				wsHeader.setWSCorrelationId(sucuRqs.getWSHeader()
						.getWSCallback().getWSCorrelationId());

			if (null != sucuRqs.getWSHeader().getWSContext()) {
				WSContext wsContext = populateWSContextApp(sucuRqs
						.getWSHeader().getWSContext().getFromAppId(), sucuRqs
						.getWSHeader().getWSContext().getToAppId());
				if (null != sucuRqs.getWSHeader().getWSContext().getVersion())
					populateWSContextVersion(wsContext, sucuRqs.getWSHeader()
							.getWSContext().getVersion().getMajor(), sucuRqs
							.getWSHeader().getWSContext().getVersion()
							.getMinor());

				wsHeader.setWSContext(wsContext);
			}

			sucuRsp.setWSResponseHeader(wsHeader);
			return sucuRsp;
		}

		if (request instanceof ConfirmUnifiedMXCreditDebtPaymentRequest) {
			System.out
					.println("Inside ExecuteUnifiedMXCreditCheckRequest type ");
			ConfirmUnifiedMXCreditDebtPaymentRequest cucdpRqs = (ConfirmUnifiedMXCreditDebtPaymentRequest) request;
			ConfirmUnifiedMXCreditDebtPaymentResponse cucdpRsp = (ConfirmUnifiedMXCreditDebtPaymentResponse) response;
			WSResponseHeader wsHeader = new WSResponseHeader();
			wsHeader.setWSConversationId(cucdpRqs.getWSHeader()
					.getWSConversationId());
			if (null != cucdpRqs.getWSHeader().getWSCallback())
				wsHeader.setWSCorrelationId(cucdpRqs.getWSHeader()
						.getWSCallback().getWSCorrelationId());

			if (null != cucdpRqs.getWSHeader().getWSContext()) {
				WSContext wsContext = populateWSContextApp(cucdpRqs
						.getWSHeader().getWSContext().getFromAppId(), cucdpRqs
						.getWSHeader().getWSContext().getToAppId());
				if (null != cucdpRqs.getWSHeader().getWSContext().getVersion())
					populateWSContextVersion(wsContext, cucdpRqs.getWSHeader()
							.getWSContext().getVersion().getMajor(), cucdpRqs
							.getWSHeader().getWSContext().getVersion()
							.getMinor());

				wsHeader.setWSContext(wsContext);
			}

			cucdpRsp.setWSResponseHeader(wsHeader);
			return cucdpRsp;
		}

		if (request instanceof InquireUnifiedMXCreditCheckResultRequest) {
			System.out
					.println("Inside ExecuteUnifiedMXCreditCheckRequest type ");
			InquireUnifiedMXCreditCheckResultRequest iucpRqs = (InquireUnifiedMXCreditCheckResultRequest) request;
			InquireUnifiedMXCreditCheckResultResponse iucpRsp = (InquireUnifiedMXCreditCheckResultResponse) response;
			WSResponseHeader wsHeader = new WSResponseHeader();
			wsHeader.setWSConversationId(iucpRqs.getWSHeader()
					.getWSConversationId());
			if (null != iucpRqs.getWSHeader().getWSCallback())
				wsHeader.setWSCorrelationId(iucpRqs.getWSHeader()
						.getWSCallback().getWSCorrelationId());
			if (null != iucpRqs.getWSHeader().getWSContext()) {
				WSContext wsContext = populateWSContextApp(iucpRqs
						.getWSHeader().getWSContext().getFromAppId(), iucpRqs
						.getWSHeader().getWSContext().getToAppId());
				if (null != iucpRqs.getWSHeader().getWSContext().getVersion())
					populateWSContextVersion(wsContext, iucpRqs.getWSHeader()
							.getWSContext().getVersion().getMajor(), iucpRqs
							.getWSHeader().getWSContext().getVersion()
							.getMinor());

				wsHeader.setWSContext(wsContext);
			}

			iucpRsp.setWSResponseHeader(wsHeader);
			return iucpRsp;
		}

		if (request instanceof ExecuteUnifiedMXPolicyCheckRequest) {
			Logger.debug("Inside polpulate WSHeader ExecuteUnifiedMXPolicyCheckRequest type");
			ExecuteUnifiedMXPolicyCheckRequest executeUnifiedMXPolicyCheckRequest = (ExecuteUnifiedMXPolicyCheckRequest) request;
			ExecuteUnifiedMXPolicyCheckResponse executeUnifiedMXPolicyCheckResponse = (ExecuteUnifiedMXPolicyCheckResponse) response;
			WSResponseHeader wsHeader = new WSResponseHeader();
			wsHeader.setWSConversationId(executeUnifiedMXPolicyCheckRequest
					.getWSHeader().getWSConversationId());
			if (null != executeUnifiedMXPolicyCheckRequest.getWSHeader()
					.getWSCallback())
				wsHeader.setWSCorrelationId(executeUnifiedMXPolicyCheckRequest
						.getWSHeader().getWSCallback().getWSCorrelationId());
			if (null != executeUnifiedMXPolicyCheckRequest.getWSHeader()
					.getWSContext()) {
				WSContext wsContext = populateWSContextApp(
						executeUnifiedMXPolicyCheckRequest.getWSHeader()
								.getWSContext().getFromAppId(),
						executeUnifiedMXPolicyCheckRequest.getWSHeader()
								.getWSContext().getToAppId());
				if (null != executeUnifiedMXPolicyCheckRequest.getWSHeader()
						.getWSContext().getVersion())
					populateWSContextVersion(wsContext,
							executeUnifiedMXPolicyCheckRequest.getWSHeader()
									.getWSContext().getVersion().getMajor(),
							executeUnifiedMXPolicyCheckRequest.getWSHeader()
									.getWSContext().getVersion().getMinor());

				wsHeader.setWSContext(wsContext);
			}
			executeUnifiedMXPolicyCheckResponse.setWSResponseHeader(wsHeader);
			return executeUnifiedMXPolicyCheckResponse;
		}

		if (request instanceof SubmitUnifiedMXPolicyUpdateRequest) {
			Logger.debug("Inside polpulate WSHeader SubmitUnifiedMXCreditUpdateRequest type ");
			SubmitUnifiedMXPolicyUpdateRequest submitUnifiedMXPolicyUpdateRequest = (SubmitUnifiedMXPolicyUpdateRequest) request;
			SubmitUnifiedMXPolicyUpdateResponse submitUnifiedMXPolicyUpdateResponse = (SubmitUnifiedMXPolicyUpdateResponse) response;
			WSResponseHeader wsHeader = new WSResponseHeader();
			wsHeader.setWSConversationId(submitUnifiedMXPolicyUpdateRequest
					.getWSHeader().getWSConversationId());
			if (null != submitUnifiedMXPolicyUpdateRequest.getWSHeader()
					.getWSCallback())
				wsHeader.setWSCorrelationId(submitUnifiedMXPolicyUpdateRequest
						.getWSHeader().getWSCallback().getWSCorrelationId());
			if (null != submitUnifiedMXPolicyUpdateRequest.getWSHeader()
					.getWSContext()) {
				WSContext wsContext = populateWSContextApp(
						submitUnifiedMXPolicyUpdateRequest.getWSHeader()
								.getWSContext().getFromAppId(),
						submitUnifiedMXPolicyUpdateRequest.getWSHeader()
								.getWSContext().getToAppId());
				if (null != submitUnifiedMXPolicyUpdateRequest.getWSHeader()
						.getWSContext().getVersion())
					populateWSContextVersion(wsContext,
							submitUnifiedMXPolicyUpdateRequest.getWSHeader()
									.getWSContext().getVersion().getMajor(),
							submitUnifiedMXPolicyUpdateRequest.getWSHeader()
									.getWSContext().getVersion().getMinor());

				wsHeader.setWSContext(wsContext);
			}
			submitUnifiedMXPolicyUpdateResponse.setWSResponseHeader(wsHeader);
			return submitUnifiedMXPolicyUpdateResponse;
		}
		if (request instanceof UpdateUnifiedMXPolicyApplicationRequest) {
			Logger.debug("Inside polpulate WSHeader SubmitUnifiedMXCreditUpdateRequest type ");
			UpdateUnifiedMXPolicyApplicationRequest updateUnifiedMXPolicyApplicationRequest = (UpdateUnifiedMXPolicyApplicationRequest) request;
			UpdateUnifiedMXPolicyApplicationResponse unifiedMXPolicyApplicationResponse = (UpdateUnifiedMXPolicyApplicationResponse) response;
			WSResponseHeader wsHeader = new WSResponseHeader();
			wsHeader.setWSConversationId(updateUnifiedMXPolicyApplicationRequest
					.getWSHeader().getWSConversationId());
			if (null != updateUnifiedMXPolicyApplicationRequest.getWSHeader()
					.getWSCallback())
				wsHeader.setWSCorrelationId(updateUnifiedMXPolicyApplicationRequest
						.getWSHeader().getWSCallback().getWSCorrelationId());
			if (null != updateUnifiedMXPolicyApplicationRequest.getWSHeader()
					.getWSContext()) {
				WSContext wsContext = populateWSContextApp(
						updateUnifiedMXPolicyApplicationRequest.getWSHeader()
								.getWSContext().getFromAppId(),
						updateUnifiedMXPolicyApplicationRequest.getWSHeader()
								.getWSContext().getToAppId());
				if (null != updateUnifiedMXPolicyApplicationRequest
						.getWSHeader().getWSContext().getVersion())
					populateWSContextVersion(wsContext,
							updateUnifiedMXPolicyApplicationRequest
									.getWSHeader().getWSContext().getVersion()
									.getMajor(),
							updateUnifiedMXPolicyApplicationRequest
									.getWSHeader().getWSContext().getVersion()
									.getMinor());

				wsHeader.setWSContext(wsContext);
			}
			unifiedMXPolicyApplicationResponse.setWSResponseHeader(wsHeader);
			return unifiedMXPolicyApplicationResponse;
		}

		if (request instanceof InquireUnifiedMXPolicyCheckResultRequest) {
			System.out.println("Inside ExecuteUnifiedMXPolicyCheckRequest type ");
			InquireUnifiedMXPolicyCheckResultRequest iucpRqs = (InquireUnifiedMXPolicyCheckResultRequest) request;
			InquireUnifiedMXPolicyCheckResultResponse iucpRsp = (InquireUnifiedMXPolicyCheckResultResponse) response;
			WSResponseHeader wsHeader = new WSResponseHeader();
			wsHeader.setWSConversationId(iucpRqs.getWSHeader().getWSConversationId());
			if (null != iucpRqs.getWSHeader().getWSCallback())
				wsHeader.setWSCorrelationId(iucpRqs.getWSHeader().getWSCallback().getWSCorrelationId());
			if (null != iucpRqs.getWSHeader().getWSContext()) {
				WSContext wsContext = populateWSContextApp(iucpRqs.getWSHeader().getWSContext().getFromAppId(), iucpRqs
						.getWSHeader().getWSContext().getToAppId());
				if (null != iucpRqs.getWSHeader().getWSContext().getVersion())
					populateWSContextVersion(wsContext, iucpRqs.getWSHeader().getWSContext().getVersion().getMajor(),
							iucpRqs.getWSHeader().getWSContext().getVersion().getMinor());

				wsHeader.setWSContext(wsContext);
			}

			iucpRsp.setWSResponseHeader(wsHeader);
			return iucpRsp;
		}

		return response;
	}

	/**
	 * 
	 * @param fromAppID
	 * @param toAppID
	 * @return
	 */
	private static WSContext populateWSContextApp(String fromAppID,
			String toAppID) {
		WSContext wsContext = new WSContext();
		wsContext.setFromAppId(ICASConstants.ICAS_SYSTEM_ID);
		wsContext.setToAppId(fromAppID);
		return wsContext;
	}

	/**
	 * 
	 * @param wsContext
	 * @param majorVersion
	 * @param minorVersion
	 * @return
	 */
	private static WSContext populateWSContextVersion(WSContext wsContext,
			int majorVersion, int minorVersion) {
		Version ver = new Version();
		ver.setMajor(majorVersion);
		ver.setMinor(minorVersion);
		wsContext.setVersion(ver);
		return wsContext;
	}

}
