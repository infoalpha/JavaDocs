package com.att.icasmx.rti.services.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.att.icasmx.rti.constants.Language;
import com.att.icasmx.rti.core.data.ICASError;
import com.att.icasmx.rti.services.ErrorService;
import com.att.icasmx.rti.ws.ErrorInfo;

/**
 * @author bb047p
 * 
 * ICAS Error Service mock implementation
 */
@Service("errorService")
public class ErrorServiceMockImpl implements ErrorService {

	Logger LOGGER = LogManager.getLogger(ErrorServiceMockImpl.class.getName());
	
	/** MOCK DB ERROR MAP */
	private Map<String, Map<String, String>> mockICASErrorMap = new HashMap<String, Map<String, String>>();
	
	
	/**
	 * Get ICAS error using error code
	 * @param the error code integer
	 * @return ICASError
	 */
	public ICASError getICASError(String errorCode) {
		ICASError icasError = null;
		Map<String, String> icasErrorMap = mockICASErrorMap.get(errorCode);
		
		if(!icasErrorMap.isEmpty()) {
			icasError = new ICASError();
			icasError.setErrorCode(icasErrorMap.get("code"));
			icasError.setErrorMessage_en(icasErrorMap.get("err_en"));
			icasError.setErrorMessage_es(icasErrorMap.get("err_es"));
		} else {
			LOGGER.error("Invalid error code recieved:" + errorCode);
		}
		
		return icasError;
	}

	/**
	 * Get ErrorInfo object using error code and language info
	 * @param errorCode
	 * @param languageInfo
	 * @return ErrorInfo
	 */
	public ErrorInfo getErrorInfo(String errorCode, Language language) {
		ErrorInfo errorInfo = null;
		Map<String, String> icasErrorMap = mockICASErrorMap.get(errorCode);
		
		if (!icasErrorMap.isEmpty()) {
			errorInfo = new ErrorInfo();
			errorInfo.setErrorCode(icasErrorMap.get("code"));
			errorInfo.setErrorMessage(icasErrorMap.get("err_" + language.getCode()));
			errorInfo.setErrorMessage(icasErrorMap.get("src"));
		} else {
			LOGGER.error("Invalid error code recieved:" + errorCode);
		}
		
		return errorInfo;
	}
	
	/** CONSTRUCTOR INITIALIZE MOCK ERROR MAP */
	@SuppressWarnings("serial")
	public ErrorServiceMockImpl() {
		mockICASErrorMap.put("999", new HashMap<String, String>() {{
			put("code", "999");
			put("err_en", "unknown error");
			put("err_es", "error desconocido");
			put("src", "500");
		}});
		mockICASErrorMap.put("100", new HashMap<String, String>() {{
			put("code", "100");
			put("err_en", "input error");
			put("err_es", "error de entrada");
			put("src", "500");
		}});
		mockICASErrorMap.put("200", new HashMap<String, String>() {{
			put("code", "200");
			put("err_en", "system down");
			put("err_es", "sistema de abajo");
			put("src", "500");
		}});
	}


}
