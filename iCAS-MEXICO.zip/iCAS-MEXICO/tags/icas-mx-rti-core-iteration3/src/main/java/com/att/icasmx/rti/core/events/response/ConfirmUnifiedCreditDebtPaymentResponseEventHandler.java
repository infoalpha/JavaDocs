package com.att.icasmx.rti.core.events.response;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.att.icasmx.rti.constants.ICASConstants;
import com.att.icasmx.rti.core.data.AdditionalDocumentation;
import com.att.icasmx.rti.core.data.EUCC_RSP;
import com.att.icasmx.rti.util.MockUtils;
import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowEventHandler;
import com.att.icasmx.rti.ws.ConfirmUnifiedMXCreditDebtPaymentRequest;
import com.att.icasmx.rti.ws.ConfirmUnifiedMXCreditDebtPaymentResponse;
import com.att.icasmx.rti.ws.CreditClassInfo;
import com.att.icasmx.rti.ws.DocumentationRequiredInfo;
import com.att.icasmx.rti.ws.DocumentationStatusCodeInfo;
import com.att.icasmx.rti.ws.DocumentationTypeInfo;
import com.att.icasmx.rti.ws.StatusInfo;
import com.att.icasmx.rti.ws.WorklistAlertInfo;
import com.att.icasmx.rti.ws.WorklistAlertReasonInfo;
import com.att.icasmx.rti.ws.WorklistAlertSeverityInfo;

public class ConfirmUnifiedCreditDebtPaymentResponseEventHandler implements
		WorkflowEventHandler {

	/** The logger. */
	private static Logger logger = LogManager
			.getLogger(ConfirmUnifiedCreditDebtPaymentResponseEventHandler.class
					.getName());
	private static final String CUCDP_RESULT  ="CUCDP_RESULT";

	@Override
	public String execute(EventManager eventManager) {
		ConfirmUnifiedMXCreditDebtPaymentResponse cucdpschemaRes = new ConfirmUnifiedMXCreditDebtPaymentResponse();
		EUCC_RSP eucc_resp = (EUCC_RSP) eventManager
				.getWorkflowData(WorkflowConstants.WORKFLOW_CUDP_RESP);

		ConfirmUnifiedMXCreditDebtPaymentRequest cudpRqs = (ConfirmUnifiedMXCreditDebtPaymentRequest) eventManager
				.getWorkflowData(WorkflowConstants.CONFIRM_UNIFIED_CREDIT_DEBT_REQUEST);
		if (null != cudpRqs.getWSHeader()) {
			System.out.println("PRINT CONVERSATION :"
					+ cudpRqs.getWSHeader().getWSConversationId());
			cucdpschemaRes = (ConfirmUnifiedMXCreditDebtPaymentResponse) MockUtils
					.populateHeaders(cudpRqs, cucdpschemaRes);
			
		}

		setUnifiedTransactionID(cudpRqs,cucdpschemaRes);
		
		if (eucc_resp != null
				&& eucc_resp.getErrorCode() != null
				&& (eucc_resp.getErrorCode().equalsIgnoreCase(ICASConstants.ERROR_CODE) || eucc_resp
						.getErrorCode().equalsIgnoreCase(ICASConstants.INPUT_ERROR_CODE))) {
			logger.error("Error: CUCD - response schema ERROR ");
			cucdpschemaRes.getError().add(MockUtils.generateError(eucc_resp));			
			cucdpschemaRes.setStatus(StatusInfo.fromValue(eucc_resp.getStatus()));
			cucdpschemaRes.setStatusReason(eucc_resp.getStatusReason());
			return eventManager.eventEnd(
					WorkflowConstants.WORKFLOW_RESULT_SUCCESS, CUCDP_RESULT,
					cucdpschemaRes);
		}

		Boolean debtIndicator = new Boolean(
				eucc_resp.getOutstandingDebtIndicator());
		Boolean addnDocIndicator = new Boolean(
				eucc_resp.getAdditionalDocumentationReqIndicator());

		if (null != eucc_resp.getWorkListIndicator()
				&& !eucc_resp.getWorkListIndicator().equals(
						ICASConstants.EMPTY_STRING))
			cucdpschemaRes.setWorklistIndicator(new Boolean(eucc_resp
					.getWorkListIndicator()).booleanValue());
		if (null != eucc_resp.getStatus() && !eucc_resp.getStatus().equals(""))
			cucdpschemaRes
					.setStatus(StatusInfo.fromValue(eucc_resp.getStatus()));
		if (null != eucc_resp.getStatusReason()
				&& !eucc_resp.getStatusReason().equals(""))
			cucdpschemaRes.setStatusReason(eucc_resp.getStatusReason());
		if (null != eucc_resp.getCreditClass())
			cucdpschemaRes.setCreditClass(CreditClassInfo.fromValue(eucc_resp
					.getCreditClass()));

		if (eucc_resp != null && eucc_resp.getWorkListAlertSeverity() != null) {
			WorklistAlertInfo workAlertInfo = new WorklistAlertInfo();
			workAlertInfo.setMessage(eucc_resp.getWorkListAlertMessage_en());
			workAlertInfo.setSeverity(WorklistAlertSeverityInfo
					.fromValue(eucc_resp.getWorkListAlertSeverity()));
			workAlertInfo.setReasonCode(WorklistAlertReasonInfo
					.fromValue(eucc_resp.getWorkListAlertReasonCode()));
			cucdpschemaRes.getWorklistAlert().add(workAlertInfo);
		}

		if (addnDocIndicator)
			cucdpschemaRes
					.setAdditionalDocumentationRequiredIndicator(addnDocIndicator);

		if (null != eucc_resp.getAdditionalDoc()) {
			List<DocumentationRequiredInfo> additionalDoc = cucdpschemaRes
					.getAdditionalDocumentationRequired();
			for (AdditionalDocumentation obj : eucc_resp.getAdditionalDoc()) {
				DocumentationRequiredInfo temp = new DocumentationRequiredInfo();
				temp.setDocumentationType(DocumentationTypeInfo.fromValue(obj
						.getDocumentationType()));
				temp.setReasonCode(DocumentationStatusCodeInfo.fromValue(obj
						.getReasonCode()));
				temp.setReasonText(obj.getReasonText_en());
				additionalDoc.add(temp);
			}
		}

		return eventManager.eventEnd(WorkflowConstants.WORKFLOW_RESULT_SUCCESS,
				CUCDP_RESULT, cucdpschemaRes);
	}
	
	
	/**
	 * 
	 * @param cucdpRqs
	 * @param cucdpRes
	 */
	private void setUnifiedTransactionID(ConfirmUnifiedMXCreditDebtPaymentRequest cucdpReq,ConfirmUnifiedMXCreditDebtPaymentResponse cucdpRes) {
		if (null !=cucdpReq &&  null != cucdpReq.getUnifiedCreditTransactionId())
			cucdpRes.setUnifiedCreditTransactionId(cucdpReq
					.getUnifiedCreditTransactionId());
		}

}
