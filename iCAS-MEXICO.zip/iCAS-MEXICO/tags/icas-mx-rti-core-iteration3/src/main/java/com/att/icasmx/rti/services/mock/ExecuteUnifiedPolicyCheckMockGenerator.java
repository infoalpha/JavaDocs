package com.att.icasmx.rti.services.mock;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.att.icasmx.rti.core.data.AdditionalDocumentation;
import com.att.icasmx.rti.core.data.EUPC_RESPONSE;
import com.att.icasmx.rti.exception.ICASException;
import com.att.icasmx.rti.util.MockUtils;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXPolicyCheckRequest;
import com.att.icasmx.rti.ws.SubmitUnifiedMXPolicyUpdateRequest;
import com.att.icasmx.rti.ws.UpdateUnifiedMXPolicyApplicationRequest;
import com.att.icasmx.rti.ws.InquireUnifiedMXPolicyCheckResultRequest;
import com.att.icasmx.rti.ws.WSHeader;

/**
 * @author vk4235 Class MockupGeneratorServiceImpl This Class is collection of
 *         MouckUp methods which gets invoked during all workflow
 * 
 */
@Component("eupcMockGenarator")
public class ExecuteUnifiedPolicyCheckMockGenerator {

	private static final Logger LOGGER = LogManager
			.getLogger(ExecuteUnifiedPolicyCheckMockGenerator.class.getName());

	private static final String MULTI_LINE_DELIMITER = ",";

	private static final String POLICY_DELIMITER = "-";

	private static final String COLON = ":";

	private static final String LINE_REJECTED = "REJ";

	private static final String LINE_APPROVED = "APP";

	private static final String LINE = "LN";

	private static final String ALERT = "ALERT";
	
	private static final String SHIPPING_ADDRESS = "SHIPADDR";

	private static final String ALERT_F1 = "F1";

	private static final String ALERT_F2 = "F2";

	private static final String ALERT_F3 = "F3";

	private static final String ALERT_F4 = "F4";

	private static final String ALERT_F1_CODE = "BLH";

	private static final String ALERT_F2_CODE = "AIH";

	private static final String ALERT_F3_CODE = "EFH";

	private static final String ALERT_F4_CODE = "OOW";

	private static final String ALERT_F1_MESSAGE_EN = "Estimated wait time less than 30 minutes";

	private static final String ALERT_F2_MESSAGE_EN = "Estimated wait time less than 1 hour";

	private static final String ALERT_F3_MESSAGE_EN = "Estimated wait time less than 4 hour";

	private static final String ALERT_F4_MESSAGE_EN = "Customer will be notified when issue is resolved";

	private static final String ERROR = "ERROR";

	private static final String SHIPPING_ADDRESS_REQUIRED = "SADDR";
		
	private static final String DEPOSIT = "DEP";

	private static final String DEPOSIT_ON_EQUIPMENT_CODE = "DEPEQ";
	
	private static final String DEPOSIT_ON_SERVICE_CODE = "DEPSVC";

	private static final String DEPOSIT_ON_EQUIPMENT = "Deposit on Equipment";

	private static final String DEPOSIT_ON_SERVICE = "Deposit on Service";

	private static final String POLICY_ENFORCEMENT_LEVEL_L = "L";

	private static final String POLICY_ENFORCEMENT_LEVEL_A = "A";

	private static final String POLICY_STATUS_CA = "CA";

	private static final String POLICY_STATUS_REASON_CODE_PLDEC = "PLDEC";

	private static final String POLICY_STATUS_REASON_CODE_FORM = "FORMS";

	private static final String POLICY_STATUS_AR = "AR";

	private static final String ERROR_CODE = "999";

	private static final String INPUT_ERROR_CODE = "100";

	private static final String ERROR_MSG = "Unknown Error Occurred";

	private static final String INPUT_ERROR_MSG = "Invalid Request";

	private static final String FRAUD = "FRAUD";

	private static final String ICAS = "ICAS";

	private static final String MSG_CODE = "000";

	private static final String MSG_TEXT = "SUCCESS";

	private static final String MSG = "MSG";

	private static final String DOC = "DOC";

	private static final String ERROR_ERR = "ERR";

	/**
	 * createEUCCMockUpResponse
	 * 
	 * @throws ICASException
	 */
	public void createEUCCMockUpResponse() throws ICASException {

	};

	/**
	 * createECUPCMockUpResponse
	 * 
	 * @throws ICASException
	 */
	public EUPC_RESPONSE createECUPCMockUpResponse(Object request)
			throws ICASException {

		LOGGER.debug("Entering EUPCMockupGenerator createECUPCMockUpResponse");

		EUPC_RESPONSE eupcMockupResponseData = new EUPC_RESPONSE();
		String requestMockString = null;
		if (request.getClass().isInstance(
				new ExecuteUnifiedMXPolicyCheckRequest())) {
			requestMockString = ((ExecuteUnifiedMXPolicyCheckRequest) request)
					.getDealerName();
			populateWSHeaderData(
					((ExecuteUnifiedMXPolicyCheckRequest) request)
							.getWSHeader(),
					eupcMockupResponseData);
			//Setting Unique Unified policy transaction ID
			eupcMockupResponseData.setUnifiedPolicyTransactionID(MockUtils
					.getMockUnifiedTransactionId(WorkflowConstants.POLICY_TYPE));
		} else if (request.getClass().isInstance(
				new SubmitUnifiedMXPolicyUpdateRequest())) {
			requestMockString = ((SubmitUnifiedMXPolicyUpdateRequest) request)
					.getDealerName();
			populateWSHeaderData(
					((SubmitUnifiedMXPolicyUpdateRequest) request)
							.getWSHeader(),
					eupcMockupResponseData);
			//Setting Unique Unified policy transaction ID
			eupcMockupResponseData
					.setUnifiedPolicyTransactionID(((SubmitUnifiedMXPolicyUpdateRequest) request)
							.getUnifiedPolicyTransactionId());
		} else if (request.getClass().isInstance(
				new UpdateUnifiedMXPolicyApplicationRequest())) {
			requestMockString = ((UpdateUnifiedMXPolicyApplicationRequest) request)
					.getDealerCode();
			populateWSHeaderData(
					((UpdateUnifiedMXPolicyApplicationRequest) request)
							.getWSHeader(),
					eupcMockupResponseData);
			//Setting Unique Unified policy transaction ID
			eupcMockupResponseData
			.setUnifiedPolicyTransactionID(((UpdateUnifiedMXPolicyApplicationRequest) request)
					.getUnifiedPolicyTransactionId());
			String dealerName = requestMockString != null ? requestMockString
					.trim() : null;
			if (null != dealerName && dealerName.contains(MSG)) {
				populateMessageResponse(eupcMockupResponseData);
			}  else if(null != dealerName && dealerName.contains(ERROR)){
				populateErrorReponse(eupcMockupResponseData, ERROR_CODE, ERROR_MSG,
						ICAS);
			}else{
				//Invalid Request
				populateErrorReponse(eupcMockupResponseData, INPUT_ERROR_CODE, INPUT_ERROR_MSG,
						ICAS);
			}			
			return eupcMockupResponseData;
		} else if (request.getClass().isInstance(
				new InquireUnifiedMXPolicyCheckResultRequest())) {
			requestMockString = ((InquireUnifiedMXPolicyCheckResultRequest) request)
					.getDealerName();
			populateWSHeaderData(
					((InquireUnifiedMXPolicyCheckResultRequest) request)
							.getWSHeader(),
					eupcMockupResponseData);
			//Setting Unique Unified policy transaction ID
			eupcMockupResponseData
					.setUnifiedPolicyTransactionID(((InquireUnifiedMXPolicyCheckResultRequest) request)
							.getUnifiedPolicyTransactionId());
		}

		String dealerName = requestMockString != null ? requestMockString
				.trim() : null;

		if (null != dealerName && dealerName.contains(LINE)) {

			populatePolicyDetails(eupcMockupResponseData, dealerName);

		} else if (null != dealerName
				&& dealerName.contains(SHIPPING_ADDRESS)) {
			populateShippingAddressResponse(eupcMockupResponseData);
		} else if (null != dealerName && dealerName.contains(ALERT)) {
			populateAlertResponse(eupcMockupResponseData, dealerName);
		}  else if(null != dealerName && dealerName.contains(ERROR)){
			populateErrorReponse(eupcMockupResponseData, ERROR_CODE, ERROR_MSG,
					ICAS);
		}else if (null != dealerName && dealerName.contains(DOC)) {
			populateDocTypeResponse(eupcMockupResponseData, dealerName);
		}else {
			populateErrorReponse(eupcMockupResponseData, INPUT_ERROR_CODE, INPUT_ERROR_MSG,
					ICAS);
		}

		LOGGER.debug("Exiting EUPCMockupGenerator createECUPCMockUpResponse");
		// setting UnifiedPolicyTransactionID starts with "U"		
		return eupcMockupResponseData;
	};

	/**
	 * Sample Request will look like
	 * XMOCK-LN1-DEPEQ:700,LN2-DEPEQ:1000-DEPSVC:800 This method will first
	 * split the sting using , (which is the line separator) and determines the
	 * number of lines and then each string will be split using "-"(policy
	 * separator) and the policies are populated accordingly
	 * populatePolicyDetails
	 * 
	 * @param eupcMockupResponseData
	 */
	public void populatePolicyDetails(EUPC_RESPONSE eupcMockupResponseData,
			String dealerName) {

		List<String> policyLineDetailsinfos = Arrays.asList(dealerName
				.split(MULTI_LINE_DELIMITER));
		if (null != policyLineDetailsinfos && !policyLineDetailsinfos.isEmpty()) {
			// Setting Response status & status reason
			eupcMockupResponseData.setStatus(POLICY_STATUS_CA);
			eupcMockupResponseData
					.setStatusReason(POLICY_STATUS_REASON_CODE_PLDEC);
			// setting lineIDs
			List<String> lineIDlist = new ArrayList<String>();
			List<Boolean> lineApprovedIndicatorList = new ArrayList<Boolean>();
			List<Boolean> policyRequiredIndicatorList = new ArrayList<Boolean>();
			List<String> policyIdList = new ArrayList<String>();
			List<String> elements = new ArrayList<String>();
			Map<String, List<String>> LinesdepositMap = new HashMap<String, List<String>>();
			int linesApproved = policyLineDetailsinfos.size();
			for (int i = 1; i <= policyLineDetailsinfos.size(); i++) {
				// Setting LineID
				lineIDlist.add(String.valueOf(i));
				// Process whether Line is Approved OR Rejected
				if (policyLineDetailsinfos.get(i - 1).contains(LINE_REJECTED)) {
					linesApproved--;
					// Setting Line Approved Indicator
					lineApprovedIndicatorList.add(false);
				} else if (policyLineDetailsinfos.get(i - 1).contains(
						LINE_APPROVED)) {
					lineApprovedIndicatorList.add(true);
				}else if(!policyLineDetailsinfos.get(i - 1).contains(
						DEPOSIT)){
					populateErrorReponse(eupcMockupResponseData, INPUT_ERROR_CODE,
							INPUT_ERROR_MSG, ICAS);
					return;
				}

				// Process Policy required Indicator
				if (policyLineDetailsinfos.get(i - 1).contains(DEPOSIT)) {
					policyIdList.add("1");
					policyRequiredIndicatorList.add(true);
					lineApprovedIndicatorList.add(true);
				} else {
					policyIdList.add(null);
					policyRequiredIndicatorList.add(false);
				}
				// Process policies
				elements = Arrays.asList(policyLineDetailsinfos.get(i - 1)
						.split(POLICY_DELIMITER));
				Iterator elementsIterator = elements.iterator();
				List<String> Linedepositlist = new ArrayList<String>();
				while (elementsIterator.hasNext()) {
					String depositElementString = (String) elementsIterator
							.next();
					if (depositElementString.contains(DEPOSIT)) {
						if (depositElementString
								.contains(DEPOSIT_ON_EQUIPMENT_CODE)) {
							// CONSTRUCT DEPOSIT ELEMENT AS
							// DEPEQ:AMOUNT:DESCRIPTION:ENFORCEMENTLEVEL
							Linedepositlist.add(depositElementString
									.concat(COLON + DEPOSIT_ON_EQUIPMENT
											+ COLON
											+ POLICY_ENFORCEMENT_LEVEL_L));
						} else if(depositElementString
								.contains(DEPOSIT_ON_SERVICE_CODE)){
							// CONSTRUCT DEPOSIT ELEMENT AS
							// DEPSVC:AMOUNT:DESCRIPTION:ENFORCEMENTLEVEL
							Linedepositlist.add(depositElementString
									.concat(COLON + DEPOSIT_ON_SERVICE + COLON
											+ POLICY_ENFORCEMENT_LEVEL_A));
						}else{
							//Error if DEPEQ or DEPSVC not present
							populateErrorReponse(eupcMockupResponseData, INPUT_ERROR_CODE,
									INPUT_ERROR_MSG, ICAS);
							return;
						}
					}
				}
				LinesdepositMap.put(String.valueOf(i), Linedepositlist);
			}
			// setting number of line approved
			eupcMockupResponseData.setNumberOfLinesApproved(String
					.valueOf(linesApproved));
			// Setting Line wise Deposit details
			eupcMockupResponseData.setLinesdepositMap(LinesdepositMap);
			// Setting LineID List
			eupcMockupResponseData.setLineID(lineIDlist);
			// Setting Line Approved Indicator List
			eupcMockupResponseData
					.setLineApprovedIndicatorlist(lineApprovedIndicatorList);
			// Setting Policy Required Indicator List
			eupcMockupResponseData
					.setPolicyRequiredIndicatorlist(policyRequiredIndicatorList);
			// Setting Policy Id List
			eupcMockupResponseData.setPolicyIdList(policyIdList);
			LOGGER.debug("PolicyId list Size " + policyIdList.size());
		} else {
			populateErrorReponse(eupcMockupResponseData, INPUT_ERROR_CODE,
					INPUT_ERROR_MSG, ICAS);
		}
	}

	/**
	 * populateShippingAddressResponse
	 * 
	 * @param eupcMockupResponseData
	 */
	public void populateShippingAddressResponse(
			EUPC_RESPONSE eupcMockupResponseData) {
		eupcMockupResponseData.setStatus(POLICY_STATUS_AR);
		eupcMockupResponseData.setStatusReason(SHIPPING_ADDRESS_REQUIRED);
		eupcMockupResponseData.setShippingAddressRequired(true);
	}

	/**
	 * 
	 * @param eupcMockupResponseData
	 * @param dealerName
	 */
	public void populateDocTypeResponse(EUPC_RESPONSE eupcMockupResponseData,
			String dealerName) {
		if (splitString(dealerName, COLON) != null) {
			List<AdditionalDocumentation> docTypesList = MockUtils
					.populateDocments(Arrays.asList(
							splitString(dealerName, COLON)).get(1));			
			// IF Doc Type List Contains Error break and return error response
			for (AdditionalDocumentation additionalDocumentation : docTypesList) {
				if (additionalDocumentation.getReasonCode().equals(ERROR_ERR)) {
					populateErrorReponse(eupcMockupResponseData,
							INPUT_ERROR_CODE, INPUT_ERROR_MSG, ICAS);
					return;
				}
			}
			populateDocTypeDetails(eupcMockupResponseData, docTypesList);
		} else {
			populateErrorReponse(eupcMockupResponseData, INPUT_ERROR_CODE,
					INPUT_ERROR_MSG, ICAS);
		}
	}

	/**
	 * populateAlertResponse
	 * 
	 * @param eupcMockupResponseData
	 */
	public void populateAlertResponse(EUPC_RESPONSE eupcMockupResponseData,
			String dealerName) {
		List<String> alertList = Arrays.asList(dealerName.split(COLON));
		// ALERT should come with format ALERT:ALERTTYPE else input error
		if (alertList.size() > 1) {
			switch (alertList.get(1)) {
			case ALERT_F1:
				constructAlertResponse(eupcMockupResponseData, true, ALERT_F1,
						ALERT_F1_CODE, ALERT_F1_MESSAGE_EN);
				break;
			case ALERT_F2:
				constructAlertResponse(eupcMockupResponseData, true, ALERT_F2,
						ALERT_F2_CODE, ALERT_F2_MESSAGE_EN);
				break;
			case ALERT_F3:
				constructAlertResponse(eupcMockupResponseData, true, ALERT_F3,
						ALERT_F3_CODE, ALERT_F3_MESSAGE_EN);
				break;
			case ALERT_F4:
				constructAlertResponse(eupcMockupResponseData, true, ALERT_F4,
						ALERT_F4_CODE, ALERT_F4_MESSAGE_EN);
				break;
			default:
				populateErrorReponse(eupcMockupResponseData, INPUT_ERROR_CODE,
						INPUT_ERROR_MSG, ICAS);
			}
		} else {
			populateErrorReponse(eupcMockupResponseData, INPUT_ERROR_CODE,
					INPUT_ERROR_MSG, ICAS);
		}
	}

	/**
	 * constructAlertResponse
	 * 
	 * @param response
	 * @param indicator
	 * @param severity
	 * @param code
	 * @param message
	 */
	public void constructAlertResponse(EUPC_RESPONSE response,
			boolean indicator, String severity, String code, String message) {
		response.setStatus(POLICY_STATUS_AR);
		response.setStatusReason(FRAUD);
		response.setWorkListIndicator(indicator);
		response.setWorkListALertSeverity(severity);
		response.setWorkListALertResonCode(code);
		response.setWorkListAlertMessage_en(message);
	}

	/**
	 * populateErrorReponse
	 * 
	 * @param eupcMockupResponseData
	 */
	public void populateErrorReponse(EUPC_RESPONSE eupcMockupResponseData,
			String code, String message, String source) {
		eupcMockupResponseData.setStatus(POLICY_STATUS_AR);
		eupcMockupResponseData.setStatusReason(ERROR);
		eupcMockupResponseData.setErrorCode(code);
		eupcMockupResponseData.setErrorMessage(message);
		eupcMockupResponseData.setErrorsource(source);
	}

	public void populateDocTypeDetails(EUPC_RESPONSE eupcMockupResponseData,
			List<AdditionalDocumentation> docTypelist) {
		eupcMockupResponseData.setAdditionalDocumentRequired(true);
		eupcMockupResponseData.setStatus(POLICY_STATUS_AR);
		eupcMockupResponseData.setStatusReason(POLICY_STATUS_REASON_CODE_FORM);
		eupcMockupResponseData.setAdditionalDocumentations(docTypelist);
	}

	/**
	 * populateMessageResponse
	 * 
	 * @param response
	 */
	public void populateMessageResponse(EUPC_RESPONSE response) {
		response.setMessageCode(MSG_CODE);
		response.setMessageText(MSG_TEXT);
	}

	/**
	 * populateWSHeaderData
	 * 
	 * @param header
	 * @param response
	 */
	public void populateWSHeaderData(WSHeader header, EUPC_RESPONSE response) {		
		if (header != null && header.getWSCallback() != null) {
			String wsCorrelationId = header.getWSCallback()
					.getWSCorrelationId();
			response.setCorrelationId(wsCorrelationId);
		}
		if (header != null && header.getWSConversationId() != null) {
			String wsconservationID = header.getWSConversationId();
			response.setConvesationID(wsconservationID);
		}
	}

	public String[] splitString(String token, String symbol) {

		if (token != null && token.contains(symbol)) {
			return token.split(symbol);
		} else {
			return null;
		}
	}

}
