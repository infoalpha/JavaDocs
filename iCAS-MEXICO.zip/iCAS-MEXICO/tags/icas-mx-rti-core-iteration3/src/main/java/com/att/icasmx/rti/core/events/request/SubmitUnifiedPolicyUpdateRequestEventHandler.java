package com.att.icasmx.rti.core.events.request;



import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.icasmx.rti.constants.ICASMXWorkflowConstants;
import com.att.icasmx.rti.exception.ICASException;
import com.att.icasmx.rti.services.CommonService;
import com.att.icasmx.rti.util.MDCUtil;
import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowEventHandler;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXPolicyCheckRequest;
import com.att.icasmx.rti.ws.SubmitUnifiedMXPolicyUpdateRequest;


/**
 * The Class ExecuteUnifiedCreditCheckRequestHandler.
 */

public class SubmitUnifiedPolicyUpdateRequestEventHandler implements
		WorkflowEventHandler {

	
	private static final Logger LOGGER = LogManager
			.getLogger(SubmitUnifiedPolicyUpdateRequestEventHandler.class
					.getName());
	
	private static final String XMOCK ="XMOCK-";
		
	@Autowired
	CommonService commonService;
	
	

	
	public String execute(EventManager eventManager) {
		try {

			LOGGER.debug("Entering SubmitUnifiedPolicyUpdateRequestEventHandler");
			MDCUtil.setTransactionName("SubmitUnifiedPolicyUpdate");
			commonService.atTransactionAndEventBegin();

			SubmitUnifiedMXPolicyUpdateRequest submitUnifiedMXPolicyUpdateRequest = (SubmitUnifiedMXPolicyUpdateRequest) eventManager
					.getWorkflowData(WorkflowConstants.SUBMIT_UNIFIED_POLICY_UPDATE_REQUEST);

			// Check to invoke MockUpservice
			if (null != submitUnifiedMXPolicyUpdateRequest.getDealerName() ? submitUnifiedMXPolicyUpdateRequest
					.getDealerName().trim().startsWith(XMOCK) : false) {
				LOGGER.debug("Found Mock In Request redircting to SubmitUnifiedMXPolicyUpdateRequest");
				return WorkflowConstants.WORKFLOW_SUPU_MOCK_GEN;
			}

			LOGGER.debug("Exiting SubmitUnifiedMXPolicyUpdateRequest");
			// returns nextstep
			return WorkflowConstants.WORKFLOW_RESULT_SUCCESS;
		} catch (ICASException e) {
			MDCUtil.clear();
			LOGGER.error(e.getMessage());
			// set appropriate next event
			return WorkflowConstants.WORKFLOW_RESULT_FAILURE;
		}
	}

}
