package com.att.icasmx.rti.workflow;

import java.util.Map;

// TODO: Auto-generated Javadoc
/**
 * The Interface WorkflowDataValidator.
 */
public interface WorkflowDataValidator {

	/**
	 * Checks if is valid.
	 *
	 * @param workflowData the workflow data
	 * @param validationRules the validation rules
	 * @return true, if is valid
	 */
	boolean isValid (Map workflowData, Map validationRules);
}
