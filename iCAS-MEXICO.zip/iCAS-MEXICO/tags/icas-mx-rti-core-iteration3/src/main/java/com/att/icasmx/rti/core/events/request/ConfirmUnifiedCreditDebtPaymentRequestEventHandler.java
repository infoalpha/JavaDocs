package com.att.icasmx.rti.core.events.request;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
//Value Objects for ExecuteUnifiedCreditCheckRequest
import org.springframework.beans.factory.annotation.Autowired;

import com.att.icasmx.rti.constants.ICASConstants;
import com.att.icasmx.rti.core.data.EUCC_RSP;
import com.att.icasmx.rti.exception.ICASException;
import com.att.icasmx.rti.services.CommonService;
import com.att.icasmx.rti.services.mock.EUCCMockGenerator;
import com.att.icasmx.rti.util.MDCUtil;
import com.att.icasmx.rti.util.MockUtils;
import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowEventHandler;
import com.att.icasmx.rti.ws.ConfirmUnifiedMXCreditDebtPaymentRequest;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXCreditCheckRequest;
import com.ctc.wstx.util.StringUtil;

/**
 * The Class ExecuteUnifiedCreditCheckRequestHandler.
 */

public class ConfirmUnifiedCreditDebtPaymentRequestEventHandler implements
		WorkflowEventHandler {

	@Autowired
	CommonService commonService;

	private static final Logger LOGGER = LogManager
			.getLogger(ConfirmUnifiedCreditDebtPaymentRequestEventHandler.class
					.getName());

	public String execute(EventManager eventManager) {

		LOGGER.debug("ConfirmUnifiedCreditDebtPaymentRequestEventHandler called");
		MDCUtil.setTransactionName("Transaction Name");
		MDCUtil.setTransactionId("Transaaction ID"); //
		ConfirmUnifiedMXCreditDebtPaymentRequest cudpReq = (ConfirmUnifiedMXCreditDebtPaymentRequest) eventManager
				.getWorkflowData(WorkflowConstants.CONFIRM_UNIFIED_CREDIT_DEBT_REQUEST);
		// eventManager.putWorkflowData(WorkflowConstants.WEBSCHEMA_RQS,
		// cudpReq);
		if (cudpReq.getDealerName() != null
				&& cudpReq.getDealerName().startsWith(
						ICASConstants.XMOCK_DEALER_PATTERN)
				&& !StringUtils.contains(cudpReq.getDealerName(),
						ICASConstants.XMOCK_DEBT)) {
			LOGGER.info("ConfirmUnifiedCreditDebtPaymentRequestEventHandler : Calling Mock Event ");
			return WorkflowConstants.WORKFLOW_MOCK_GEN;
		} else {
			LOGGER.info("ConfirmUnifiedCreditDebtPaymentRequestEventHandler :  Error Scenario ");
			EUCC_RSP euccRes = MockUtils.generateInputError();
			eventManager.putWorkflowData(WorkflowConstants.WORKFLOW_CUDP_RESP,
					euccRes);
			return WorkflowConstants.WORKFLOW_RESULT_SUCCESS;
		}

	}

}
