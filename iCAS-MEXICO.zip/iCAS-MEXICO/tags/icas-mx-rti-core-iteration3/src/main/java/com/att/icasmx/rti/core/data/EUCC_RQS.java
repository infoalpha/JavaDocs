package com.att.icasmx.rti.core.data;

public class EUCC_RQS {
	
	private String dealerName;

	public String getDealerName() {
		return dealerName;
	}

	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}

}
