package com.att.icasmx.rti.core.events.request;



import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.icasmx.rti.exception.ICASException;
import com.att.icasmx.rti.services.CommonService;
import com.att.icasmx.rti.util.MDCUtil;
import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowEventHandler;
import com.att.icasmx.rti.ws.UpdateUnifiedMXPolicyApplicationRequest;


/**
 * The Class UpdateUnifiedPolicyRequestEventHandler.
 */

public class UpdateUnifiedPolicyApplicationRequestEventHandler implements
		WorkflowEventHandler {

	
	private static final Logger LOGGER = LogManager
			.getLogger(UpdateUnifiedPolicyApplicationRequestEventHandler.class
					.getName());
	
	private static final String XMOCK ="XMOCK-";
		
	@Autowired
	CommonService commonService;
	
		
	public String execute(EventManager eventManager) {
		try {

			LOGGER.debug("Entering UpdateUnifiedPolicyRequestEventHandler");
			MDCUtil.setTransactionName("UpdateUnifiedPolicyApplication");
			commonService.atTransactionAndEventBegin();

			UpdateUnifiedMXPolicyApplicationRequest updateUnifiedMXPolicyRequest = (UpdateUnifiedMXPolicyApplicationRequest) eventManager
					.getWorkflowData(WorkflowConstants.UPDATE_UNIFIED_POLICY_REQUEST);

			// Check to invoke MockUpservice
			if (null != updateUnifiedMXPolicyRequest.getDealerCode() ? updateUnifiedMXPolicyRequest
					.getDealerCode().trim().startsWith(XMOCK) : false) {
				LOGGER.debug("Found Mock In Request redircting to UpdateUnifiedPolicyMockEventHandler");
				return WorkflowConstants.WORKFLOW_UUP_MOCK_GEN;
			}

			LOGGER.debug("Exiting UpdateUnifiedPolicyRequestEventHandler");
			// returns nextstep
			return WorkflowConstants.WORKFLOW_RESULT_SUCCESS;
		} catch (ICASException e) {
			MDCUtil.clear();
			LOGGER.error(e.getMessage());
			// set appropriate next event
			return WorkflowConstants.WORKFLOW_RESULT_FAILURE;
		}
	}

}
