package com.att.icasmx.rti.core.data;

import java.util.List;

public class EUCC_RSP {

	private String	creditClass;
	private String	status;
	private String	statusReason;
	private String 	workListIndicator;
	private String 	workListAlertSeverity;
	private String 	workListAlertReasonCode;
	private String 	workListAlertMessage_en;
	private String 	workListAlertMessage_es;
	private String  outstandingDebtIndicator;
	private String  outstandingDebtPastAmountDue;
	private String  outstandingDebtMinAmountDue;
	private String  additionalDocumentationReqIndicator;
	List<AdditionalDocumentation> additionalDoc;
	private String  errorCode ="";
	private String  errorMessage ="";
	private String  errorSource ="";
	
	public String getCreditClass() {
		return creditClass;
	}
	public void setCreditClass(String creditClass) {
		this.creditClass = creditClass;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatusReason() {
		return statusReason;
	}
	public void setStatusReason(String statusReason) {
		this.statusReason = statusReason;
	}
	public String getWorkListIndicator() {
		return workListIndicator;
	}
	public void setWorkListIndicator(String workListIndicator) {
		this.workListIndicator = workListIndicator;
	}
	public String getWorkListAlertSeverity() {
		return workListAlertSeverity;
	}
	public void setWorkListAlertSeverity(String workListAlertSeverity) {
		this.workListAlertSeverity = workListAlertSeverity;
	}
	public String getWorkListAlertReasonCode() {
		return workListAlertReasonCode;
	}
	public void setWorkListAlertReasonCode(String workListAlertReasonCode) {
		this.workListAlertReasonCode = workListAlertReasonCode;
	}
	public String getWorkListAlertMessage_en() {
		return workListAlertMessage_en;
	}
	public void setWorkListAlertMessage_en(String workListAlertMessage_en) {
		this.workListAlertMessage_en = workListAlertMessage_en;
	}
	public String getWorkListAlertMessage_es() {
		return workListAlertMessage_es;
	}
	public void setWorkListAlertMessage_es(String workListAlertMessage_es) {
		this.workListAlertMessage_es = workListAlertMessage_es;
	}
	public String getOutstandingDebtIndicator() {
		return outstandingDebtIndicator;
	}
	public void setOutstandingDebtIndicator(String outstandingDebtIndicator) {
		this.outstandingDebtIndicator = outstandingDebtIndicator;
	}
	public String getOutstandingDebtPastAmountDue() {
		return outstandingDebtPastAmountDue;
	}
	public void setOutstandingDebtPastAmountDue(String outstandingDebtPastAmountDue) {
		this.outstandingDebtPastAmountDue = outstandingDebtPastAmountDue;
	}
	public String getOutstandingDebtMinAmountDue() {
		return outstandingDebtMinAmountDue;
	}
	public void setOutstandingDebtMinAmountDue(String outstandingDebtMinAmountDue) {
		this.outstandingDebtMinAmountDue = outstandingDebtMinAmountDue;
	}
	
	public String getAdditionalDocumentationReqIndicator() {
		return additionalDocumentationReqIndicator;
	}
	public void setAdditionalDocumentationReqIndicator(
			String additionalDocumentationReqIndicator) {
		this.additionalDocumentationReqIndicator = additionalDocumentationReqIndicator;
	}
	
	public List<AdditionalDocumentation> getAdditionalDoc() {
		return additionalDoc;
	}
	public void setAdditionalDoc(List<AdditionalDocumentation> additionalDoc) {
		this.additionalDoc = additionalDoc;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getErrorSource() {
		return errorSource;
	}
	public void setErrorSource(String errorSource) {
		this.errorSource = errorSource;
	}
	
}
