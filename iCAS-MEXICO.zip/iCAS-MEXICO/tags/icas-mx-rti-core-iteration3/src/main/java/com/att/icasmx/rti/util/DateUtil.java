package com.att.icasmx.rti.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

public class DateUtil {

	public static XMLGregorianCalendar dateToXml(Date date){
		  DateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd");
		  String strDate=dateFormat.format(date);
		  try {
		    XMLGregorianCalendar xmlDate=DatatypeFactory.newInstance().newXMLGregorianCalendar(strDate);
		    return xmlDate;
		  }
		 catch (  DatatypeConfigurationException e) {
		    throw new RuntimeException(e);
		  }
		}
	
	
}
