package com.att.icasmx.rti.core.data;

/**
 * @author bb047p
 * 
 *         ICAS Error class
 */
public class ICASError {

	/** The error code. */
	private String errorCode;

	/** The error message in english. */
	private String errorMessage_en;

	/** The error message in spanish. */
	private String errorMessage_es;

	/** The error source code. */
	private String sourceErrorCode;

	/** The error source message in english. */
	private String sourceErrorMessage_en;

	/** The error source message in spanish. */
	private String sourceErrorMessage_es;

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage_en() {
		return errorMessage_en;
	}

	public void setErrorMessage_en(String errorMessage_en) {
		this.errorMessage_en = errorMessage_en;
	}

	public String getErrorMessage_es() {
		return errorMessage_es;
	}

	public void setErrorMessage_es(String errorMessage_es) {
		this.errorMessage_es = errorMessage_es;
	}

	public String getSourceErrorCode() {
		return sourceErrorCode;
	}

	public void setSourceErrorCode(String sourceErrorCode) {
		this.sourceErrorCode = sourceErrorCode;
	}

	public String getSourceErrorMessage_en() {
		return sourceErrorMessage_en;
	}

	public void setSourceErrorMessage_en(String sourceErrorMessage_en) {
		this.sourceErrorMessage_en = sourceErrorMessage_en;
	}

	public String getSourceErrorMessage_es() {
		return sourceErrorMessage_es;
	}

	public void setSourceErrorMessage_es(String sourceErrorMessage_es) {
		this.sourceErrorMessage_es = sourceErrorMessage_es;
	}

	

}
