package com.att.icasmx.rti.workflow;

/*
 * General workflow constants
 * Constants not specific to a particular usage of the workflow go here
 */

/**
 * The Class WorkflowConstants.
 */
public class WorkflowConstants {

	/** The Constant WORKFLOW_INPUT. */
	public static final String WORKFLOW_INPUT = "WORKFLOW_INPUT";

	/** The Constant WORKFLOW_RESULT_NAME. */
	public static final String WORKFLOW_RESULT_NAME = "WORKFLOW_RESULT_NAME";

	// indicator for the end of a workflow
	/** The Constant WORKFLOW_END. */
	public static final String WORKFLOW_END = "WORKFLOW_END";

	// some default workflow values
	/** The Constant WORKFLOW_RESULT_SUCCESS. */
	public static final String WORKFLOW_RESULT_SUCCESS = "success";

	/** The Constant WORKFLOW_RESULT_SUCCESS_BUSINESS. */
	public static final String WORKFLOW_RESULT_SUCCESS_BUSINESS = "success_business";

	/** The Constant WORKFLOW_RESULT_SUCCESS_CONSUMER. */
	public static final String WORKFLOW_RESULT_SUCCESS_CONSUMER = "success_consumer";

	/** The Constant WORKFLOW_RESULT_FAILURE. */
	public static final String WORKFLOW_RESULT_FAILURE = "failure";

	/** The Constant WORKFLOW_RESULT_EXCEPTION. */
	public static final String WORKFLOW_RESULT_EXCEPTION = "exception";

	/** The Constant WORKFLOW_RESULT_CCRINQDEBT. */
	public static final String WORKFLOW_RESULT_CCRINQDEBT = "ccrinqdebt";

	/** The Constant WORKFLOW_RESULT_DUP. */
	public static final String WORKFLOW_RESULT_DUP = "dup";

	/** The Constant WORKFLOW_RESULT_NODUP. */
	public static final String WORKFLOW_RESULT_NODUP = "nodup";

	/** The Constant WORKFLOW_RESULT_UVERSE_E_ORDER. */
	public static final String WORKFLOW_RESULT_UVERSE_E_ORDER = "uverseEOrder";

	/** The Constant WORKFLOW_RESULT_UVERSE_D_ORDER. */
	public static final String WORKFLOW_RESULT_UVERSE_D_ORDER = "uverseDOrder";

	/** The Constant WORKFLOW_RESULT_STUB_REQUEST. */
	public static final String WORKFLOW_RESULT_DEFAULT_RESPONSE = "defaultResp";

	/** The Constant WORKFLOW_RESULT_MOCK_GEN */
	public static final String WORKFLOW_RESULT_MOCK_GEN = "mockgen";

	/** The Constant EXECUTE_UNIFIED_CREDIT_CHECK_WORKFLOW_ID. */
	public static final String EXECUTE_UNIFIED_CREDIT_CHECK_WORKFLOW_ID = "ExecuteUnifiedCreditCheck";

	public static final String SUBMIT_UNIFIED_CREDIT_UPDATE_WORKFLOW_ID = "SubmitUnifiedCreditUpdate";

	public static final String CONFIRM_UNIFIED_CREDITDEBT_PAYMENT_WORKFLOW_ID = "ConfirmUnifiedCreditDebtPayment";

	/** The Constant IUCC_WORKFLOW_ID. */
	public static final String INQUIRE_UNIFIED_CREDIT_CHECK_WORKFLOW_ID = "InquireUnifiedCreditCheck";

	/** The Constant IUPC_WORKFLOW_ID. */
	public static final String INQUIRE_UNIFIED_POLICY_CHECK_WORKFLOW_ID = "InquireUnifiedPolicyCheck";

	/** The Constant ICAS_UC_XCHGSEL_REQ. */
	public static final String EXECUTE_UNIFIED_POLICY_CHECK_REQUEST = "ICASMX_EUPC_REQ";

	/** The Constant ICAS_UC_XCHGSEL_REQ. */
	public static final String EXECUTE_UNIFIED_CREDIT_CHECK_REQUEST = "ICASMX_EUCC_REQ";
	public static final String CONFIRM_UNIFIED_CREDIT_DEBT_REQUEST = "ICASMX_CUCDP_RQS";

	public static final String SUBMIT_UNIFIED_CREDIT_UPDATE_REQUEST = "ICASMX_SUCU_RQS";
	/** The Constant IUCC_REQUEST_ID. */
	public static final String INQUIRE_UNIFIED_CREDIT_CHECK_REQUEST = "ICASMX_IUCC_REQ";

	/** The Constant IUPC_REQUEST_ID. */
	public static final String INQUIRE_UNIFIED_POLICY_CHECK_REQUEST = "ICASMX_IUPC_REQ";

	/** The Constant IUPC_RESPONSE_ID. */
	public static final String IUPC_RESPONSE = "ICASMX_IUPC_RSP";

	/** The Constant ICASMX_EUPC_REQ. */
	public static final String SUBMIT_UNIFIED_POLICY_UPDATE_REQUEST = "ICASMX_SUPU_RQS";

	public static final String WORKFLOW_EUCC_MOCK_GEN = "euccmockgen";

	public static final String EUPC_MOCK_RESPONSE_DATA = "EUPC_MOCK_RESPONSE_DATA";

	public static final String WORKFLOW_MOCK_GEN = "mockgen";

	public static final String WORKFLOW_EUCC_RESP = "eucc_rsp";
	public static final String WORKFLOW_CUDP_RESP = "cucdp_rsp";
	public static final String WORKFLOW_SUCU_RESP = "sucu_rsp";

	public static final String WEBSCHEMA_RQS = "WEBSCHEMA_RQS";

	public static final String WORKFLOW_EUPC_MOCK_GEN = "eupcmockgen";

	public static final String SUPU_MOCK_RESPONSE_DATA = "SUPU_MOCK_RESPONSE_DATA";
	
	 public static final String WORKFLOW_SUPU_MOCK_GEN = "supumockgen";

	/** The Constant EXECUTE_UNIFIED_POLICY_CHECK_WORKFLOW_ID. */
	public static final String EXECUTE_UNIFIED_POLICY_CHECK_WORKFLOW_ID = "ExecuteUnifiedPolicyCheck";

	/** The Constant SUBMIT_UNIFIED_POLICY_UPDATE_WORKFLOW_ID. */
	public static final String SUBMIT_UNIFIED_POLICY_UPDATE_WORKFLOW_ID = "SubmitUnifiedPolicyUpdate";

	/** The Constant WORKFLOW_RESULT_NAME_CREDIT_RESULT_MOCKUP. */
	public static final String WORKFLOW_RESULT_NAME_POLICY_RESULT_MOCKUP = "WorkflowResultMockupPolicyResult";

	/** The Constant WORKFLOW_RESULT_NAME_CREDIT_RESULT_MOCKUP. */
	public static final String WORKFLOW_RESULT_NAME_POLICY_UPDATE_RESULT_MOCKUP = "WorkflowResultMockupPolicyUpdateResult";

	public static final String UPDATE_UNIFIED_POLICY_WORKFLOW_ID = "UpdateUnifiedPolicyApplication";

	public static final String UPDATE_UNIFIED_POLICY_REQUEST = "ICASMX_UUP_REQ";

	public static final String WORKFLOW_UUP_MOCK_GEN = "uupmockgen";
	
	public static final String CREDIT_TYPE="CREDIT";
	
	public static final String POLICY_TYPE="POLICY";
	
}
