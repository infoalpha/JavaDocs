package com.att.icasmx.rti.core.events.mock;

import org.springframework.beans.factory.annotation.Autowired;

import com.att.icasmx.rti.core.data.EUCC_RSP;
import com.att.icasmx.rti.services.mock.EUCCMockGenerator;
import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowEventHandler;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXCreditCheckRequest;

public class ExecuteUnifiedCreditCheckMockEventHandler implements
WorkflowEventHandler {

	@Autowired 
	EUCCMockGenerator euccMock;
	
	@Override
	public String execute(EventManager eventManager) {
		EUCC_RSP euccRes;
		ExecuteUnifiedMXCreditCheckRequest euccReq = (ExecuteUnifiedMXCreditCheckRequest) eventManager
				.getWorkflowData(WorkflowConstants.EXECUTE_UNIFIED_CREDIT_CHECK_REQUEST);
		euccRes= euccMock.generateEUCCMock(euccReq.getDealerName());
		eventManager.putWorkflowData(WorkflowConstants.WORKFLOW_EUCC_RESP, euccRes);
		return WorkflowConstants.WORKFLOW_RESULT_SUCCESS;
	}

}
