package com.att.icasmx.rti.workflow;

import java.util.Map;

// TODO: Auto-generated Javadoc
/**
 * The Interface EventManager.
 */
public interface EventManager {

	/**
	 * Gets the results.
	 *
	 * @return the results
	 */
	public Map getResults();
	
	/**
	 * Sets the results.
	 *
	 * @param results the new results
	 */
	public void setResults(Map results);
	
	/**
	 * Gets the next event.
	 *
	 * @param result the result
	 * @return the next event
	 */
	public String getNextEvent(String result);
	
	/**
	 * Gets the inputs.
	 *
	 * @return the inputs
	 */
	public Map getInputs();
	
	/**
	 * Sets the inputs.
	 *
	 * @param inputs the new inputs
	 */
	public void setInputs(Map inputs);
	
	/**
	 * Gets the outputs.
	 *
	 * @return the outputs
	 */
	public Map getOutputs();
	
	/**
	 * Sets the outputs.
	 *
	 * @param outputs the new outputs
	 */
	public void setOutputs(Map outputs);
	
	/**
	 * Checks if is input valid.
	 *
	 * @param validator the validator
	 * @return true, if is input valid
	 */
	public boolean isInputValid(WorkflowDataValidator validator);
	
	/**
	 * Checks if is output valid.
	 *
	 * @param validator the validator
	 * @return true, if is output valid
	 */
	public boolean isOutputValid(WorkflowDataValidator validator);
	
	/**
	 * Checks if is workflow end.
	 *
	 * @param result the result
	 * @return true, if is workflow end
	 */
	public boolean isWorkflowEnd(String result);
	
	/**
	 * Event end.
	 *
	 * @param result the result
	 * @return the string
	 */
	public String eventEnd(String result);
	
	/**
	 * Event end.
	 *
	 * @param result the result
	 * @param key the key
	 * @param data the data
	 * @return the string
	 */
	public String eventEnd(String result, String key, Object data);
	
	/**
	 * Sets the workflow data map.
	 *
	 * @param workflowDataMap the new workflow data map
	 */
	public void setWorkflowDataMap(Map workflowDataMap);
	
	/**
	 * Gets the workflow data map.
	 *
	 * @return the workflow data map
	 */
	public Map getWorkflowDataMap();
	
	/**
	 * Gets the workflow data.
	 *
	 * @param key the key
	 * @return the workflow data
	 */
	public Object getWorkflowData(String key);
	
	/**
	 * Put workflow data.
	 *
	 * @param key the key
	 * @param data the data
	 */
	public void putWorkflowData(String key, Object data);
	
	/**
	 * Gets the event.
	 *
	 * @return the event
	 */
	public WorkflowEventHandler getEvent();
	
	/**
	 * Sets the event handler.
	 *
	 * @param eventHandler the new event handler
	 */
	public void setEventHandler(WorkflowEventHandler eventHandler);
	
	/**
	 * Execute event.
	 *
	 * @return the string
	 */
	public String executeEvent();
}
