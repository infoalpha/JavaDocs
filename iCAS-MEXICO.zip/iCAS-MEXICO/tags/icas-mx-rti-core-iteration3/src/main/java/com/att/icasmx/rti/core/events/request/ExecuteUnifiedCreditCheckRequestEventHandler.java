package com.att.icasmx.rti.core.events.request;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
//Value Objects for ExecuteUnifiedCreditCheckRequest
import org.springframework.beans.factory.annotation.Autowired;

import com.att.icasmx.rti.constants.ICASConstants;
import com.att.icasmx.rti.core.data.EUCC_RSP;
import com.att.icasmx.rti.exception.ICASException;
import com.att.icasmx.rti.services.CommonService;
import com.att.icasmx.rti.util.MDCUtil;
import com.att.icasmx.rti.util.MockUtils;
import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowEventHandler;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXCreditCheckRequest;

/**
 * The Class ExecuteUnifiedCreditCheckRequestHandler.
 */

public class ExecuteUnifiedCreditCheckRequestEventHandler implements
		WorkflowEventHandler {


	@Autowired
	CommonService commonService;

	private static final Logger LOGGER = LogManager
			.getLogger(ExecuteUnifiedCreditCheckRequestEventHandler.class
					.getName());

	public String execute(EventManager eventManager) {
	
			LOGGER.debug("ExecuteUnifiedCreditCheckRequestHandler called");
			MDCUtil.setTransactionName("Transaction Name");
			MDCUtil.setTransactionId("Transaaction ID"); //
			ExecuteUnifiedMXCreditCheckRequest euccReq = (ExecuteUnifiedMXCreditCheckRequest) eventManager
					.getWorkflowData(WorkflowConstants.EXECUTE_UNIFIED_CREDIT_CHECK_REQUEST);
			if (euccReq.getDealerName() != null
					&& euccReq.getDealerName().startsWith(ICASConstants.XMOCK_DEALER_PATTERN)) {
				// Generate Mock Event euccmockService.parse(euccReq);
				return WorkflowConstants.WORKFLOW_MOCK_GEN;
			} else {
				LOGGER.debug("ERROR : EUCC REQ HANDLER ");
				EUCC_RSP euccRes = MockUtils.generateInputError();
				eventManager.putWorkflowData(WorkflowConstants.WORKFLOW_EUCC_RESP,euccRes);
				return WorkflowConstants.WORKFLOW_RESULT_FAILURE;	
			}		
			
		
	}

}
