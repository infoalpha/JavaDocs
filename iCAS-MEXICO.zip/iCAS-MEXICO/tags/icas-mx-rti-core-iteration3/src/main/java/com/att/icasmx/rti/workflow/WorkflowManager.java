package com.att.icasmx.rti.workflow;

import com.att.icasmx.rti.workflow.WorkflowManager;
import com.att.icasmx.rti.workflow.Workflow;
import com.att.icasmx.rti.workflow.WorkflowException;
import com.att.icasmx.rti.workflow.WorkflowHashMap;
import com.att.icasmx.rti.workflow.WorkflowResult;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

/**
 * WorkFlow Manager For all events
 */

public class WorkflowManager {

	/** The logger. */
	private static Logger logger = LogManager.getLogger(WorkflowManager.class
			.getName());

	// private static WorkflowManager instance;
	/** The workflows. */
	HashMap workflows = new HashMap();

	// constructor
	/**
	 * Instantiates a new workflow manager.
	 */
	public WorkflowManager() {
	}

	/**
	 * Gets the workflow.
	 * 
	 * @param workflowId
	 *            the workflow id
	 * @return the workflow
	 * @throws WorkflowException
	 *             the workflow exception
	 */
	public Workflow getWorkflow(String workflowId) throws WorkflowException {
		Workflow workflow;

		workflow = (Workflow) workflows.get(workflowId);

		if (workflow == null) {
			throw new WorkflowException("Workflow not found for workflowId: "
					+ workflowId);
		}

		return workflow;
	}

	// Takes an input object and begins executing workflow
	/**
	 * Execute.
	 * 
	 * @param workflowId
	 *            the workflow id
	 * @param object
	 *            the object
	 * @return the workflow result
	 * @throws WorkflowException
	 *             the workflow exception
	 */
	public WorkflowResult execute(String workflowId, Object object) {
		logger.debug("Workflow Manager: execute");
		// uses a default name for the starting input object
		return this.execute(workflowId, WorkflowConstants.WORKFLOW_INPUT,
				object);
	}

	// Takes an input object and begins executing workflow
	/**
	 * Execute.
	 * 
	 * @param workflowId
	 *            the workflow id
	 * @param objectName
	 *            the object name
	 * @param object
	 *            the object
	 * @return the workflow result
	 * @throws WorkflowException
	 *             the workflow exception
	 */
	public WorkflowResult execute(String workflowId, String objectName,
			Object object) {
		WorkflowHashMap workflowData = new WorkflowHashMap();
		workflowData.put(objectName, object);

		WorkflowResult result = new WorkflowResult();
		List<String> workflowHistory = new ArrayList<String>();

		Workflow workflow = null;
		workflow = getWorkflow(workflowId);

		// determine where to start
		String event = workflow.getFirstEvent();

		// loop until there are no more actions to take
		while (event != null) {

			if (logger.isDebugEnabled()) {// Invoke the action
				logger.debug("Invoking event: " + event);
			}
			// keep track of which events were invoked for exposing to client
			workflowHistory.add(event);

			event = workflow.invokeEvent(event, workflowData);

			if (logger.isDebugEnabled()) {
				logger.debug("Next event after invocation: " + event);
			}
		}

		// create the result object & return
		result.setResult(workflow.getOutput());
		result.setResultName(workflow.getOutputType());
		result.setWorkflowHistory(workflowHistory);
		return result;
	}

	/**
	 * Sets the workflows.
	 * 
	 * @param workflows
	 *            the new workflows
	 */
	public void setWorkflows(HashMap workflows) {
		this.workflows = workflows;
	}
}
