package com.att.icasmx.rti.services.impl;

import org.springframework.stereotype.Service;

import com.att.icasmx.rti.exception.ICASException;
import com.att.icasmx.rti.services.CommonService;

/**
 * @author vk4235 Class CommonServiceImpl
 * 
 */
@Service
public class CommonServiceImpl implements CommonService {

	/**
	 * atTransactionAndEventBegin
	 * 
	 * @throws ICASException
	 */
	public void atTransactionAndEventBegin() throws ICASException {

	}

	/**
	 * atTransactionAndEventEnd
	 * 
	 * @throws ICASException
	 */
	public void atTransactionAndEventEnd() throws ICASException {

	}

}
