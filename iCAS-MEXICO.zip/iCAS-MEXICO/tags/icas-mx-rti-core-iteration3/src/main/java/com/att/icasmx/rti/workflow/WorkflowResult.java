package com.att.icasmx.rti.workflow;

import java.util.Collection;

public class WorkflowResult {
	
	/** The result name. */
	String resultName;
	
	/** The workflow history. */
	Collection workflowHistory;
	
	/** The result. */
	Object result;

	/**
	 * @return the resultName
	 */
	public String getResultName() {
		return resultName;
	}

	/**
	 * @param resultName the resultName to set
	 */
	public void setResultName(String resultName) {
		this.resultName = resultName;
	}

	/**
	 * @return the workflowHistory
	 */
	public Collection getWorkflowHistory() {
		return workflowHistory;
	}

	/**
	 * @param workflowHistory the workflowHistory to set
	 */
	public void setWorkflowHistory(Collection workflowHistory) {
		this.workflowHistory = workflowHistory;
	}

	/**
	 * @return the result
	 */
	public Object getResult() {
		return result;
	}

	/**
	 * @param result the result to set
	 */
	public void setResult(Object result) {
		this.result = result;
	}


	
}
