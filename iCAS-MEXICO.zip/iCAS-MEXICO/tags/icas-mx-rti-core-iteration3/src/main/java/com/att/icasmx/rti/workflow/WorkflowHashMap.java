package com.att.icasmx.rti.workflow;


import java.util.HashMap;


// TODO: Auto-generated Javadoc
/*
 * A Map that keeps track of the last (most recent) addition.
 */

/**
 * The Class WorkflowHashMap.
 */
public class WorkflowHashMap extends HashMap {
	
	/** The last put key. */
	private String lastPutKey;
	
	// override
	/**
	 * Put.
	 *
	 * @param key the key
	 * @param value the value
	 */
	public void put(String key, Object value) {
		super.put(key, value);
		lastPutKey = key;
	}
	
	/**
	 * Gets the most recent entry.
	 *
	 * @return the most recent entry
	 */
	public Object getMostRecentEntry() {
		return super.get(lastPutKey);
	}
}
