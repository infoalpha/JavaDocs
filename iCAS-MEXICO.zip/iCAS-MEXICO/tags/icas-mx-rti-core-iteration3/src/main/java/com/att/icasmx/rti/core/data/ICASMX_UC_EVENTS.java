package com.att.icasmx.rti.core.data;

import java.sql.Timestamp;

/**
 * AbstractIcasUcEvents entity provides the base persistence definition of the
 * IcasUcEvents entity. @author MyEclipse Persistence Tools
 */

public class ICASMX_UC_EVENTS implements java.io.Serializable {

	// Fields

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4618376320298912112L;

	/*
	 * Event Names for ExecuteUnifiedCreditCheck Workflow
	 */
	/** The Constant EVENT_NANE_EUCCHK_REQ. */
	public static final String EVENT_NANE_EUCCHK_REQ = "EUCCHK_REQ";
	
	/** The Constant EVENT_NANE_IC_INQKEY. */
	public static final String EVENT_NAME_IC_INQKEY = "IC_INQKEY";
	
	/** The Constant EVENT_NANE_CCR_INQDEBT. */
	public static final String EVENT_NANE_CCR_INQDEBT = "CCR_INQDEBT";
	
	/** The Constant EVENT_NANE_CAS_EUCCHK. */
	public static final String EVENT_NANE_CAS_EUCCHK = "CAS_EUCCHK";
	
	/** The Constant EVENT_NANE_EUCCHK_RSLT. */
	public static final String EVENT_NANE_EUCCHK_RSLT = "EUCCHK_RSLT";
	
	/** The Constant EVENT_NANE_DEFAULT_GENERATOR. */
	public static final String EVENT_NANE_DEFAULT_GENERATOR = "DEFAULT_GENERATOR";
	
	/** The Constant EVENT_NANE_MOCKUP_GENERATOR. */
	public static final String EVENT_NANE_MOCKUP_GENERATOR = "MOCKUP_GENERATOR";
	
	/** The Constant EVENT_NAME_KEY_ANALYSIS. */
	public static final String EVENT_NAME_KEY_ANALYSIS = "KEY_ANALYSIS";
	
	/** The Constant EVENT_NANE_CFM_INQBAL. */
	public static final String EVENT_NANE_CFM_INQBAL = "CFM_INQBAL";	
	
	/** The Constant EVENT_NANE_CAPM_INQPMTS. */
	public static final String EVENT_NANE_CAPM_INQPMTS = "CAPM_INQPMTS";	

	/*
	 * Event names for InquireUnifiedCreditPolicy (IUCP)
	 */
	/** The Constant EVENT_NAME_IUCP_REQ. */
	public static final String EVENT_NAME_IUCP_REQ = "IUCP_REQ";
	
	/** The Constant EVENT_NAME_IUCP_ACK. */
	public static final String EVENT_NAME_IUCP_ACK = "IUCP_ACK";
	
	/** The Constant EVENT_NANE_CAS_IUCP. */
	public static final String EVENT_NANE_CAS_IUCP = "CAS_IUCP";
	
	/** The Constant STEP_TYPE_CAS_IUCP_SYNC. */
	public static final String STEP_TYPE_CAS_IUCP_SYNC = "CAS_IUCP_SYNC";
	
	/** The Constant EVENT_NAME_PUCP_REQ. */
	public static final String EVENT_NAME_PUCP_REQ = "PUCP_REQ";	
	
	/** The Constant EVENT_NAME_PUCP_RSLT. */
	public static final String EVENT_NAME_PUCP_RSLT = "PUCP_RSLT";	
	
	/** The Constant RESULT_TYPE_PUCP_RSLT. */
	public static final String RESULT_TYPE_PUCP_RSLT = "PUCPRSLT";	

	/*
	 * Event names for eID workflows
	 */
	/** The Constant EVENT_NAME_INQEID_REQ. */
	public static final String EVENT_NAME_INQEID_REQ = "INQEID_REQ";
	
	/** The Constant EVENT_NAME_INQEID_RSLT. */
	public static final String EVENT_NAME_INQEID_RSLT = "INQEID_RSLT";
	
	/** The Constant EVENT_NAME_VALEID_REQ. */
	public static final String EVENT_NAME_VALEID_REQ = "VALEID_REQ";
	
	/** The Constant EVENT_NAME_VALEID_RSLT. */
	public static final String EVENT_NAME_VALEID_RSLT = "VALEID_RSLT";
	
	/** The Constant EVENT_NAME_IC_INQEID. */
	public static final String EVENT_NAME_IC_INQEID = "IC_INQEID";
	
	/** The Constant EVENT_NAME_IC_VALEID. */
	public static final String EVENT_NAME_IC_VALEID = "IC_VALEID";

	// CAS related
	/** The Constant EVENT_NAME_CAS_INQAPP. */
	public static final String EVENT_NAME_CAS_INQAPP = "CAS_INQAPP";
	
	/** The Constant EVENT_NAME_CAS_UPDEID. */
	public static final String EVENT_NAME_CAS_UPDEID = "CAS_UPDEID";

	/** Check for Duplicates and Overrides */
	public static final String EVENT_NAME_DUPCHECK = "DUPCHECK";
	
	/*
	 * Step Types for ExecuteUnifiedCreditCheck Workflow
	 */
	/** The Constant STEP_TYPE_CAS_EUCCHK_SYNC. */
	public static final String STEP_TYPE_CAS_EUCCHK_SYNC = "CAS_EUCCHK_SYNC";
	
	/** The Constant STEP_TYPE_CAS_EUCCHK_ASYNC. */
	public static final String STEP_TYPE_CAS_EUCCHK_ASYNC = "CAS_EUCCHK_ASYNC";

	/*
	 *  Step Types for SubmitUnifiedCreditApplication Workflow
	 */
	/** The Constant STEP_TYPE_CAS_EXCHGSEL_SYNC. */
	public static final String STEP_TYPE_CAS_EXCHGSEL_SYNC = "CAS_EXCHGSEL_SYNC";
	
	/** The Constant STEP_TYPE_CAS_EXCHGSEL_ASYNC. */
	public static final String STEP_TYPE_CAS_EXCHGSEL_ASYNC = "CAS_EXCHGSEL_ASYNC";

	/*
	 * Step Types for ConfirmUnifiedCreditAccountDebtPayment
	 */
	/** The Constant STEP_TYPE_CAS_CDEBTPMT_SYNC. */
	public static final String STEP_TYPE_CAS_CDEBTPMT_SYNC = "CAS_CDEBTPMT_SYNC";
	
	/** The Constant STEP_TYPE_CAS_CDEBTPMT_ASYNC. */
	public static final String STEP_TYPE_CAS_CDEBTPMT_ASYNC = "CAS_CDEBTPMT_ASYNC";

	/*
	 * Step Types for WorkListResumeUnifiedCreditCheck
	 */
	/** The Constant STEP_TYPE_CAS_CDEBTPMT_SYNC. */
	public static final String STEP_TYPE_CAS_WLRUCC_SYNC = "CAS_WLRUCC_SYNC";

	/** The Constant STEP_TYPE_CAS_CDEBTPMT_ASYNC. */
	public static final String STEP_TYPE_CAS_WLRUCC_ASYNC = "CAS_WLRUCC_ASYNC";

	/*
	 * Event Status
	 */
	/** The Constant EVENT_STATUS_COMPLETE. */
	public static final String EVENT_STATUS_COMPLETE = "CMPLT";						//Complete
	
	/** The Constant EVENT_STATUS_ERROR. */
	public static final String EVENT_STATUS_ERROR = "ERR";							//Error
	
	/** The Constant EVENT_STATUS_EXCEPTION. */
	public static final String EVENT_STATUS_EXCEPTION = "EXCP";						//Exception
	
	/** The Constant EVENT_STATUS_TIMEOUT. */
	public static final String EVENT_STATUS_TIMEOUT = "TMOUT";						//Timeout

	/*
	 * Result Types for ExecuteUnifiedCreditCheck Workflow
	 */
	/** The Constant RESULT_TYPE_CAS_CREDRESULT. */
	public static final String RESULT_TYPE_CAS_CREDRESULT = "CREDRSLT";				//Credit Result
	
	/** The Constant RESULT_TYPE_CAS_EXCHGLIST. */
	public static final String RESULT_TYPE_CAS_EXCHGLIST = "EXCHGLIST";				//Exchange List
	
	/** The Constant RESULT_TYPE_CAS_ACCTDEBT. */
	public static final String RESULT_TYPE_CAS_ACCTDEBT = "ACCTDEBT";				//Account Debt
	
	/** The Constant RESULT_TYPE_GENMSG. */
	public static final String RESULT_TYPE_GENMSG = "GENMSG";						//General Message
	
	/** The Constant RESULT_TYPE_ERRMSG. */
	public static final String RESULT_TYPE_ERRMSG = "ERRMSG";						//Error Message
	
	/** The Constant RESULT_TYPE_EXCEPTION. */
	public static final String RESULT_TYPE_EXCEPTION = "EXCEPT";					//Exception
	
	/** The Constant RESULT_TYPE_DEFAULT_CREDRESULT. */
	public static final String RESULT_TYPE_DEFAULT_CREDRESULT = "DFLTCRED";			//Default Credit Result
	
	/** The Constant RESULT_TYPE_MOCKUP_CREDRESULT. */
	public static final String RESULT_TYPE_MOCKUP_CREDRESULT = "MOCKCRED";			//Default Credit Result
	
	/** The Constant RESULT_TYPE_EUCCHK_REQ. */
	public static final String RESULT_TYPE_EUCCHK_REQ = "EUCCHK_REQ";				//Credit Check Request
	
	/** The Constant RESULT_TYPE_APPLICANT_MESSAGE. */
	public static final String RESULT_TYPE_APPLICANT_MESSAGE = "APPLMSG";			//4000/Applicant Message

	/*
	 * Result types for eID workflows
	 */
	/** The Constant RESULT_TYPE_CAS_APPLREC. */
	public static final String RESULT_TYPE_CAS_APPLREC = "CASAPPLREC";
	
	/** The Constant RESULT_TYPE_IC_INQEID_RSP_6101. */
	public static final String RESULT_TYPE_IC_INQEID_RSP_6101 = "IC_INQEIDRSP_6101";
	
	/** The Constant RESULT_TYPE_IC_VEREID_RSP_6100. */
	public static final String RESULT_TYPE_IC_VEREID_RSP_6100 = "IC_VEREIDRSP_6100";
	
	/** The Constant RESULT_TYPE_INQEID_RQS. */
	public static final String RESULT_TYPE_INQEID_RQS = "INQEID_RQS";
	
	/** The Constant RESULT_TYPE_INQEID_RSLT. */
	public static final String RESULT_TYPE_INQEID_RSLT = "INQEID_RSLT";
	
	/** The Constant RESULT_TYPE_VALEID_RQS. */
	public static final String RESULT_TYPE_VALEID_RQS = "VALEID_RQS";
	
	/** The Constant RESULT_TYPE_VALEID_RSLT. */
	public static final String RESULT_TYPE_VALEID_RSLT = "VALEID_RSLT";

	/*
	 * Event Names for UpdateUnifiedCreditApplication Workflow
	 */
	/** The Constant EVENT_NAME_UPDAPP_REQ. */
	public static final String EVENT_NAME_UPDAPP_REQ = "UPDAPP_REQ";
	
	/** The Constant EVENT_NAME_CAS_UPDAPP. */
	public static final String EVENT_NAME_CAS_UPDAPP = "CAS_UPDAPP";
	
	/** The Constant EVENT_NAME_CAS_UPDAPP_STS. */
	public static final String EVENT_NAME_CAS_UPDAPP_STS = "CAS_UPDAPP_STS";
	
	/** The Constant EVENT_NAME_UPDAPP_RSLT. */
	public static final String EVENT_NAME_UPDAPP_RSLT = "UPDAPP_RSLT";
	
	/** The Constant RESULT_TYPE_DEFAULT_UPDAPPRESULT. */
	public static final String RESULT_TYPE_DEFAULT_UPDAPPRESULT = "DFLTUPDAPP";			//Default Update Result	

	/*
	 * Event Names for SubmitUnifiedCreditApplication Workflow
	 */
	/** The Constant EVENT_NAME_EXCHGSEL_REQ. */
	public static final String EVENT_NAME_EXCHGSEL_REQ = "EXCHGSEL_REQ";
	
	/** The Constant EVENT_NAME_CAS_EXCHGSEL. */
	public static final String EVENT_NAME_CAS_EXCHGSEL = "CAS_EXCHGSEL";
	
	/** The Constant EVENT_NAME_EXCHGSEL_RSLT. */
	public static final String EVENT_NAME_EXCHGSEL_RSLT = "EXCHGSEL_RSLT";
	
	/** The Constant EVENT_NAME_SUCA_APPLICANT_DETAIL_REQ. */
	public static final String EVENT_NAME_SUCA_APPLICANT_DETAIL_REQ = "SUCAADETAIL_REQ";
	
	/** The Constant EVENT_NAME_SUCA_APPLICANT_DETAIL_RSLT. */
	public static final String EVENT_NAME_SUCA_APPLICANT_DETAIL_RSLT = "SUCAADETAIL_RSLT";

	/*
	 * Event Name for ConfirmUnifiedCreditAccountDebtPayment
	 */
	/** The Constant EVENT_NAME_CDEBTPMT_REQ. */
	public static final String EVENT_NAME_CDEBTPMT_REQ = "CDEBTPMT_REQ";
	
	/** The Constant EVENT_NAME_CAS_CDEBTPMT. */
	public static final String EVENT_NAME_CAS_CDEBTPMT = "CAS_CDEBTPMT";
	
	/** The Constant EVENT_NAME_CAS_CDEBTPMT_MOBILITY. */
	public static final String EVENT_NAME_CAS_CDEBTPMT_MOBILITY = "CAS_CDEBTPMT_MOB";
	
	/** The Constant EVENT_NAME_CDEBTPMT_RSLT. */
	public static final String EVENT_NAME_CDEBTPMT_RSLT = "CDEBTPMT_RSLT";


	/** The Constant RESULT_TYPE_NOMSG. */
	public static final String RESULT_TYPE_NOMSG = "NOMSG";

	/*
	 * Events Names for InquireUnifiedCreditAccountDebtDetails workflow
	 */
	/** The Constant EVENT_NAME_INQDEBT_REQ. */
	public static final String EVENT_NAME_INQDEBT_REQ = "INQDEBT_REQ";
	
	/** The Constant EVENT_NAME_CAS_INQDEBT. */
	public static final String EVENT_NAME_CAS_INQDEBT = "CAS_INQDEBT";
	
	/** The Constant EVENT_NAME_INQDEBT_RSLT. */
	public static final String EVENT_NAME_INQDEBT_RSLT = "INQDEBT_RSLT";

	/** The Constant RESULT_TYPE_INQDEBT_RQS. */
	public static final String RESULT_TYPE_INQDEBT_RQS = "INQDEBT_RQS";
	
	/** The Constant RESULT_TYPE_CAS_INQDEBT. */
	public static final String RESULT_TYPE_CAS_INQDEBT = "INQDEBT_RSLT";
	
	/** The Constant RESULT_TYPE_INQDEBT_RSLT. */
	public static final String RESULT_TYPE_INQDEBT_RSLT = "INQDEBT_RSLT";

	/** The Constant RESULT_TYPE_UPDAPP_RQS. */
	public static final String RESULT_TYPE_UPDAPP_RQS = "UPDAPP_RQS";
	
	/** The Constant RESULT_TYPE_UPDAPP_RSLT. */
	public static final String RESULT_TYPE_UPDAPP_RSLT = "UPDAPP_RSLT";

	/*
	 * Events Names for CASInquirePersistentKeyDebtsWorkflow workflow
	 */
	/** The Constant EVENT_NAME_CASINQKEY_REQ. */
	public static final String EVENT_NAME_CASINQKEY_REQ = "CASINQKEY_REQ";
	
	/** The Constant EVENT_NAME_CASINQKEY_RSLT. */
	public static final String EVENT_NAME_CASINQKEY_RSLT = "CASINQKEY_RSLT";

	/** The Constant RESULT_TYPE_CASINQKEY_RQS. */
	public static final String RESULT_TYPE_CASINQKEY_RQS = "CASINQKEY_RQS";
	
	/** The Constant RESULT_TYPE_CASINQKEY_RSLT. */
	public static final String RESULT_TYPE_CASINQKEY_RSLT = "CASINQKEY_RSLT";

	/** The Constant RESULT_TYPE_UNKNOWNMSG. */
	public static final String RESULT_TYPE_UNKNOWNMSG = "UNKNOWNMSG";
	
	/** The Constant STEP_TYPE_CAS_UPDAPP_ASYNC. */
	public static final String STEP_TYPE_CAS_UPDAPP_ASYNC = "CAS_UPDAPP_ASYNC";
	
	/** The Constant STEP_TYPE_CAS_UPDAPP_SYNC. */
	public static final String STEP_TYPE_CAS_UPDAPP_SYNC = "CAS_UPDAPP_SYNC";
	
	/** The Constant STEP_TYPE_CAS_UPDAPPSTAT_ASYNC. */
	public static final String STEP_TYPE_CAS_UPDAPPSTAT_ASYNC = "CAS_UPDAPPSTAT_ASYNC";

	/** The Constant STEP_TYPE_CAS_UPDAPPSTAT_SYNC. */
	public static final String STEP_TYPE_CAS_UPDAPPSTAT_SYNC = "CAS_UPDAPPSTAT_SYNC";

	/** The Constant EVENT_NAME_IC_UPDAPP. */
	public static final String EVENT_NAME_IC_UPDAPP = "IC_UPDAPP";
	
	/** The Constant EVENT_NAME_IC_UPDAPPSTAT. */
	public static final String EVENT_NAME_IC_UPDAPPSTAT = "IC_UPDAPPSTAT";

	/** The Constant RESULT_TYPE_IC_UPDAPP_RSP_6000. */
	public static final String RESULT_TYPE_IC_UPDAPP_RSP_6000 = "IC_UPDAPP_6000";
	
	/** The Constant RESULT_TYPE_IC_UPDAPPSTAT_RSP_6000. */
	public static final String RESULT_TYPE_IC_UPDAPPSTAT_RSP_6000 = "IC_UPDAPPSTAT_6000";

	/** The Constant EVENT_NAME_WORKITEM_UPDATE. */
	public static final String EVENT_NAME_WORKITEM_UPDATE = "WORKITEM_UPDATE";

	/** The Constant RESULT_TYPE_CAS_NOTIFICATION_SUCCESS. */
	public static final String RESULT_TYPE_CAS_NOTIFICATION_SUCCESS = "CAS_NOTIFY_OK";
	
	/** The Constant RESULT_TYPE_CAS_NOTIFICATION_ERROR. */
	public static final String RESULT_TYPE_CAS_NOTIFICATION_ERROR = "CAS_NOTIFY_ERR";

	
	/** The constants for IUCCR workflow */
	public static final String 	EVENT_NAME_IUCCR_REQ = "IUCCR_REQ";
	
	/** The Constant EVENT_NAME_CAS_IUCCR. */
	public static final String EVENT_NAME_CAS_IUCCR = "CAS_IUCCR";
	
	/** The Constant EVENT_NAME_IUCCR_RSLT. */
	public static final String EVENT_NAME_IUCCR_RSLT = "IUCCR_RSLT";
	
	/** The Constant RESULT_TYPE_IUCCR_RQS. */
	public static final String RESULT_TYPE_IUCCR_RQS = "IUCCR_RQS";
	
	public static final String RESULT_TYPE_IUCCR_MOCKUP = "IUCCR_MOCKUP";
	
	/** The Constant RESULT_TYPE_CAS_IUCCR. */
	public static final String RESULT_TYPE_CAS_IUCCR = "CAS_IUCCR";
	
	/** The Constant RESULT_TYPE_IUCCR_RSLT. */
	public static final String RESULT_TYPE_IUCCR_RSLT = "IUCCR_RSLT";

	/*
	 * Events Names for WorkListResumeUnifiedCreditCheck workflow
	 */
	/** The WorkListResumeUnifiedCreditCheck request event. */
	public static final String EVENT_NAME_WLRUCC_REQ = "WLRUCC_REQ";
	
	/** The CAS WorkListResumeUnifiedCreditCheck event. */
	public static final String EVENT_NAME_CAS_WLRUCC = "CAS_WLRUCC";
	
	/** The WorkListResumeUnifiedCreditCheck result event. */
	public static final String EVENT_NAME_WLRUCC_RSLT = "WLRUCC_RSLT";
	
	/** The Constant RESULT_TYPE_WLRUCC_RQA. */
	public static final String RESULT_TYPE_WLRUCC_RQS = "WLRUCC_RQS";
	
	/** The Constant RESULT_TYPE_WLRUCC_RSLT. */
	public static final String RESULT_TYPE_WLRUCC_RSLT = "WLRUCC_RSLT";

	/*
	 * Variables
	 */
	/** The event id. */
	private long eventId;
	
	/** The transaction id. */
	private String transactionId;
	
	/** The transaction seq. */
	private int transactionSeq;
	
	/** The transaction name. */
	private String transactionName;
	
	/** The event name. */
	private String eventName;
	
	/** The event start time. */
	private Timestamp eventStartTime;
	
	/** The event end time. */
	private Timestamp eventEndTime;
	
	/** The stepone type. */
	private String steponeType;
	
	/** The stepone start time. */
	private Timestamp steponeStartTime;
	
	/** The stepone end time. */
	private Timestamp steponeEndTime;
	
	/** The steptwo type. */
	private String steptwoType;
	
	/** The steptwo start time. */
	private Timestamp steptwoStartTime;
	
	/** The steptwo end time. */
	private Timestamp steptwoEndTime;
	
	/** The status. */
	private String status;
	
	/** The status desc. */
	private String statusDesc;
	
	/** The result type. */
	private String resultType;
	
	/** The correlation key. */
	private String correlationKey;

	/**
	 * Gets the event id.
	 *
	 * @return the event id
	 */
	public long getEventId() {
		return eventId;
	}
	
	/**
	 * Sets the event id.
	 *
	 * @param eventId the new event id
	 */
	public void setEventId(long eventId) {
		this.eventId = eventId;
	}
	
	/**
	 * Gets the transaction id.
	 *
	 * @return the transaction id
	 */
	public String getTransactionId() {
		return transactionId;
	}
	
	/**
	 * Sets the transaction id.
	 *
	 * @param transactionId the new transaction id
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	
	/**
	 * @return the transactionSeq
	 */
	public int getTransactionSeq() {
		return transactionSeq;
	}

	/**
	 * @param transactionSeq the transactionSeq to set
	 */
	public void setTransactionSeq(int transactionSeq) {
		this.transactionSeq = transactionSeq;
	}

	/**
	 * Gets the transaction name.
	 *
	 * @return the transaction name
	 */
	public String getTransactionName() {
		return transactionName;
	}
	
	/**
	 * Sets the transaction name.
	 *
	 * @param transactionName the new transaction name
	 */
	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}
	
	/**
	 * Gets the event name.
	 *
	 * @return the event name
	 */
	public String getEventName() {
		return eventName;
	}
	
	/**
	 * Sets the event name.
	 *
	 * @param eventName the new event name
	 */
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	
	/**
	 * Gets the event start time.
	 *
	 * @return the event start time
	 */
	public Timestamp getEventStartTime() {
		// Fix Security Violation #2 Malicious code vulnerability - May expose internal representation 
		// by returning reference to mutable object 
		// - MK5569 3/26/2015
		// return eventStartTime;
		if (eventStartTime != null)
			return new Timestamp(eventStartTime.getTime());
		else
			return null;
	}
	
	/**
	 * Sets the event start time.
	 *
	 * @param eventStartTime the new event start time
	 */
	public void setEventStartTime(Timestamp eventStartTime) {
		// Fix Security Violation #1 Malicious code vulnerability - May expose internal representation 
		// by incorporating reference to mutable object
		// - MK5569 3/26/2015
		// this.eventStartTime = eventStartTime;
		if (eventStartTime != null)
			this.eventStartTime = new Timestamp(eventStartTime.getTime());
		else
			this.eventStartTime = null;
	}
	
	/**
	 * Gets the event end time.
	 *
	 * @return the event end time
	 */
	public Timestamp getEventEndTime() {
		// Fix Security Violation #2 Malicious code vulnerability - May expose internal representation 
		// by returning reference to mutable object 
		// - MK5569 3/26/2015
		// return eventEndTime;
		if (eventEndTime != null)
			return new Timestamp(eventEndTime.getTime());
		else
			return null;
	}
	
	/**
	 * Sets the event end time.
	 *
	 * @param eventEndTime the new event end time
	 */
	public void setEventEndTime(Timestamp eventEndTime) {
		// Fix Security Violation #1 Malicious code vulnerability - May expose internal representation 
		// by incorporating reference to mutable object
		// - MK5569 3/26/2015
		// this.eventEndTime = eventEndTime;
		if (eventEndTime != null)
			this.eventEndTime = new Timestamp(eventEndTime.getTime());
		else
			this.eventEndTime = null;
	}
	
	/**
	 * Gets the stepone type.
	 *
	 * @return the stepone type
	 */
	public String getSteponeType() {
		return steponeType;
	}
	
	/**
	 * Sets the stepone type.
	 *
	 * @param steponeType the new stepone type
	 */
	public void setSteponeType(String steponeType) {
		this.steponeType = steponeType;
	}
	
	/**
	 * Gets the stepone start time.
	 *
	 * @return the stepone start time
	 */
	public Timestamp getSteponeStartTime() {
		// Fix Security Violation #2 Malicious code vulnerability - May expose internal representation 
		// by returning reference to mutable object 
		// - MK5569 3/26/2015
		// return steponeStartTime;
		if (steponeStartTime != null)
			return new Timestamp(steponeStartTime.getTime());
		else
			return null;
	}
	
	/**
	 * Sets the stepone start time.
	 *
	 * @param steponeStartTime the new stepone start time
	 */
	public void setSteponeStartTime(Timestamp steponeStartTime) {
		// Fix Security Violation #1 Malicious code vulnerability - May expose internal representation 
		// by incorporating reference to mutable object
		// - MK5569 3/26/2015
		// this.steponeStartTime = steponeStartTime;
		if (steponeStartTime != null)
			this.steponeStartTime = new Timestamp(steponeStartTime.getTime());
		else
			this.steponeStartTime = null;
	}
	
	/**
	 * Gets the stepone end time.
	 *
	 * @return the stepone end time
	 */
	public Timestamp getSteponeEndTime() {
		// Fix Security Violation #2 Malicious code vulnerability - May expose internal representation 
		// by returning reference to mutable object 
		// - MK5569 3/26/2015
		// return steponeEndTime;
		if (steponeEndTime != null )
			return new Timestamp(steponeEndTime.getTime());
		else 
			return null;
	}
	
	/**
	 * Sets the stepone end time.
	 *
	 * @param steponeEndTime the new stepone end time
	 */
	public void setSteponeEndTime(Timestamp steponeEndTime) {
		// Fix Security Violation #1 Malicious code vulnerability - May expose internal representation 
		// by incorporating reference to mutable object
		// - MK5569 3/26/2015
		// this.steponeEndTime = steponeEndTime;
		if (steponeEndTime != null)
			this.steponeEndTime = new Timestamp(steponeEndTime.getTime());
		else
			this.steponeEndTime = null;
	}
	
	/**
	 * Gets the steptwo type.
	 *
	 * @return the steptwo type
	 */
	public String getSteptwoType() {
		return steptwoType;
	}
	
	/**
	 * Sets the steptwo type.
	 *
	 * @param steptwoType the new steptwo type
	 */
	public void setSteptwoType(String steptwoType) {
		this.steptwoType = steptwoType;
	}
	
	/**
	 * Gets the steptwo start time.
	 *
	 * @return the steptwo start time
	 */
	public Timestamp getSteptwoStartTime() {
		// Fix Security Violation #2 Malicious code vulnerability - May expose internal representation 
		// by returning reference to mutable object 
		// - MK5569 3/26/2015
		// return steptwoStartTime;
		if (steptwoStartTime != null)
			return new Timestamp(steptwoStartTime.getTime());
		else
			return null;
	}
	
	/**
	 * Sets the steptwo start time.
	 *
	 * @param steptwoStartTime the new steptwo start time
	 */
	public void setSteptwoStartTime(Timestamp steptwoStartTime) {
		// Fix Security Violation #1 Malicious code vulnerability - May expose internal representation 
		// by incorporating reference to mutable object
		// - MK5569 3/26/2015
		// this.steptwoStartTime = steptwoStartTime;
		if (steptwoStartTime != null)
			this.steptwoStartTime = new Timestamp(steptwoStartTime.getTime());
		else
			this.steptwoStartTime = null;
	}
	
	/**
	 * Gets the steptwo end time.
	 *
	 * @return the steptwo end time
	 */
	public Timestamp getSteptwoEndTime() {
		// Fix Security Violation #2 Malicious code vulnerability - May expose internal representation 
		// by returning reference to mutable object 
		// - MK5569 3/26/2015
		// return steptwoEndTime;
		if (steptwoEndTime != null)
			return new Timestamp(steptwoEndTime.getTime());
		else
			return null;
	}
	
	/**
	 * Sets the steptwo end time.
	 *
	 * @param steptwoEndTime the new steptwo end time
	 */
	public void setSteptwoEndTime(Timestamp steptwoEndTime) {
		// Fix Security Violation #1 Malicious code vulnerability - May expose internal representation 
		// by incorporating reference to mutable object
		// - MK5569 3/26/2015
		// this.steptwoEndTime = steptwoEndTime;
		if (steptwoEndTime != null)
			this.steptwoEndTime = new Timestamp(steptwoEndTime.getTime());
		else
			this.steptwoEndTime = null;
	}
	
	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	
	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * Gets the status desc.
	 *
	 * @return the status desc
	 */
	public String getStatusDesc() {
		return statusDesc;
	}
	
	/**
	 * Sets the status desc.
	 *
	 * @param statusDesc the new status desc
	 */
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	
	/**
	 * Gets the result type.
	 *
	 * @return the result type
	 */
	public String getResultType() {
		return resultType;
	}
	
	/**
	 * Sets the result type.
	 *
	 * @param resultType the new result type
	 */
	public void setResultType(String resultType) {
		this.resultType = resultType;
	}
	
	/**
	 * Gets the correlation key.
	 *
	 * @return the correlation key
	 */
	public String getCorrelationKey() {
		return correlationKey;
	}
	
	/**
	 * Sets the correlation key.
	 *
	 * @param correlationKey the new correlation key
	 */
	public void setCorrelationKey(String correlationKey) {
		this.correlationKey = correlationKey;
	}

	/*
	// for convenience
	public void setEventEndData(Timestamp eventEndTime, String status, String statusDesc, String resultType) {
		this.eventEndTime = eventEndTime;
		this.status = status;
		this.statusDesc = statusDesc;
		this.resultType = resultType;
	}
	*/

}