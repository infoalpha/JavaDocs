package com.att.icasmx.rti.core.events.response;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.att.icasmx.rti.constants.ICASConstants;
import com.att.icasmx.rti.core.data.AdditionalDocumentation;
import com.att.icasmx.rti.core.data.EUCC_RSP;
import com.att.icasmx.rti.core.events.request.ExecuteUnifiedCreditCheckRequestEventHandler;
import com.att.icasmx.rti.util.MockUtils;
import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowEventHandler;
import com.att.icasmx.rti.workflow.WorkflowException;
import com.att.icasmx.rti.ws.AccountDetailInfo;
import com.att.icasmx.rti.ws.CreditClassInfo;
import com.att.icasmx.rti.ws.DocumentationRequiredInfo;
import com.att.icasmx.rti.ws.DocumentationStatusCodeInfo;
import com.att.icasmx.rti.ws.DocumentationTypeInfo;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXCreditCheckRequest;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXCreditCheckResponse;
import com.att.icasmx.rti.ws.StatusInfo;
import com.att.icasmx.rti.ws.WorklistAlertInfo;

/**
 * 
 * @author mp157q
 * 
 *         EUCC Response event handler to map EUCC data model to EUCC schema
 *         response.
 */

public class ExecuteUnifiedCreditCheckResponseEventHandler implements
		WorkflowEventHandler {

	public static final String EUCC_RESULT = "EUCC_RESULT";
	private static final Logger logger = LogManager
			.getLogger(ExecuteUnifiedCreditCheckRequestEventHandler.class
					.getName());

	@Override
	public String execute(EventManager eventManager) {

		// Gettting EUCC data response
		EUCC_RSP eucc_resp = (EUCC_RSP) eventManager
				.getWorkflowData(WorkflowConstants.WORKFLOW_EUCC_RESP);
		ExecuteUnifiedMXCreditCheckResponse euccschemaRes = new ExecuteUnifiedMXCreditCheckResponse();

		// Getting Generated transaction ID
		String transactionID = MockUtils
				.getMockUnifiedTransactionId(WorkflowConstants.CREDIT_TYPE);
		euccschemaRes.setUnifiedCreditTransactionId(transactionID);
		// Getting Original Schema Request
		ExecuteUnifiedMXCreditCheckRequest euccRqs = (ExecuteUnifiedMXCreditCheckRequest) eventManager
				.getWorkflowData(WorkflowConstants.EXECUTE_UNIFIED_CREDIT_CHECK_REQUEST);
		if (null != euccRqs.getWSHeader()) {
			logger.info("PRINT CONVERSATION :"
					+ euccRqs.getWSHeader().getWSConversationId());
			euccschemaRes = (ExecuteUnifiedMXCreditCheckResponse) MockUtils
					.populateHeaders(euccRqs, euccschemaRes);
		}

		if (eucc_resp.getErrorCode() != null
				&& (ICASConstants.ERROR_CODE.equals(eucc_resp.getErrorCode()) || ICASConstants.INPUT_ERROR_CODE
						.equalsIgnoreCase(eucc_resp.getErrorCode()))) {
			euccschemaRes.getError().add(MockUtils.generateError(eucc_resp));
			euccschemaRes
					.setStatus(StatusInfo.fromValue(eucc_resp.getStatus()));
			euccschemaRes.setStatusReason(eucc_resp.getStatusReason());
			return eventManager.eventEnd(
					WorkflowConstants.WORKFLOW_RESULT_SUCCESS, EUCC_RESULT,
					euccschemaRes);
		}

		try {
			Boolean debtIndicator = new Boolean(
					eucc_resp.getOutstandingDebtIndicator());					
			if (null != eucc_resp.getOutstandingDebtIndicator()
					&& !eucc_resp.getOutstandingDebtIndicator().equals(
							ICASConstants.EMPTY_STRING))
				euccschemaRes.setOutstandingDebtIndicator(debtIndicator);

			if (null != eucc_resp.getOutstandingDebtMinAmountDue()
					&& !eucc_resp.getOutstandingDebtMinAmountDue().equals(
							ICASConstants.EMPTY_STRING)) {
				AccountDetailInfo accdtl = MockUtils.populateDebt(eucc_resp);
				euccschemaRes.getOutstandingDebt().add(accdtl);
			}

			if (null != eucc_resp.getWorkListIndicator()
					&& !eucc_resp.getWorkListIndicator().equals(
							ICASConstants.EMPTY_STRING))
				euccschemaRes.setWorklistIndicator(new Boolean(eucc_resp.getWorkListIndicator()));
			if (null != eucc_resp.getStatus()
					&& !eucc_resp.getStatus()
							.equals(ICASConstants.EMPTY_STRING))
				euccschemaRes.setStatus(StatusInfo.fromValue(eucc_resp
						.getStatus()));
			if (null != eucc_resp.getStatusReason()
					&& !eucc_resp.getStatusReason().equals(
							ICASConstants.EMPTY_STRING))
				euccschemaRes.setStatusReason(eucc_resp.getStatusReason());
			if (null != eucc_resp.getCreditClass())
				euccschemaRes.setCreditClass(CreditClassInfo
						.fromValue(eucc_resp.getCreditClass()));

			if (eucc_resp != null
					&& eucc_resp.getWorkListAlertSeverity() != null) {
				WorklistAlertInfo workAlertInfo = MockUtils.getWorklistAlertInfo(eucc_resp);
				euccschemaRes.getWorklistAlert().add(workAlertInfo);
			}

			if ("TRUE".equals(eucc_resp.getAdditionalDocumentationReqIndicator()))
				euccschemaRes
						.setAdditionalDocumentationRequiredIndicator(new Boolean(eucc_resp.getAdditionalDocumentationReqIndicator()));

			if (null != eucc_resp.getAdditionalDoc()) {
				populateDocument(eucc_resp,euccschemaRes);
			}

			return eventManager.eventEnd(
					WorkflowConstants.WORKFLOW_RESULT_SUCCESS, EUCC_RESULT,
					euccschemaRes);
		} catch (WorkflowException wfe) {
			logger.error(wfe);
			eucc_resp.setErrorCode(ICASConstants.INPUT_ERROR_CODE);
			ExecuteUnifiedMXCreditCheckResponse errResponse = new ExecuteUnifiedMXCreditCheckResponse();
			errResponse.getError().add(MockUtils.generateError(eucc_resp));
			return eventManager.eventEnd(
					WorkflowConstants.WORKFLOW_RESULT_FAILURE, EUCC_RESULT,
					errResponse);

		}

	}

	 /**
	  * 
	  * @param euccRsp
	  * @param euccschemaRes
	  */
	private void populateDocument(EUCC_RSP euccRsp, ExecuteUnifiedMXCreditCheckResponse euccschemaRes) {

		List<DocumentationRequiredInfo> additionalDoc = euccschemaRes
				.getAdditionalDocumentationRequired();
		for (AdditionalDocumentation obj : euccRsp.getAdditionalDoc()) {
			DocumentationRequiredInfo temp = new DocumentationRequiredInfo();
			temp.setDocumentationType(DocumentationTypeInfo.fromValue(obj
					.getDocumentationType()));
			temp.setReasonCode(DocumentationStatusCodeInfo.fromValue(obj
					.getReasonCode()));
			temp.setReasonText(obj.getReasonText_en());
			additionalDoc.add(temp);
		}
	}

}