package com.att.icasmx.rti.ws;

import javax.annotation.PostConstruct;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.apache.cxf.interceptor.InInterceptors;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jboss.ws.api.annotation.EndpointConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowException;
import com.att.icasmx.rti.workflow.WorkflowManager;
import com.att.icasmx.rti.workflow.WorkflowResult;

/**
 * 
 * @author mp157q
 * 
 */

@WebService(portName = "ICASMXCreditPolicyServicesSoapHttpPort", serviceName = "ICASMXCreditPolicyServices", wsdlLocation = "WEB-INF/wsdl/ICASMXCreditPolicyServices.wsdl", targetNamespace = "http://icas.att.com/ICASMXCreditPolicyServices.wsdl", endpointInterface = "com.att.icasmx.rti.ws.ICASMXCreditPolicyServicesPortType")
@SOAPBinding(parameterStyle = SOAPBinding.ParameterStyle.BARE)
@EndpointConfig(configFile = "WEB-INF/jaxws-endpoint-config.xml", configName = "Custom WS-Security Endpoint")
@InInterceptors(interceptors = { "org.jboss.wsf.stack.cxf.security.authentication.SubjectCreatingPolicyInterceptor" })
public class ICASMXCreditPolicyServicesPortTypeImpl implements
		ICASMXCreditPolicyServicesPortType {

	/** The logger. */
	private static Logger logger = LogManager
			.getLogger(ICASMXCreditPolicyServicesPortTypeImpl.class
					.getName());

	// Injecting Work flow Manager
	@Autowired
	WorkflowManager manager;

	@Override
	public UpdateUnifiedMXPolicyApplicationResponse updateUnifiedMXPolicyApplication(
			UpdateUnifiedMXPolicyApplicationRequest updateUnifiedMXPolicyApplicationRequest)
			throws WSException_Exception {
		   logger.debug("Entering "
					+ ICASMXCreditPolicyServicesPortTypeImpl.class.getName()+" updateUnifiedMXPolicyApplication()");
			WorkflowResult workflowResult = null;
			try {
				workflowResult = manager.execute(
						WorkflowConstants.UPDATE_UNIFIED_POLICY_WORKFLOW_ID,
						WorkflowConstants.UPDATE_UNIFIED_POLICY_REQUEST,
						updateUnifiedMXPolicyApplicationRequest);
				UpdateUnifiedMXPolicyApplicationResponse unifiedMXPolicyApplicationResponse = (UpdateUnifiedMXPolicyApplicationResponse) workflowResult
						.getResult();
				logger.debug("Exiting "
						+ ICASMXCreditPolicyServicesPortTypeImpl.class
								.getName()+" updateUnifiedMXPolicyApplication()");
				return unifiedMXPolicyApplicationResponse;
			} catch (WorkflowException wfe) {
				WSException_Exception WSexception = new WSException_Exception(
						wfe.getMessage(), wfe);
				logger.error("ICASException- " + WSexception.toString());
				throw WSexception;
			} finally {

			}
	}

	@Override
	public ExecuteUnifiedMXCreditCheckResponse executeUnifiedMXCreditCheck(
			ExecuteUnifiedMXCreditCheckRequest executeUnifiedMXCreditCheckRequest)
			throws WSException_Exception {
		WorkflowResult flowResult = null;
		ExecuteUnifiedMXCreditCheckResponse response = null;
		try {
			logger.info("executeUnifiedMXCreditCheck:");
			flowResult = manager.execute(
					WorkflowConstants.EXECUTE_UNIFIED_CREDIT_CHECK_WORKFLOW_ID,
					WorkflowConstants.EXECUTE_UNIFIED_CREDIT_CHECK_REQUEST,
					executeUnifiedMXCreditCheckRequest);
			ExecuteUnifiedMXCreditCheckResponse executeUnifiedMXCreditCheckResponse = (ExecuteUnifiedMXCreditCheckResponse) flowResult
					.getResult();
			logger.debug("Exiting "
					+ ExecuteUnifiedMXCreditCheckResponse.class.getName());
			return executeUnifiedMXCreditCheckResponse;
		} catch (WorkflowException wfe) {
			wfe.printStackTrace();
			WSException_Exception WSexception = new WSException_Exception(
					wfe.getMessage(), wfe);
			logger.error("ICASException- " + WSexception.toString());
			throw WSexception;
		} finally {

		}

	}

	@Override
	public InquireUnifiedMXPolicyCheckResultResponse inquireUnifiedMXPolicyCheckResult(
			InquireUnifiedMXPolicyCheckResultRequest inquireUnifiedMXPolicyCheckResultRequest)
			throws WSException_Exception {
		logger.info("IUPC - Entering");
		WorkflowResult workflowResult = null;
		try {
			workflowResult = manager.execute(
					WorkflowConstants.INQUIRE_UNIFIED_POLICY_CHECK_WORKFLOW_ID,
					WorkflowConstants.INQUIRE_UNIFIED_POLICY_CHECK_REQUEST,
					inquireUnifiedMXPolicyCheckResultRequest);
			InquireUnifiedMXPolicyCheckResultResponse response = (InquireUnifiedMXPolicyCheckResultResponse) workflowResult
					.getResult();
			logger.info("IUPC - Exiting");
			return response;
		} catch (WorkflowException wfe) {
			WSException_Exception WSexception = new WSException_Exception(
					wfe.getMessage(), wfe);
			logger.error("IUPC - ICASException- " + WSexception.toString());
			throw WSexception;
		}
	}

	@Override
	public InquireUnifiedMXCreditCheckResultResponse inquireUnifiedMXCreditCheckResult(
			InquireUnifiedMXCreditCheckResultRequest inquireUnifiedMXCreditCheckResultRequest)
			throws WSException_Exception {
		WorkflowResult workflowResult = null;
		logger.info("IUCC - Entering");
		try {
			workflowResult = manager.execute(
					WorkflowConstants.INQUIRE_UNIFIED_CREDIT_CHECK_WORKFLOW_ID,
					WorkflowConstants.INQUIRE_UNIFIED_CREDIT_CHECK_REQUEST,
					inquireUnifiedMXCreditCheckResultRequest);
			InquireUnifiedMXCreditCheckResultResponse response = (InquireUnifiedMXCreditCheckResultResponse) workflowResult
					.getResult();
			logger.info("IUCC - Exiting");
			return response;
		} catch (WorkflowException wfe) {
			wfe.printStackTrace();
			WSException_Exception WSexception = new WSException_Exception(
					wfe.getMessage(), wfe);
			logger.error("ICASException- " + WSexception.toString());
			throw WSexception;
		}

	}

	@Override
	public ConfirmUnifiedMXCreditDebtPaymentResponse confirmUnifiedMXCreditDebtPayment(
			ConfirmUnifiedMXCreditDebtPaymentRequest confirmUnifiedMXCreditDebtPaymentRequest)
			throws WSException_Exception {
		WorkflowResult flowResult = null;
		ConfirmUnifiedMXCreditDebtPaymentResponse response = null;
		try {
			logger.info("confirmUnifiedMXCreditDebtPayment:");
			flowResult = manager
					.execute(
							WorkflowConstants.CONFIRM_UNIFIED_CREDITDEBT_PAYMENT_WORKFLOW_ID,
							WorkflowConstants.CONFIRM_UNIFIED_CREDIT_DEBT_REQUEST,
							confirmUnifiedMXCreditDebtPaymentRequest);
			ConfirmUnifiedMXCreditDebtPaymentResponse cucdpSchemaResp = (ConfirmUnifiedMXCreditDebtPaymentResponse) flowResult
					.getResult();
			logger.debug("Exiting "
					+ ConfirmUnifiedMXCreditDebtPaymentResponse.class.getName());
			return cucdpSchemaResp;
		} catch (WorkflowException wfe) {
			wfe.printStackTrace();
			WSException_Exception WSexception = new WSException_Exception(
					wfe.getMessage(), wfe);
			logger.error("ICASException- " + WSexception.toString());
			throw WSexception;
		} finally {

		}
	}

	@Override
	public SubmitUnifiedMXPolicyUpdateResponse submitUnifiedMXPolicyUpdate(
			SubmitUnifiedMXPolicyUpdateRequest submitUnifiedMXPolicyUpdateRequest)
			throws WSException_Exception {		
		    logger.debug("Entering "
					+ ICASMXCreditPolicyServicesPortTypeImpl.class.getName()+" submitUnifiedMXPolicyUpdate");
			WorkflowResult workflowResult = null;
			try {
				workflowResult = manager.execute(
						WorkflowConstants.SUBMIT_UNIFIED_POLICY_UPDATE_WORKFLOW_ID,
						WorkflowConstants.SUBMIT_UNIFIED_POLICY_UPDATE_REQUEST,
						submitUnifiedMXPolicyUpdateRequest);
				SubmitUnifiedMXPolicyUpdateResponse submitUnifiedMXPolicyUpdateResponse = (SubmitUnifiedMXPolicyUpdateResponse) workflowResult
						.getResult();
				logger.debug("Exiting "
						+ ICASMXCreditPolicyServicesPortTypeImpl.class
								.getName()+" submitUnifiedMXPolicyUpdate()");
				return submitUnifiedMXPolicyUpdateResponse;
			} catch (WorkflowException wfe) {
				WSException_Exception WSexception = new WSException_Exception(
						wfe.getMessage(), wfe);
				logger.error("ICASException- " + WSexception.toString());
				throw WSexception;
			} finally {

			}
	}

	@Override
	public ExecuteUnifiedMXPolicyCheckResponse executeUnifiedMXPolicyCheck(
			ExecuteUnifiedMXPolicyCheckRequest executeUnifiedMXPolicyCheckRequest)
			throws WSException_Exception {
		WorkflowResult workflowResult = null;
		ExecuteUnifiedMXPolicyCheckResponse executeUnifiedMXPolicyCheckResponse = null;
		logger.debug("Entering "
				+ ICASMXCreditPolicyServicesPortTypeImpl.class.getName() +" executeUnifiedMXPolicyCheck()" );
		try {
			workflowResult = manager.execute(
					WorkflowConstants.EXECUTE_UNIFIED_POLICY_CHECK_WORKFLOW_ID,
					WorkflowConstants.EXECUTE_UNIFIED_POLICY_CHECK_REQUEST,
					executeUnifiedMXPolicyCheckRequest);
			executeUnifiedMXPolicyCheckResponse = new ExecuteUnifiedMXPolicyCheckResponse();
			executeUnifiedMXPolicyCheckResponse = (ExecuteUnifiedMXPolicyCheckResponse) workflowResult
					.getResult();
			logger.debug("Exiting "
					+ ICASMXCreditPolicyServicesPortTypeImpl.class.getName()+" executeUnifiedMXPolicyCheck()" );
			return executeUnifiedMXPolicyCheckResponse;

		} catch (WorkflowException wfe) {
			wfe.printStackTrace();
			WSException_Exception WSexception = new WSException_Exception(
					wfe.getMessage(), wfe);
			logger.error("ICASException- " + WSexception.toString());
			throw WSexception;
		} finally {

		}
	}

	@Override
	public SubmitUnifiedMXCreditUpdateResponse submitUnifiedMXCreditUpdate(
			SubmitUnifiedMXCreditUpdateRequest submitUnifiedMXCreditUpdateRequest)
			throws WSException_Exception {
		WorkflowResult flowResult = null;
		SubmitUnifiedMXCreditUpdateResponse sucuSchemaResp = null;
		try {
			logger.info("submitUnifiedMXCreditUpdate:");
			flowResult = manager.execute(
					WorkflowConstants.SUBMIT_UNIFIED_CREDIT_UPDATE_WORKFLOW_ID,
					WorkflowConstants.SUBMIT_UNIFIED_CREDIT_UPDATE_REQUEST,
					submitUnifiedMXCreditUpdateRequest);
			sucuSchemaResp = (SubmitUnifiedMXCreditUpdateResponse) flowResult
					.getResult();
			logger.debug("Exiting "
					+ SubmitUnifiedMXCreditUpdateResponse.class.getName());
			return sucuSchemaResp;
		} catch (WorkflowException flowException) {
			flowException.printStackTrace();
			logger.error(flowException);
			return sucuSchemaResp;
		}
	}

	@PostConstruct
	public void postConstruct() {		
		logger.info("postconstruct has run for Port Type Impl.Injecting workflow bean");
		SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
	}

}
