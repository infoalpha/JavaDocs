package com.att.icasmx.rti.core.events.request;



import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.icasmx.rti.constants.ICASMXWorkflowConstants;
import com.att.icasmx.rti.exception.ICASException;
import com.att.icasmx.rti.services.CommonService;
import com.att.icasmx.rti.util.MDCUtil;
import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowEventHandler;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXPolicyCheckRequest;
import com.att.icasmx.rti.ws.WSHeader;


/**
 * The Class ExecuteUnifiedCreditCheckRequestHandler.
 */

public class ExecuteUnifiedPolicyCheckRequestEventHandler implements
		WorkflowEventHandler {

	
	private static final Logger LOGGER = LogManager
			.getLogger(ExecuteUnifiedPolicyCheckRequestEventHandler.class
					.getName());
	
	private static final String XMOCK ="XMOCK-";
		
	@Autowired
	CommonService commonService;
	
	

	
	public String execute(EventManager eventManager) {
		try {

			LOGGER.debug("Entering ExecuteUnifiedMXPolicyCheckRequestEventHandler");
			MDCUtil.setTransactionName("ExecuteUnifiedPolicyCheck");
			commonService.atTransactionAndEventBegin();

			ExecuteUnifiedMXPolicyCheckRequest executeUnifiedMXPolicyCheckRequest = (ExecuteUnifiedMXPolicyCheckRequest) eventManager
					.getWorkflowData(WorkflowConstants.EXECUTE_UNIFIED_POLICY_CHECK_REQUEST);
			// Check to invoke MockUpservice
			if (null != executeUnifiedMXPolicyCheckRequest.getDealerName() ? executeUnifiedMXPolicyCheckRequest
					.getDealerName().trim().startsWith(XMOCK) : false) {
				LOGGER.debug("Found Mock In Request redircting to ExecuteUnifiedPolicyCheckMockEventHandler");
				return WorkflowConstants.WORKFLOW_EUPC_MOCK_GEN;
			}else{
				
			}

			LOGGER.debug("Exiting ExecuteUnifiedMXPolicyCheckRequestEventHandler");
			// returns nextstep
			return WorkflowConstants.WORKFLOW_RESULT_SUCCESS;
		} catch (ICASException e) {
			MDCUtil.clear();
			LOGGER.error(e.getMessage());
			// set appropriate next event
			return WorkflowConstants.WORKFLOW_RESULT_FAILURE;
		}
	}

}
