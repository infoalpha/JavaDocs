package com.att.icasmx.rti.core.events.response;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.att.icasmx.rti.constants.ICASConstants;
import com.att.icasmx.rti.core.data.AdditionalDocumentation;
import com.att.icasmx.rti.core.data.EUCC_RSP;
import com.att.icasmx.rti.util.MockUtils;
import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowEventHandler;
import com.att.icasmx.rti.workflow.WorkflowException;
import com.att.icasmx.rti.ws.CreditClassInfo;
import com.att.icasmx.rti.ws.DocumentationRequiredInfo;
import com.att.icasmx.rti.ws.DocumentationStatusCodeInfo;
import com.att.icasmx.rti.ws.DocumentationTypeInfo;
import com.att.icasmx.rti.ws.StatusInfo;
import com.att.icasmx.rti.ws.SubmitUnifiedMXCreditUpdateRequest;
import com.att.icasmx.rti.ws.SubmitUnifiedMXCreditUpdateResponse;
import com.att.icasmx.rti.ws.WorklistAlertInfo;

public class SubmitUnifiedCreditUpdateResponseEventHandler implements
		WorkflowEventHandler {
	private static final Logger logger = LogManager
			.getLogger(SubmitUnifiedCreditUpdateResponseEventHandler.class
					.getName());
	private static final String SUCU_RESULT = "SUCU_RESULT";

	@Override
	public String execute(EventManager eventManager) {

		logger.info("SubmitUnifiedCreditUpdateResponseEventHandler:execute method");

		EUCC_RSP euccRsp = (EUCC_RSP) eventManager
				.getWorkflowData(WorkflowConstants.WORKFLOW_SUCU_RESP);
		SubmitUnifiedMXCreditUpdateResponse sucuschemaRes = new SubmitUnifiedMXCreditUpdateResponse();

		SubmitUnifiedMXCreditUpdateRequest sucuRqs = (SubmitUnifiedMXCreditUpdateRequest) eventManager
				.getWorkflowData(WorkflowConstants.SUBMIT_UNIFIED_CREDIT_UPDATE_REQUEST);
		if (null != sucuRqs.getWSHeader()) {
			logger.info("PRINT CONVERSATION :"
					+ sucuRqs.getWSHeader().getWSConversationId());
			sucuschemaRes = (SubmitUnifiedMXCreditUpdateResponse) MockUtils
					.populateHeaders(sucuRqs, sucuschemaRes);
			
		}
		
		setUnifiedTransactionID(sucuRqs,sucuschemaRes);

		try {

			if (euccRsp != null
					&& euccRsp.getErrorCode() != null
					&& (euccRsp.getErrorCode().equalsIgnoreCase(
							ICASConstants.ERROR_CODE) || euccRsp.getErrorCode()
							.equalsIgnoreCase(ICASConstants.INPUT_ERROR_CODE))) {
				logger.error("inside error: schema response"
						+ euccRsp.getErrorCode());
				sucuschemaRes.getError().add(MockUtils.generateError(euccRsp));
				sucuschemaRes.setStatus(StatusInfo.fromValue(euccRsp
						.getStatus()));
				sucuschemaRes.setStatusReason(euccRsp.getStatusReason());
				return eventManager.eventEnd(
						WorkflowConstants.WORKFLOW_RESULT_SUCCESS, SUCU_RESULT,
						sucuschemaRes);

			}

			Boolean debtIndicator = new Boolean(
					euccRsp.getOutstandingDebtIndicator());
			Boolean workListIndicator = new Boolean(
					euccRsp.getWorkListIndicator());
			Boolean addnDocIndicator = new Boolean(
					euccRsp.getAdditionalDocumentationReqIndicator());

			if (null != euccRsp.getWorkListIndicator()
					&& !euccRsp.getWorkListIndicator().equals(""))
				sucuschemaRes.setWorklistIndicator(workListIndicator);
			if (null != euccRsp.getStatus() && !euccRsp.getStatus().equals(""))
				sucuschemaRes.setStatus(StatusInfo.fromValue(euccRsp
						.getStatus()));
			if (null != euccRsp.getStatusReason()
					&& !euccRsp.getStatusReason().equals(""))
				sucuschemaRes.setStatusReason(euccRsp.getStatusReason());
			if (null != euccRsp.getCreditClass())
				sucuschemaRes.setCreditClass(CreditClassInfo.fromValue(euccRsp
						.getCreditClass()));

			if (euccRsp != null && euccRsp.getWorkListAlertSeverity() != null) {
				WorklistAlertInfo workAlertInfo = MockUtils
						.getWorklistAlertInfo(euccRsp);
				sucuschemaRes.getWorklistAlert().add(workAlertInfo);
			}

			
			// TODO:
			// .setAdditionalDocumentationRequiredIndicator(addnDocIndicator);
			if (addnDocIndicator == true)
				sucuschemaRes
						.setAdditionalDocumentationRequiredIndicator(addnDocIndicator);

			if (null != euccRsp.getAdditionalDoc()) {
				populateDocument(euccRsp, sucuschemaRes);
			}			

			return eventManager.eventEnd(
					WorkflowConstants.WORKFLOW_RESULT_SUCCESS, SUCU_RESULT,
					sucuschemaRes);
		} catch (WorkflowException wfe) {
			logger.error(wfe);
			euccRsp.setErrorCode(ICASConstants.INPUT_ERROR_CODE);
			SubmitUnifiedMXCreditUpdateResponse errResponse = new SubmitUnifiedMXCreditUpdateResponse();
			errResponse.getError().add(MockUtils.generateError(euccRsp));
			return eventManager.eventEnd(
					WorkflowConstants.WORKFLOW_RESULT_SUCCESS, SUCU_RESULT,
					sucuschemaRes);
		}
	}

	/**
	 * 
	 * @param euccRsp
	 * @param sucuschemaRes
	 */
	private void populateDocument(EUCC_RSP euccRsp,
			SubmitUnifiedMXCreditUpdateResponse sucuschemaRes) {

		List<DocumentationRequiredInfo> additionalDoc = sucuschemaRes
				.getAdditionalDocumentationRequired();
		for (AdditionalDocumentation obj : euccRsp.getAdditionalDoc()) {
			DocumentationRequiredInfo temp = new DocumentationRequiredInfo();
			temp.setDocumentationType(DocumentationTypeInfo.fromValue(obj
					.getDocumentationType()));
			temp.setReasonCode(DocumentationStatusCodeInfo.fromValue(obj
					.getReasonCode()));
			temp.setReasonText(obj.getReasonText_en());
			additionalDoc.add(temp);
		}
	}
	
	private void setUnifiedTransactionID(SubmitUnifiedMXCreditUpdateRequest sucuRqs,SubmitUnifiedMXCreditUpdateResponse sucuschemaRes) {
	if (null != sucuRqs && null != sucuRqs.getUnifiedCreditTransactionId())
		sucuschemaRes.setUnifiedCreditTransactionId(sucuRqs
				.getUnifiedCreditTransactionId());
	}
}
