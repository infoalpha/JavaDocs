package com.att.icasmx.rti.core.events.response;

import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.att.icasmx.rti.constants.ICASConstants;
import com.att.icasmx.rti.constants.ICASMXWorkflowConstants;
import com.att.icasmx.rti.core.data.EUPC_RESPONSE;
import com.att.icasmx.rti.core.data.ICASMX_UC_EVENTS;
import com.att.icasmx.rti.exception.ICASException;
import com.att.icasmx.rti.util.MockUtils;
import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowEventHandler;
import com.att.icasmx.rti.ws.ErrorInfo;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXPolicyCheckRequest;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXPolicyCheckResponse;
import com.att.icasmx.rti.ws.MessageInfo;
import com.att.icasmx.rti.ws.StatusInfo;
import com.att.icasmx.rti.ws.SubmitUnifiedMXPolicyUpdateResponse;
import com.att.icasmx.rti.ws.UpdateUnifiedMXPolicyApplicationRequest;
import com.att.icasmx.rti.ws.UpdateUnifiedMXPolicyApplicationResponse;
import com.att.icasmx.rti.ws.WSResponseHeader;

/**
 * The Class UpdateUnifiedPolicyResponseHandler.
 */
public class UpdateUnifiedPolicyApplicationResponseHandler implements
		WorkflowEventHandler {

	/** The logger. */
	private static Logger LOGGER = LogManager
			.getLogger(UpdateUnifiedPolicyApplicationResponseHandler.class
					.getName());

	private static final String HYPHEN = "-";

	private static final String DEPOSIT_DELIMITER = ":";

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.att.icas.workflow.WorkflowAbstractEventHandler#execute(com.att.icas
	 * .workflow.EventManager)
	 */
	public String execute(EventManager eventManager) {

		LOGGER.info("Entering UpdateUnifiedPolicyResponseHandler");
		/*
		 * Define variables for this event
		 */
		UpdateUnifiedMXPolicyApplicationRequest updateUnifiedMXPolicyApplicationRequest = new UpdateUnifiedMXPolicyApplicationRequest();
		UpdateUnifiedMXPolicyApplicationResponse updateUnifiedMXPolicyResponse = new UpdateUnifiedMXPolicyApplicationResponse();
		EUPC_RESPONSE uupResponse = null;
		HashMap<String, Object> results = new HashMap<String, Object>();
		/*
		 * Variables for Workflow Result
		 */
		String eventStatus = null;
		String eventResultType = null;
		String workflowResultType = null;
		String workflowResultObjectKey = null;
		Object workflowResultObject = null;

		/*
		 * Display values of workflow data
		 */
		try {
			// Build credit response document
			LOGGER.debug("building MOCK UpdateUnifiedMXPolicyResponseHandler begin...");
			results = (HashMap<String, Object>) eventManager
					.getWorkflowDataMap();
			uupResponse = (EUPC_RESPONSE) results
					.get(WorkflowConstants.EUPC_MOCK_RESPONSE_DATA);
			updateUnifiedMXPolicyApplicationRequest = (UpdateUnifiedMXPolicyApplicationRequest) results
					.get(WorkflowConstants.UPDATE_UNIFIED_POLICY_REQUEST);
			// Parse Mock Response
			try{
			updateUnifiedMXPolicyResponse=parseMockResponseData(updateUnifiedMXPolicyResponse,
					updateUnifiedMXPolicyApplicationRequest, uupResponse);
			}catch(RuntimeException runtimeException){
				LOGGER.error(runtimeException.getStackTrace());
				updateUnifiedMXPolicyResponse=populateErrorResponse(updateUnifiedMXPolicyResponse, 
						updateUnifiedMXPolicyApplicationRequest);
			}
			eventStatus = ICASMX_UC_EVENTS.EVENT_STATUS_COMPLETE;
			workflowResultType = WorkflowConstants.WORKFLOW_RESULT_SUCCESS;
			workflowResultObjectKey = ICASMXWorkflowConstants.WORKFLOW_RESULT_NAME_POLICY_RESULT_MOCKUP;
			workflowResultObject = updateUnifiedMXPolicyResponse;
		} finally {
			/*
			 * Event/transaction update at Event end.
			 */
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("workflowResultType/workflowResultObjectKey = "
					+ workflowResultType + "/" + workflowResultObjectKey);
		}
		LOGGER.info("Exiting UpdateUnifiedMXPolicyResponseHandler");
		return eventManager.eventEnd(workflowResultType,
				workflowResultObjectKey, workflowResultObject);
	}

	public UpdateUnifiedMXPolicyApplicationResponse  parseMockResponseData(
			UpdateUnifiedMXPolicyApplicationResponse updateUnifiedMXPolicyResponse,
			UpdateUnifiedMXPolicyApplicationRequest unifiedMXPolicyApplicationRequest,
			EUPC_RESPONSE uupMockupResponseData) {

		if (uupMockupResponseData != null) {
			// Setting UpdateUnifiedTransactionID
			updateUnifiedMXPolicyResponse=new UpdateUnifiedMXPolicyApplicationResponse();
			if(unifiedMXPolicyApplicationRequest.getWSHeader()!=null){
				MockUtils.populateHeaders(unifiedMXPolicyApplicationRequest, updateUnifiedMXPolicyResponse);
			}
			
			updateUnifiedMXPolicyResponse
					.setUnifiedPolicyTransactionId(uupMockupResponseData
							.getUnifiedPolicyTransactionID());

			// Setting Message
			if (uupMockupResponseData.getMessageCode() != null) {
				MessageInfo messageInfo = new MessageInfo();
				messageInfo.setMessageCode(uupMockupResponseData
						.getMessageCode());
				messageInfo.setMessageText(uupMockupResponseData
						.getMessageText());
				updateUnifiedMXPolicyResponse.setMessage(messageInfo);
			}

			// Setting Error
			if (uupMockupResponseData.getErrorCode() != null) {
				ErrorInfo errorInfo = new ErrorInfo();
				errorInfo.setErrorCode(uupMockupResponseData.getErrorCode());
				errorInfo.setErrorMessage(uupMockupResponseData
						.getErrorMessage());
				errorInfo
						.setErrorSource(uupMockupResponseData.getErrorsource());
				updateUnifiedMXPolicyResponse.getError().add(errorInfo);
			}
		} else {
			updateUnifiedMXPolicyResponse=populateErrorResponse(updateUnifiedMXPolicyResponse,
					unifiedMXPolicyApplicationRequest);
		}
		return updateUnifiedMXPolicyResponse;
	}

	public UpdateUnifiedMXPolicyApplicationResponse  populateErrorResponse(
			UpdateUnifiedMXPolicyApplicationResponse unifiedMXPolicyApplicationResponse,
			UpdateUnifiedMXPolicyApplicationRequest unifiedMXPolicyApplicationRequest) {
		unifiedMXPolicyApplicationResponse=new UpdateUnifiedMXPolicyApplicationResponse();
		if(unifiedMXPolicyApplicationRequest.getWSHeader()!=null)
		unifiedMXPolicyApplicationResponse=(UpdateUnifiedMXPolicyApplicationResponse)MockUtils.
				populateHeaders(unifiedMXPolicyApplicationRequest, unifiedMXPolicyApplicationResponse);
		unifiedMXPolicyApplicationResponse
				.setUnifiedPolicyTransactionId(unifiedMXPolicyApplicationRequest.getUnifiedPolicyTransactionId()
						);		
		ErrorInfo errorInfo = new ErrorInfo();
		errorInfo.setErrorCode(ICASConstants.INPUT_ERROR_CODE);
		errorInfo.setErrorMessage(ICASConstants.INPUT_ERROR_MSG);
		errorInfo.setErrorSource(ICASConstants.ICAS_SYSTEM_ID);
		unifiedMXPolicyApplicationResponse.getError().add(errorInfo);		
		return unifiedMXPolicyApplicationResponse;
	}

}
