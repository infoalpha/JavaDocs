package com.att.icasmx.rti.workflow;

// TODO: Auto-generated Javadoc
/**
 * The Class WorkflowAbstractEventHandler.
 */
public interface  WorkflowEventHandler {
	
	/**
	 * Execute.
	 *
	 * @param eventManager the event manager
	 * @return the string
	 */
	public  String execute(EventManager eventManager);
	
}
