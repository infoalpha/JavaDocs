package com.att.icasmx.rti.core.events.mock;

import org.springframework.beans.factory.annotation.Autowired;

import com.att.icasmx.rti.core.data.EUCC_RSP;
import com.att.icasmx.rti.services.mock.EUCCMockGenerator;
import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowEventHandler;
import com.att.icasmx.rti.ws.ConfirmUnifiedMXCreditDebtPaymentRequest;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXCreditCheckRequest;
import com.att.icasmx.rti.ws.SubmitUnifiedMXCreditUpdateRequest;

public class SubmitUnifiedCreditUpdateMockEventHandler implements
WorkflowEventHandler {

	@Autowired 
	EUCCMockGenerator euccMock;
	
	@Override
	public String execute(EventManager eventManager) {
		EUCC_RSP sucuRes;
		SubmitUnifiedMXCreditUpdateRequest sucuReq = (SubmitUnifiedMXCreditUpdateRequest) eventManager
				.getWorkflowData(WorkflowConstants.SUBMIT_UNIFIED_CREDIT_UPDATE_REQUEST);
		sucuRes= euccMock.generateEUCCMock(sucuReq.getDealerName());
		eventManager.putWorkflowData(WorkflowConstants.WORKFLOW_SUCU_RESP, sucuRes);
		return WorkflowConstants.WORKFLOW_RESULT_SUCCESS;
	}

}
