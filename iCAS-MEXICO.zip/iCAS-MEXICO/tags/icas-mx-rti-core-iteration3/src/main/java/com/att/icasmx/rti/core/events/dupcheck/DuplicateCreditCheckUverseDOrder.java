package com.att.icasmx.rti.core.events.dupcheck;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowEventHandler;

/**
 * The Class DuplicateCreditCheckUverseDOrder.
 */
public class DuplicateCreditCheckUverseDOrder implements WorkflowEventHandler {

	/** The logger. */
	private static final Logger LOGGER = LogManager
			.getLogger(DuplicateCreditCheckUverseDOrder.class.getName());

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.att.icas.workflow.WorkflowAbstractEventHandler#execute(com.att.icas
	 * .workflow.EventManager)
	 */
	public String execute(EventManager eventManager) {
		LOGGER.info("DuplicateCreditCheckUverseEOrder.execute called");

		return eventManager.eventEnd(WorkflowConstants.WORKFLOW_RESULT_SUCCESS);
	}

}
