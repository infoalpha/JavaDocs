package com.att.icasmx.rti.util;


import org.apache.logging.log4j.ThreadContext;

import com.att.icasmx.rti.constants.ICASConstants;

// TODO: Auto-generated Javadoc
/**
 * The Class MDCUtil.
 */
public class MDCUtil {

	/**
	 * Sets the transaction name.
	 *
	 * @param transactionName the new transaction name
	 */
	public static void setTransactionName(String transactionName) {
		
		ThreadContext.put(ICASConstants.TRANSACTION_NAME, transactionName);
		ThreadContext.put(ICASConstants.THREAD_NAME, ThreadIdentityUtil.getThreadShortName());			
	}

	/**
	 * Sets the transaction id.
	 *
	 * @param transactionId the new transaction id
	 */
	public static void setTransactionId(String transactionId) {
		ThreadContext.put(ICASConstants.TRANSACTION_ID, transactionId);
	}

	/**
	 * Clear.
	 */
	public static void clear() {
		ThreadContext.clearMap();	
	}

	/** CAST changes for 'Provide a private default constructor for utility classes' rule */
	private MDCUtil () {
		
	}
}


