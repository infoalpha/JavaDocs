package com.att.icasmx.rti.services;

import com.att.icasmx.rti.constants.Language;
import com.att.icasmx.rti.core.data.ICASError;
import com.att.icasmx.rti.ws.ErrorInfo;


/**
 * @author bb047p
 * 
 * ICAS Error Service
 */
public interface ErrorService {
	
	/**
	 * Get ICAS error using error code
	 * @param the error code integer
	 * @return ICASError
	 */
	public ICASError getICASError(String errorCode);
	
	
	/**
	 * Get ErrorInfo object using error code and language
	 * @param errorCode
	 * @param language
	 * @return ErrorInfo
	 */
	public ErrorInfo getErrorInfo(String errorCode, Language language);
	
}
