package com.att.icasmx.rti.services.mock;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.att.icasmx.rti.core.data.AdditionalDocumentation;
import com.att.icasmx.rti.core.data.EUCC_RSP;
import com.att.icasmx.rti.util.MockUtils;

@Component("euccMock")
public class EUCCMockGenerator {
	private static final Logger logger = LogManager
			.getLogger(EUCCMockGenerator.class.getName());

	/**
	 * 
	 * @param euccreq
	 * @return
	 */
	public EUCC_RSP generateEUCCMock(String dealerName) {
		logger.debug("Entering EUCCMockGenerator : generateEUCCMock"
				+ dealerName);
		EUCC_RSP euccres = null;
		boolean debtIndicator = false;
		boolean docIndicator = false;
		String tokens[] = StringUtils.split(dealerName, "-");
		euccres = new EUCC_RSP();
		for (int i = 1; i < tokens.length; i++) {
			System.out.println("token -->" + tokens[i]);
			if (tokens[i].contains("CREDIT")) {
				String creditClass = splitValueWitSeparator(tokens[i]);
				euccres = generateCreditTypeMock(creditClass, euccres);

			} else if (tokens[i].contains("ALERT")) {
				String severity = splitValueWitSeparator(tokens[i]);
				euccres = generateAlertTypeMock(severity, euccres);

			} else if (tokens[i].contains("DEBT")) {
				String debtValue = splitValueWitSeparator(tokens[i]);				
				euccres = generateDebtTypeMock(debtValue, euccres);
				debtIndicator = true;
				
			} else if (tokens[i].contains("DOC")) {
				String docType = splitValueWitSeparator(tokens[i]);
				euccres = generateDocTypeMock(docType, euccres);
				docIndicator = true;
			} else if (tokens[i].contains("ERROR")
					|| tokens[i].contains("INPUTERR")) {
				euccres = generateErrorMock(tokens[i]);

			} else
				euccres = generateErrorMock("INPUTERR");
			
			
			if(null != euccres && euccres.getErrorCode().equals("100") || euccres.getErrorCode().equals("999"))
			{	
				debtIndicator = false;
				docIndicator = false;
				break;
			}
			
			
		}

		if (debtIndicator && docIndicator) {
			// overwrite and set status reason
			euccres.setStatusReason("DBTFR");
			euccres.setAdditionalDocumentationReqIndicator("TRUE");
		}
		return euccres;
	}

	private String splitValueWitSeparator(String inputValue) {
		String outputVal = "";
		String value[] = StringUtils.split(inputValue, ":");
		if (value != null && value.length > 1) {
			outputVal = value[1];
		}
		return outputVal;

	}

	/**
	 * 
	 * @param err
	 * @param euccres
	 * @return
	 */
	public  EUCC_RSP generateErrorMock(String err) {
		EUCC_RSP euccres = new EUCC_RSP();
		if (err.equals("ERROR")) {
			euccres.setStatusReason("ERROR");
			euccres.setStatus("AR");
			euccres.setErrorCode("999");
			euccres.setErrorMessage("Unknown Error Occurred");
			euccres.setErrorSource("ICAS");

		}
		if (err.equals("INPUTERR")) {
			euccres.setStatusReason("ICINP");
			euccres.setStatus("PA");
			euccres.setErrorCode("100");
			euccres.setErrorMessage("Invalid Request");
			euccres.setErrorSource("ICAS");
		}
		return euccres;
	}

	/**
	 * 
	 * @param debtValue
	 * @return
	 */
	private EUCC_RSP generateDebtTypeMock(String debtValue, EUCC_RSP euccres) {
		
		if(debtValue!=null && !debtValue.equals(""))
		{euccres.setStatus("AR");
		euccres.setStatusReason("DEBT");
		euccres.setOutstandingDebtIndicator("TRUE");
		euccres.setOutstandingDebtMinAmountDue(debtValue);
		euccres.setOutstandingDebtPastAmountDue(debtValue);
		euccres.setAdditionalDocumentationReqIndicator("FALSE");		
		}
		else 
			euccres = generateErrorMock("INPUTERR");
		return euccres;
	}

	/**
	 * 
	 * @param creditClass
	 * @return
	 */
	private EUCC_RSP generateCreditTypeMock(String creditClass, EUCC_RSP euccres) {
		if (null != creditClass && !creditClass.equals("")
				&& MockUtils.validateCreditClass(creditClass)) {
			euccres.setCreditClass(creditClass);
			euccres.setStatus("CA");
			euccres.setStatusReason("CRDEC");
			euccres.setAdditionalDocumentationReqIndicator("FALSE");
		} else {
			logger.error("generateCreditTypeMock -> Error Wrong  creditClass: generating Input Error");
			euccres = generateErrorMock("INPUTERR");
		}

		return euccres;
	}

	/**
	 * 
	 * @param severity
	 * @return
	 */
	private EUCC_RSP generateAlertTypeMock(String severity, EUCC_RSP euccres) {

		if (null != severity && !severity.equals("")) {
			euccres.setStatus("AR");
			euccres.setStatusReason("FRAUD");
			euccres.setWorkListIndicator("TRUE");
			euccres.setWorkListAlertSeverity(severity);
			List<String> workList = MockUtils.getWorkListAlertReason(severity);
			if (workList != null && !workList.get(0).equals("ERR")) {
				euccres.setWorkListAlertReasonCode(workList.get(0));
				euccres.setWorkListAlertMessage_en(workList.get(1));
			} else {
				euccres = generateErrorMock("INPUTERR");
			}
		} else {
			logger.debug("generateAlertTypeMock - > Error wrong severity : generating Input Error");
			euccres = generateErrorMock("INPUTERR");
		}
		return euccres;
	}

	/**
	 * 
	 * @param docType
	 *            - can be single or multiple docType
	 */
	private EUCC_RSP generateDocTypeMock(String docType, EUCC_RSP euccres) {
		if (null != docType && !docType.equals("")) {
			euccres.setStatus("AR");
			euccres.setStatusReason("FORMS");
			euccres.setAdditionalDocumentationReqIndicator("TRUE");
			List<AdditionalDocumentation> addDocs = MockUtils
					.populateDocments(docType);
			if (addDocs != null
					&& ((AdditionalDocumentation) addDocs.get(0))
							.getReasonCode().equals("INPUTERR")) {
				logger.debug("generateDocTypeMock - > Error wrong Doc Type : generating Input Error");
				euccres = generateErrorMock("INPUTERR");
			} else {
				euccres.setAdditionalDoc(addDocs);
			}

		} else {
			logger.debug("generateDocTypeMock - > Error wrong Doc Type : generating Input Error");
			euccres = generateErrorMock("INPUTERR");
		}

		return euccres;
	}

}
