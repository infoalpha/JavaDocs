package com.att.icasmx.rti.services;

import com.att.icasmx.rti.exception.ICASException;


/**
 * @author vk4235 Class CommonService This Class is collection of common methods
 *         which gets invoked during all workflow
 * 
 */

public interface CommonService {

	/**
	 * atTransactionAndEventBegin
	 * 
	 * @throws ICASException
	 */
	public void atTransactionAndEventBegin();

	/**
	 * atTransactionAndEventEnd
	 * 
	 * @throws ICASException
	 */
	public void atTransactionAndEventEnd();
}
