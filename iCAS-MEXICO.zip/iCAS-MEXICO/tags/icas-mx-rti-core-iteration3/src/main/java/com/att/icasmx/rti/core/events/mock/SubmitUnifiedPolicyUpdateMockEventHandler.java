package com.att.icasmx.rti.core.events.mock;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.icasmx.rti.core.data.EUPC_RESPONSE;
import com.att.icasmx.rti.core.data.SUPU_RESPONSE;
import com.att.icasmx.rti.exception.ICASException;
import com.att.icasmx.rti.services.mock.ExecuteUnifiedPolicyCheckMockGenerator;
import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowEventHandler;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXPolicyCheckRequest;
import com.att.icasmx.rti.ws.SubmitUnifiedMXPolicyUpdateRequest;

public class SubmitUnifiedPolicyUpdateMockEventHandler implements
WorkflowEventHandler {

	private static final Logger LOGGER=LogManager.getLogger(SubmitUnifiedPolicyUpdateMockEventHandler.class.getName());
	
	@Autowired
	ExecuteUnifiedPolicyCheckMockGenerator eupcMockGenarator;   
	
	public String execute(EventManager eventManager) {
		LOGGER.debug("Entering SubmitUnifiedPolicyUpdateMockEventHandler");
	EUPC_RESPONSE supu_Response;
	    SubmitUnifiedMXPolicyUpdateRequest submitUnifiedMXPolicyUpdateRequest = (SubmitUnifiedMXPolicyUpdateRequest) eventManager
				.getWorkflowData(WorkflowConstants.SUBMIT_UNIFIED_POLICY_UPDATE_REQUEST);
		LOGGER.debug("Dealer Name:"+submitUnifiedMXPolicyUpdateRequest.getDealerName());
		System.out.println("*********Dealer Name:********SUPU*******"+submitUnifiedMXPolicyUpdateRequest.getDealerName()+"******************");
		try{
		supu_Response= eupcMockGenarator.createECUPCMockUpResponse(submitUnifiedMXPolicyUpdateRequest);
		}catch(RuntimeException icasException){
			LOGGER.error(icasException.getStackTrace());
			supu_Response=null;
		}
		eventManager.putWorkflowData(WorkflowConstants.SUPU_MOCK_RESPONSE_DATA, supu_Response);
		LOGGER.debug("Exiting SubmitUnifiedPolicyUpdateMockEventHandler");
		return WorkflowConstants.WORKFLOW_RESULT_SUCCESS;
	}

}
