package com.att.icasmx.rti.core.events.response;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.att.icasmx.rti.constants.ICASConstants;
import com.att.icasmx.rti.core.data.AdditionalDocumentation;
import com.att.icasmx.rti.core.data.EUPC_RESPONSE;
import com.att.icasmx.rti.util.MockUtils;
import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowEventHandler;
import com.att.icasmx.rti.ws.DocumentationRequiredInfo;
import com.att.icasmx.rti.ws.DocumentationStatusCodeInfo;
import com.att.icasmx.rti.ws.DocumentationTypeInfo;
import com.att.icasmx.rti.ws.ErrorInfo;
import com.att.icasmx.rti.ws.InquireUnifiedMXPolicyCheckResultRequest;
import com.att.icasmx.rti.ws.InquireUnifiedMXPolicyCheckResultResponse;
import com.att.icasmx.rti.ws.PolicyCheckResultInfo;
import com.att.icasmx.rti.ws.PolicyDetailInfo;
import com.att.icasmx.rti.ws.PolicyEnforcementLevelInfo;
import com.att.icasmx.rti.ws.PolicyItemCodeInfo;
import com.att.icasmx.rti.ws.PolicyLineDetailInfo;
import com.att.icasmx.rti.ws.PolicyOptionInfo;
import com.att.icasmx.rti.ws.StatusInfo;
import com.att.icasmx.rti.ws.WorklistAlertInfo;
import com.att.icasmx.rti.ws.WorklistAlertReasonInfo;
import com.att.icasmx.rti.ws.WorklistAlertSeverityInfo;

/**
 * @author bb047p
 * 
 *         class InquireUnifiedPolicyCheckResponseHandler
 * 
 */
public class InquireUnifiedPolicyCheckResponseEventHandler implements WorkflowEventHandler {

	private static final Logger LOGGER = LogManager.getLogger(
			InquireUnifiedPolicyCheckResponseEventHandler.class.getName());

	private static final String HYPHEN = "-";

	private static final String DEPOSIT_DELIMITER = ":";

	/**
	 * Execute IUPC response event handler
	 * 
	 * @param EventManager
	 * @return String event result
	 */
	public String execute(EventManager eventManager) {
		LOGGER.info("IUPC - Response event handler");

		InquireUnifiedMXPolicyCheckResultResponse schemaResponse = null;
		InquireUnifiedMXPolicyCheckResultRequest schemaRequest = null;
		EUPC_RESPONSE eupcResponse = null;

		HashMap<String, Object> results = (HashMap<String, Object>) eventManager.getWorkflowDataMap();
		eupcResponse = (EUPC_RESPONSE) results.get("EUPC_RSP");
		schemaRequest = (InquireUnifiedMXPolicyCheckResultRequest) results.get(WorkflowConstants.INQUIRE_UNIFIED_POLICY_CHECK_REQUEST);

		try {
			schemaResponse = parseMockResponseData(schemaResponse, eupcResponse, schemaRequest);
		} catch (RuntimeException runtimeException) {
			LOGGER.error(runtimeException.getMessage());
			schemaResponse = populateErrorResponse(schemaResponse, schemaRequest);
		}

		String workflowResultType = WorkflowConstants.WORKFLOW_RESULT_SUCCESS;
		String workflowResultObjectKey = WorkflowConstants.WORKFLOW_RESULT_NAME_POLICY_RESULT_MOCKUP;
		
		schemaResponse.setUnifiedPolicyTransactionId(schemaRequest.getUnifiedPolicyTransactionId());
		return eventManager.eventEnd(workflowResultType, workflowResultObjectKey, schemaResponse);
	}

	public InquireUnifiedMXPolicyCheckResultResponse parseMockResponseData(
			InquireUnifiedMXPolicyCheckResultResponse executeUnifiedMXPolicyCheckResponse,
			EUPC_RESPONSE eupcMockupResponseData, InquireUnifiedMXPolicyCheckResultRequest executeUnifiedMXPolicyCheckRequest) {

		if (eupcMockupResponseData != null) {
			executeUnifiedMXPolicyCheckResponse = new InquireUnifiedMXPolicyCheckResultResponse();
			PolicyCheckResultInfo policyCheckResultInfo = new PolicyCheckResultInfo();
			Map linesDepositMap = new HashMap<String, List<String>>();
			// Setting header information
			if (executeUnifiedMXPolicyCheckRequest.getWSHeader() != null)
				executeUnifiedMXPolicyCheckResponse = (InquireUnifiedMXPolicyCheckResultResponse) MockUtils.populateHeaders(
						executeUnifiedMXPolicyCheckRequest, executeUnifiedMXPolicyCheckResponse);
			// Setting Unique Transaction ID
			executeUnifiedMXPolicyCheckResponse.setUnifiedPolicyTransactionId(eupcMockupResponseData
					.getUnifiedPolicyTransactionID());
			executeUnifiedMXPolicyCheckResponse.setStatus(StatusInfo.fromValue(eupcMockupResponseData.getStatus()));
			executeUnifiedMXPolicyCheckResponse.setStatusReason(eupcMockupResponseData.getStatusReason());

			// Setting Shipping Address indicator
			if (eupcMockupResponseData.isShippingAddressRequired()) {
				executeUnifiedMXPolicyCheckResponse.setNewShippingAddressRequiredIndicator(eupcMockupResponseData
						.isShippingAddressRequired());
			}
			// Setting Number Of Approved Lines
			if (null != eupcMockupResponseData.getNumberOfLinesApproved()
					&& Integer.valueOf(eupcMockupResponseData.getNumberOfLinesApproved()) >= 0) {
				policyCheckResultInfo.setNumberOfLinesApproved(eupcMockupResponseData.getNumberOfLinesApproved());
			}
			// Setting DOC type info
			if (eupcMockupResponseData.isAdditionalDocumentRequired()) {
				executeUnifiedMXPolicyCheckResponse.setAdditionalDocumentationRequiredIndicator(eupcMockupResponseData
						.isAdditionalDocumentRequired());
				for (AdditionalDocumentation additionalDocumentation : eupcMockupResponseData
						.getAdditionalDocumentations()) {
					DocumentationRequiredInfo documentationRequiredInfo = new DocumentationRequiredInfo();
					documentationRequiredInfo.setDocumentationType(DocumentationTypeInfo
							.fromValue(additionalDocumentation.getDocumentationType()));
					documentationRequiredInfo.setReasonCode(DocumentationStatusCodeInfo
							.fromValue(additionalDocumentation.getReasonCode()));
					documentationRequiredInfo.setReasonText(additionalDocumentation.getReasonText_en());
					executeUnifiedMXPolicyCheckResponse.getAdditionalDocumentationRequired().add(
							documentationRequiredInfo);
				}
			}
			// Setting Alert WorkList Items
			if (eupcMockupResponseData.isWorkListIndicator()) {
				WorklistAlertInfo alertInfo = new WorklistAlertInfo();
				alertInfo.setReasonCode(WorklistAlertReasonInfo.fromValue(eupcMockupResponseData
						.getWorkListALertResonCode()));
				alertInfo.setSeverity(WorklistAlertSeverityInfo.fromValue(eupcMockupResponseData
						.getWorkListALertSeverity()));
				alertInfo.setMessage(eupcMockupResponseData.getWorkListAlertMessage_en());
				executeUnifiedMXPolicyCheckResponse.setWorklistIndicator(true);
				executeUnifiedMXPolicyCheckResponse.getWorklistAlert().add(alertInfo);
			}
			// Setting Error
			if (eupcMockupResponseData.getErrorCode() != null) {
				ErrorInfo errorInfo = new ErrorInfo();
				errorInfo.setErrorCode(eupcMockupResponseData.getErrorCode());
				errorInfo.setErrorMessage(eupcMockupResponseData.getErrorMessage());
				errorInfo.setErrorSource(eupcMockupResponseData.getErrorsource());
				executeUnifiedMXPolicyCheckResponse.getError().add(errorInfo);
			}
			if (null != eupcMockupResponseData.getLineID() && eupcMockupResponseData.getLineID().size() > 0) {
				for (int i = 1; null != eupcMockupResponseData.getLineID()
						&& i <= eupcMockupResponseData.getLineID().size(); i++) {

					LOGGER.debug("LineIDIndicator List Size "
							+ eupcMockupResponseData.getLineApprovedIndicatorlist().size());

					PolicyLineDetailInfo policyLineDetailInfo = new PolicyLineDetailInfo();
					PolicyOptionInfo policyOptionInfo = new PolicyOptionInfo();

					policyLineDetailInfo.setLineId(eupcMockupResponseData.getLineID().get(i - 1));
					policyLineDetailInfo.setLineApprovedIndicator(eupcMockupResponseData.getLineApprovedIndicatorlist()
							.get(i - 1));
					policyLineDetailInfo.setPolicyRequiredIndicator(eupcMockupResponseData
							.getPolicyRequiredIndicatorlist().get(i - 1));

					linesDepositMap = eupcMockupResponseData.getLinesdepositMap();

					List<String> lineDepositList = (List<String>) linesDepositMap.get(String.valueOf(i));
					for (int j = 0; j < lineDepositList.size(); j++) {
						PolicyDetailInfo PolicyDetailInfo = new PolicyDetailInfo();
						String lineDepositDetailsString = (String) lineDepositList.get(j);
						List<String> depositDetailsList = Arrays.asList(lineDepositDetailsString
								.split(DEPOSIT_DELIMITER));
						PolicyDetailInfo.setPolicyItemCode(PolicyItemCodeInfo
								.fromValue(new String(depositDetailsList.get(0).substring(0, 3))
										+ HYPHEN
										+ new String(depositDetailsList.get(0).substring(3,
												depositDetailsList.get(0).length()))));
						PolicyDetailInfo.setPolicyItemAmount(new BigDecimal(depositDetailsList.get(1)));
						PolicyDetailInfo.setPolicyItemDescription(depositDetailsList.get(2));
						PolicyDetailInfo.setPolicyEnforcementLevel(PolicyEnforcementLevelInfo
								.valueOf(depositDetailsList.get(3)));
						policyOptionInfo.getPolicyItem().add(PolicyDetailInfo);

					}
					policyOptionInfo.setPolicyId(eupcMockupResponseData.getPolicyIdList().get(i - 1));
					policyLineDetailInfo.getPolicyOption().add(policyOptionInfo);
					policyCheckResultInfo.getPoliciesForLines().add(policyLineDetailInfo);
				}

				executeUnifiedMXPolicyCheckResponse.setPolicyCheckResult(policyCheckResultInfo);
			}
		} else {
			executeUnifiedMXPolicyCheckResponse = populateErrorResponse(executeUnifiedMXPolicyCheckResponse,
					executeUnifiedMXPolicyCheckRequest);
		}

		return executeUnifiedMXPolicyCheckResponse;
	}

	public InquireUnifiedMXPolicyCheckResultResponse populateErrorResponse(
			InquireUnifiedMXPolicyCheckResultResponse executeUnifiedMXPolicyCheckResponse,
			InquireUnifiedMXPolicyCheckResultRequest executeUnifiedMXPolicyCheckRequest) {
		executeUnifiedMXPolicyCheckResponse = new InquireUnifiedMXPolicyCheckResultResponse();
		if (executeUnifiedMXPolicyCheckRequest.getWSHeader() != null) {
			executeUnifiedMXPolicyCheckResponse = (InquireUnifiedMXPolicyCheckResultResponse) MockUtils.populateHeaders(
					executeUnifiedMXPolicyCheckRequest, executeUnifiedMXPolicyCheckResponse);
		}
		executeUnifiedMXPolicyCheckResponse.setUnifiedPolicyTransactionId(MockUtils
				.getMockUnifiedTransactionId(WorkflowConstants.POLICY_TYPE));
		ErrorInfo errorInfo = new ErrorInfo();
		errorInfo.setErrorCode(ICASConstants.INPUT_ERROR_CODE);
		errorInfo.setErrorMessage(ICASConstants.INPUT_ERROR_MSG);
		errorInfo.setErrorSource(ICASConstants.ICAS_SYSTEM_ID);
		executeUnifiedMXPolicyCheckResponse.setStatus(StatusInfo.fromValue(ICASConstants.SCHEMA_ERROR_CODE));
		executeUnifiedMXPolicyCheckResponse.setStatusReason(ICASConstants.SCHEMA_ERROR_REASON);
		executeUnifiedMXPolicyCheckResponse.getError().add(errorInfo);
		return executeUnifiedMXPolicyCheckResponse;
	}

}
