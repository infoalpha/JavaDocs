package com.att.icasmx.rti.core.events.vri;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.springframework.stereotype.Component;
import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowEventHandler;


// TODO: Auto-generated Javadoc
/**
 * The Class VRICCRInquireDebt.
 */

public class VRICCRInquireDebt implements WorkflowEventHandler {

	/** The logger. */
	private static Logger  logger = LogManager.getLogger(VRICCRInquireDebt.class.getName());	
	
	
	
	/* (non-Javadoc)
	 * @see com.att.icas.workflow.WorkflowAbstractEventHandler#execute(com.att.icas.workflow.EventManager)
	 */

	public String execute(EventManager eventManager) {
		logger.info("VRICCRInquireDebt called");
	
		
		return eventManager.eventEnd(WorkflowConstants.WORKFLOW_RESULT_SUCCESS);
	}
	


}
