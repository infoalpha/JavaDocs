package com.att.icasmx.rti.core.events.dupcheck;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.att.icasmx.rti.exception.ICASException;
import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowEventHandler;
/**
 * The Class DuplicateCreditCheckUverseEOrder.
 */

public class DuplicateCreditCheckUverseEOrder implements WorkflowEventHandler {
	/** The logger. */
	private static final Logger LOGGER = LogManager
			.getLogger(DuplicateCreditCheckUverseEOrder.class.getName());

	

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.att.icas.workflow.WorkflowAbstractEventHandler#execute(com.att.icas
	 * .workflow.EventManager)
	 */

	public String execute(EventManager eventManager) {
		LOGGER.debug(" DuplicateCreditCheckUverseEOrder.execute called ");

		try {
			// Call DupCheck Service
		} catch (ICASException e) {
			// set appropriate next event
			//LOGGER.error(e.getMessage());
			return WorkflowConstants.WORKFLOW_RESULT_FAILURE;
		}

		return WorkflowConstants.WORKFLOW_RESULT_SUCCESS;

	}

}
