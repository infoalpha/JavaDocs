package com.att.icasmx.rti.core.events.mock;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.icasmx.rti.core.data.EUPC_RESPONSE;
import com.att.icasmx.rti.exception.ICASException;
import com.att.icasmx.rti.services.mock.ExecuteUnifiedPolicyCheckMockGenerator;
import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowEventHandler;
import com.att.icasmx.rti.ws.UpdateUnifiedMXPolicyApplicationRequest;;

public class UpdateUnifiedPolicyApplicationMockEventHandler implements
WorkflowEventHandler {

	private static final Logger LOGGER=LogManager.getLogger(UpdateUnifiedPolicyApplicationMockEventHandler.class.getName());
	
	@Autowired
	ExecuteUnifiedPolicyCheckMockGenerator eupcMockGenarator;   
	
	public String execute(EventManager eventManager) {
		LOGGER.debug("Entering UpdateUnifiedPolicyMockEventHandler");
	    EUPC_RESPONSE ecupcResponse;
	    UpdateUnifiedMXPolicyApplicationRequest updateUnifiedMXPolicyRequest = (UpdateUnifiedMXPolicyApplicationRequest) eventManager
				.getWorkflowData(WorkflowConstants.UPDATE_UNIFIED_POLICY_REQUEST);
		LOGGER.debug("Dealer Name:"+updateUnifiedMXPolicyRequest.getDealerCode());
		System.out.println("*********Dealer Code:*****UUP**********"+updateUnifiedMXPolicyRequest.getDealerCode()+"******************");
		try{
		ecupcResponse= eupcMockGenarator.createECUPCMockUpResponse(updateUnifiedMXPolicyRequest);
		}catch(RuntimeException icasException){
			LOGGER.error(icasException.getStackTrace());
			ecupcResponse=null;
		}
		eventManager.putWorkflowData(WorkflowConstants.EUPC_MOCK_RESPONSE_DATA, ecupcResponse);
		LOGGER.debug("Exiting UpdateUnifiedPolicyMockEventHandler");
		return WorkflowConstants.WORKFLOW_RESULT_SUCCESS;
	}

}
