package com.att.icasmx.rti.constants;

public enum Language {
	
	English("en"),
	Spanish("es");
	
	/** The language code */
	private final String code;
	
	/**
	 * Initialize the Language enum
	 * @param code
	 */
	private Language(String code) {
		this.code = code;
	}
	
	/**
	 * Get Language using a string code
	 * @param code
	 * @return Language enum
	 */
	public static Language getLanguageByCode(String code) {
		for(Language language : Language.values()) {
			if(language.code == code) {
				return language;
			}
		}
		return null;
	}
	
	/**
	 * Get code for a Language
	 * @return code
	 */
	public String getCode() {
		return code;
	}
	
}
