package com.att.icasmx.rti.core.events.mock;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.icasmx.rti.core.data.EUCC_RSP;
import com.att.icasmx.rti.services.mock.EUCCMockGenerator;
import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowEventHandler;
import com.att.icasmx.rti.ws.InquireUnifiedMXCreditCheckResultRequest;

public class InquireUnifiedCreditCheckMockEventHandler implements WorkflowEventHandler {
	
	private static final Logger LOGGER = LogManager.getLogger();
	
	@Autowired
	EUCCMockGenerator euccMock;
	
	/**
	 * Execute IUCC mock event handler
	 * @param EventManager
	 * @return String event result
	 */
	@Override
	public String execute(EventManager eventManager) {
		LOGGER.info("IUCC - Mock Generator called");
		InquireUnifiedMXCreditCheckResultRequest request = (InquireUnifiedMXCreditCheckResultRequest) 
								eventManager.getWorkflowData(WorkflowConstants.INQUIRE_UNIFIED_CREDIT_CHECK_REQUEST);
		EUCC_RSP euccRes = euccMock.generateEUCCMock(request.getDealerName());
		return eventManager.eventEnd(WorkflowConstants.WORKFLOW_RESULT_SUCCESS, WorkflowConstants.WORKFLOW_EUCC_RESP, euccRes);
	}

}
