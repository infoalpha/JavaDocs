package com.att.icasmx.rti.util;

import org.apache.commons.lang3.StringUtils;
 
/**
 * The Class ThreadIdentityUtil.
 */
public class ThreadIdentityUtil {

	/**
	 * Gets the thread name.
	 * 
	 * @return the thread name
	 */
	public static String getThreadName() {
		String threadName = Thread.currentThread().getName();
		return threadName;
	}

	// Parse out the number portion of the long Weblogic thread name. That is,
	// get the '9' from:
	// [ACTIVE] ExecuteThread: '9' for queue: 'weblogic.kernel.Default
	// (self-tuning)'
	/**
	 * Gets the thread short name.
	 * 
	 * @return the thread short name
	 */
	public static String getThreadShortName() {
		String threadName = Thread.currentThread().getName();
		threadName = "THREAD-" + StringUtils.substringBetween(threadName, "'");
		return threadName;
	}

	/**
	 * Gets the thread id.
	 * 
	 * @return the thread id
	 */
	public long getThreadId() {
		long threadId = Thread.currentThread().getId();
		return threadId;
	}
}
