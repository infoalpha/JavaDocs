/**
 * 
 */
package com.att.icasmx.rti.core.data;

import java.util.List;
import java.util.Map;




/**
 * @author vk4235
 * Class EUPC_RESPONSE DATA OBJECT
 * 
 */
public class EUPC_RESPONSE {
	 
	
	/**
	 * unifiedPolicyTransactionID
	 */
	private String unifiedPolicyTransactionID;
	
	/**
	 * correlationID
	 */
	private String correlationId;
		
	/**
	 * convesationID
	 */
	private String convesationID;
	
    /**
     * status
     */
	private String status;
	 /**
      * statusReason
      */
	private String statusReason;
	 /**
      * numberOfLinesApproved
      */
	private String numberOfLinesApproved;
	 /**
      * shippingAddressRequired
      */
	private boolean shippingAddressRequired;
	 /**
      * lineApprovedIndicatorlist
      */
	private List<Boolean>  lineApprovedIndicatorlist;
	 /**
      * policyRequiredIndicatorList
      */
	private List<Boolean>  policyRequiredIndicatorList;
	 /**
      * LinesdepositMap
      */
	private Map LinesdepositMap; 
	 /**
      * lineID
      */
	private List<String> lineID;
	 /**
      * policyIdList
      */
	private List<String> policyIdList;
	/**
	 * errorCode
	 */
	private String errorCode;
	/**
	 * errorMessage
	 */
	private String errorMessage;
	/**
	 * errorsource
	 */
	private String errorsource;
	/**
	 * workListIndicator
	 */
	private boolean workListIndicator;
	/**
	 * workListALertSeverity
	 */
	private String workListALertSeverity;
	/**
	 * workListALertResonCode
	 */
	private String workListALertResonCode;
	/**
	 * workListAlertMessage_en
	 */
	private String workListAlertMessage_en;
	/**
	 * workListAlertMessage_es
	 */
	private String workListAlertMessage_es;
	
	/**
	 * MessageCode
	 */
	private String messageCode;
    
	/**
	 * MessageText
	 */
	private String messageText;
	
	/**
	 * AdditionalDocumentRequired
	 */
	private boolean additionalDocumentRequired;
	
		/**
	 * Additional Documentation
	 * @return
	 */
	private List<AdditionalDocumentation> additionalDocumentations;
	

	public boolean isAdditionalDocumentRequired() {
		return additionalDocumentRequired;
	}

	public void setAdditionalDocumentRequired(boolean additionalDocumentRequired) {
		this.additionalDocumentRequired = additionalDocumentRequired;
	}
	
			
	public List<AdditionalDocumentation> getAdditionalDocumentations() {
		return additionalDocumentations;
	}

	public void setAdditionalDocumentations(
			List<AdditionalDocumentation> additionalDocumentations) {
		this.additionalDocumentations = additionalDocumentations;
	}

	public String getCorrelationId() {
		return correlationId;
	}

	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	public String getConvesationID() {
		return convesationID;
	}

	public void setConvesationID(String convesationID) {
		this.convesationID = convesationID;
	}

	public String getMessageCode() {
		return messageCode;
	}

	public void setMessageCode(String messageCode) {
		this.messageCode = messageCode;
	}

	public String getMessageText() {
		return messageText;
	}

	public void setMessageText(String messageText) {
		this.messageText = messageText;
	}
	
    
	

	public String getUnifiedPolicyTransactionID() {
		return unifiedPolicyTransactionID;
	}

	public void setUnifiedPolicyTransactionID(String unifiedPolicyTransactionID) {
		this.unifiedPolicyTransactionID = unifiedPolicyTransactionID;
	}

	public boolean isWorkListIndicator() {
		return workListIndicator;
	}

	public void setWorkListIndicator(boolean workListIndicator) {
		this.workListIndicator = workListIndicator;
	}

	public String getWorkListALertSeverity() {
		return workListALertSeverity;
	}

	public void setWorkListALertSeverity(String workListALertSeverity) {
		this.workListALertSeverity = workListALertSeverity;
	}

	public String getWorkListALertResonCode() {
		return workListALertResonCode;
	}

	public void setWorkListALertResonCode(String workListALertResonCode) {
		this.workListALertResonCode = workListALertResonCode;
	}

	public String getWorkListAlertMessage_en() {
		return workListAlertMessage_en;
	}

	public void setWorkListAlertMessage_en(String workListAlertMessage_en) {
		this.workListAlertMessage_en = workListAlertMessage_en;
	}

	public String getWorkListAlertMessage_es() {
		return workListAlertMessage_es;
	}

	public void setWorkListAlertMessage_es(String workListAlertMessage_es) {
		this.workListAlertMessage_es = workListAlertMessage_es;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorsource() {
		return errorsource;
	}

	public void setErrorsource(String errorsource) {
		this.errorsource = errorsource;
	}

	public boolean isShippingAddressRequired() {
		return shippingAddressRequired;
	}

	public void setShippingAddressRequired(boolean shippingAddressRequired) {
		this.shippingAddressRequired = shippingAddressRequired;
	}

	public List<Boolean> getPolicyRequiredIndicatorList() {
		return policyRequiredIndicatorList;
	}

	public void setPolicyRequiredIndicatorList(
			List<Boolean> policyRequiredIndicatorList) {
		this.policyRequiredIndicatorList = policyRequiredIndicatorList;
	}

	public Map getLinesdepositMap() {
		return LinesdepositMap;
	}

	public void setLinesdepositMap(Map linesdepositMap) {
		LinesdepositMap = linesdepositMap;
	}
	
	public List<String> getPolicyIdList() {
		return policyIdList;
	}

	public void setPolicyIdList(List<String> policyIdList) {
		this.policyIdList = policyIdList;
	}

	public List<Boolean> getPolicyRequiredIndicatorlist() {
		return policyRequiredIndicatorList;
	}

	public void setPolicyRequiredIndicatorlist(List<Boolean> policyRequiredIndicatorlist) {
		this.policyRequiredIndicatorList = policyRequiredIndicatorlist;
	}
	
	public List<Boolean> getLineApprovedIndicatorlist() {
		return lineApprovedIndicatorlist;
	}

	public void setLineApprovedIndicatorlist(List<Boolean> lineApprovedIndicatorlist) {
		this.lineApprovedIndicatorlist = lineApprovedIndicatorlist;
	}

	public List<String> getLineID() {
		return lineID;
	}

	public void setLineID(List<String> lineID) {
		this.lineID = lineID;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusReason() {
		return statusReason;
	}

	public void setStatusReason(String statusReason) {
		this.statusReason = statusReason;
	}

	public String getNumberOfLinesApproved() {
		return numberOfLinesApproved;
	}

	public void setNumberOfLinesApproved(String numberOfLinesApproved) {
		this.numberOfLinesApproved = numberOfLinesApproved;
	}
	
	

}
