package com.att.icasmx.rti.workflow;

// TODO: Auto-generated Javadoc
/**
 * The Class WorkflowException.
 */
public class WorkflowException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7802197998365257395L;
	// wrap the original exception
	/** The nested exception. */
	private RuntimeException nestedException = null;

	/**
	 * Instantiates a new workflow exception.
	 *
	 * @param message the message
	 * @param exception the exception
	 */
	public WorkflowException(String message, RuntimeException exception) {
		super(message);
		this.nestedException = exception;
	}
	
	/**
	 * Instantiates a new workflow exception.
	 *
	 * @param message the message
	 */
	public WorkflowException(String message) {
		super(message);
	}
	
	/**
	 * Gets the nested exception.
	 *
	 * @return the nested exception
	 */
	public RuntimeException getNestedException() {
		return nestedException;
	}
}
