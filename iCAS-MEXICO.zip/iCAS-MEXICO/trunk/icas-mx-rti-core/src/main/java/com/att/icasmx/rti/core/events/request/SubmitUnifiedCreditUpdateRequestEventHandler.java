package com.att.icasmx.rti.core.events.request;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.icasmx.rti.constants.ICASConstants;
import com.att.icasmx.rti.core.data.EUCC_RSP;
import com.att.icasmx.rti.util.MDCUtil;
import com.att.icasmx.rti.util.MockUtils;
import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowEventHandler;
import com.att.icasmx.rti.ws.SubmitUnifiedMXCreditUpdateRequest;

/**
 * The Class ExecuteUnifiedCreditCheckRequestHandler.
 */

public class SubmitUnifiedCreditUpdateRequestEventHandler implements
		WorkflowEventHandler {



	private static final Logger LOGGER = LogManager
			.getLogger(SubmitUnifiedCreditUpdateRequestEventHandler.class
					.getName());

	public String execute(EventManager eventManager) {
	
			LOGGER.debug("Submit Unified Credit Update Request handler  called");
			MDCUtil.setTransactionName("Transaction Name");
			MDCUtil.setTransactionId("Transaaction ID"); //
			SubmitUnifiedMXCreditUpdateRequest sucuRqs = (SubmitUnifiedMXCreditUpdateRequest) eventManager
					.getWorkflowData(WorkflowConstants.SUBMIT_UNIFIED_CREDIT_UPDATE_REQUEST);
		//	eventManager.putWorkflowData(WorkflowConstants.WEBSCHEMA_RQS, sucuRqs);
			if (sucuRqs.getDealerName() != null
					&& sucuRqs.getDealerName().startsWith(ICASConstants.XMOCK_DEALER_PATTERN) && !StringUtils.contains(sucuRqs.getDealerName(),ICASConstants.XMOCK_DEBT)) {
				LOGGER.info(" SUCU : SubmitUnifiedCreditUpdateRequestEventHandler MOCK event called");
				return WorkflowConstants.WORKFLOW_MOCK_GEN;
			} else {
				LOGGER.debug("ERROR : SUCU REQ HANDLER ");
				EUCC_RSP euccRes = MockUtils.generateInputError();
				eventManager.putWorkflowData(WorkflowConstants.WORKFLOW_SUCU_RESP,euccRes);
				return WorkflowConstants.WORKFLOW_RESULT_FAILURE;	
			}		
		
	}

}
