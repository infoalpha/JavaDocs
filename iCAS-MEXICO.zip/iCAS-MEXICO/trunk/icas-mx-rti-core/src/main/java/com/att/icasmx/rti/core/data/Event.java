package com.att.icasmx.rti.core.data;

import java.sql.Timestamp;

public class Event {
	
	
	// Fields

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4618376320298912112L;

	/*
	 * Variables
	 */
	/** The event id. */
	private long eventId;

	private Transaction trans;

	/** The event name. */
	private String eventName;

	/** The event start time. */
	private Timestamp eventStartTime;

	/** The event end time. */
	private Timestamp eventEndTime;

	/** The stepone type. */
	private String steponeType;

	/** The stepone start time. */
	private Timestamp steponeStartTime;

	/** The stepone end time. */
	private Timestamp steponeEndTime;

	/** The steptwo type. */
	private String steptwoType;

	/** The steptwo start time. */
	private Timestamp steptwoStartTime;

	/** The steptwo end time. */
	private Timestamp steptwoEndTime;

	/** The status. */
	private String status;

	/** The status desc. */
	private String statusDesc;

	/** The result type. */
	private String resultType;

	/** The correlation key. */
	private String correlationKey;

	/**
	 * Gets the event id.
	 * 
	 * @return the event id
	 */
	public long getEventId() {
		return eventId;
	}

	/**
	 * Sets the event id.
	 * 
	 * @param eventId
	 *            the new event id
	 */
	public void setEventId(long eventId) {
		this.eventId = eventId;
	}

	/**
	 * Gets the event name.
	 * 
	 * @return the event name
	 */
	public String getEventName() {
		return eventName;
	}

	/**
	 * Sets the event name.
	 * 
	 * @param eventName
	 *            the new event name
	 */
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	/**
	 * Gets the event start time.
	 * 
	 * @return the event start time
	 */
	public Timestamp getEventStartTime() {
		// Fix Security Violation #2 Malicious code vulnerability - May expose
		// internal representation
		// by returning reference to mutable object
		// - MK5569 3/26/2015
		// return eventStartTime;
		if (eventStartTime != null)
			return new Timestamp(eventStartTime.getTime());
		else
			return null;
	}

	/**
	 * Sets the event start time.
	 * 
	 * @param eventStartTime
	 *            the new event start time
	 */
	public void setEventStartTime(Timestamp eventStartTime) {
		// Fix Security Violation #1 Malicious code vulnerability - May expose
		// internal representation
		// by incorporating reference to mutable object
		// - MK5569 3/26/2015
		// this.eventStartTime = eventStartTime;
		if (eventStartTime != null)
			this.eventStartTime = new Timestamp(eventStartTime.getTime());
		else
			this.eventStartTime = null;
	}

	/**
	 * Gets the event end time.
	 * 
	 * @return the event end time
	 */
	public Timestamp getEventEndTime() {
		// Fix Security Violation #2 Malicious code vulnerability - May expose
		// internal representation
		// by returning reference to mutable object
		// - MK5569 3/26/2015
		// return eventEndTime;
		if (eventEndTime != null)
			return new Timestamp(eventEndTime.getTime());
		else
			return null;
	}

	/**
	 * Sets the event end time.
	 * 
	 * @param eventEndTime
	 *            the new event end time
	 */
	public void setEventEndTime(Timestamp eventEndTime) {
		// Fix Security Violation #1 Malicious code vulnerability - May expose
		// internal representation
		// by incorporating reference to mutable object
		// - MK5569 3/26/2015
		// this.eventEndTime = eventEndTime;
		if (eventEndTime != null)
			this.eventEndTime = new Timestamp(eventEndTime.getTime());
		else
			this.eventEndTime = null;
	}

	/**
	 * Gets the stepone type.
	 * 
	 * @return the stepone type
	 */
	public String getSteponeType() {
		return steponeType;
	}

	/**
	 * Sets the stepone type.
	 * 
	 * @param steponeType
	 *            the new stepone type
	 */
	public void setSteponeType(String steponeType) {
		this.steponeType = steponeType;
	}

	/**
	 * Gets the stepone start time.
	 * 
	 * @return the stepone start time
	 */
	public Timestamp getSteponeStartTime() {
		// Fix Security Violation #2 Malicious code vulnerability - May expose
		// internal representation
		// by returning reference to mutable object
		// - MK5569 3/26/2015
		// return steponeStartTime;
		if (steponeStartTime != null)
			return new Timestamp(steponeStartTime.getTime());
		else
			return null;
	}

	/**
	 * Sets the stepone start time.
	 * 
	 * @param steponeStartTime
	 *            the new stepone start time
	 */
	public void setSteponeStartTime(Timestamp steponeStartTime) {
		// Fix Security Violation #1 Malicious code vulnerability - May expose
		// internal representation
		// by incorporating reference to mutable object
		// - MK5569 3/26/2015
		// this.steponeStartTime = steponeStartTime;
		if (steponeStartTime != null)
			this.steponeStartTime = new Timestamp(steponeStartTime.getTime());
		else
			this.steponeStartTime = null;
	}

	/**
	 * Gets the stepone end time.
	 * 
	 * @return the stepone end time
	 */
	public Timestamp getSteponeEndTime() {
		// Fix Security Violation #2 Malicious code vulnerability - May expose
		// internal representation
		// by returning reference to mutable object
		// - MK5569 3/26/2015
		// return steponeEndTime;
		if (steponeEndTime != null)
			return new Timestamp(steponeEndTime.getTime());
		else
			return null;
	}

	/**
	 * Sets the stepone end time.
	 * 
	 * @param steponeEndTime
	 *            the new stepone end time
	 */
	public void setSteponeEndTime(Timestamp steponeEndTime) {
		// Fix Security Violation #1 Malicious code vulnerability - May expose
		// internal representation
		// by incorporating reference to mutable object
		// - MK5569 3/26/2015
		// this.steponeEndTime = steponeEndTime;
		if (steponeEndTime != null)
			this.steponeEndTime = new Timestamp(steponeEndTime.getTime());
		else
			this.steponeEndTime = null;
	}

	/**
	 * Gets the steptwo type.
	 * 
	 * @return the steptwo type
	 */
	public String getSteptwoType() {
		return steptwoType;
	}

	/**
	 * Sets the steptwo type.
	 * 
	 * @param steptwoType
	 *            the new steptwo type
	 */
	public void setSteptwoType(String steptwoType) {
		this.steptwoType = steptwoType;
	}

	/**
	 * Gets the steptwo start time.
	 * 
	 * @return the steptwo start time
	 */
	public Timestamp getSteptwoStartTime() {
		// Fix Security Violation #2 Malicious code vulnerability - May expose
		// internal representation
		// by returning reference to mutable object
		// - MK5569 3/26/2015
		// return steptwoStartTime;
		if (steptwoStartTime != null)
			return new Timestamp(steptwoStartTime.getTime());
		else
			return null;
	}

	/**
	 * Sets the steptwo start time.
	 * 
	 * @param steptwoStartTime
	 *            the new steptwo start time
	 */
	public void setSteptwoStartTime(Timestamp steptwoStartTime) {
		// Fix Security Violation #1 Malicious code vulnerability - May expose
		// internal representation
		// by incorporating reference to mutable object
		// - MK5569 3/26/2015
		// this.steptwoStartTime = steptwoStartTime;
		if (steptwoStartTime != null)
			this.steptwoStartTime = new Timestamp(steptwoStartTime.getTime());
		else
			this.steptwoStartTime = null;
	}

	/**
	 * Gets the steptwo end time.
	 * 
	 * @return the steptwo end time
	 */
	public Timestamp getSteptwoEndTime() {
		// Fix Security Violation #2 Malicious code vulnerability - May expose
		// internal representation
		// by returning reference to mutable object
		// - MK5569 3/26/2015
		// return steptwoEndTime;
		if (steptwoEndTime != null)
			return new Timestamp(steptwoEndTime.getTime());
		else
			return null;
	}

	/**
	 * Sets the steptwo end time.
	 * 
	 * @param steptwoEndTime
	 *            the new steptwo end time
	 */
	public void setSteptwoEndTime(Timestamp steptwoEndTime) {
		// Fix Security Violation #1 Malicious code vulnerability - May expose
		// internal representation
		// by incorporating reference to mutable object
		// - MK5569 3/26/2015
		// this.steptwoEndTime = steptwoEndTime;
		if (steptwoEndTime != null)
			this.steptwoEndTime = new Timestamp(steptwoEndTime.getTime());
		else
			this.steptwoEndTime = null;
	}

	/**
	 * Gets the status.
	 * 
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 * 
	 * @param status
	 *            the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the status desc.
	 * 
	 * @return the status desc
	 */
	public String getStatusDesc() {
		return statusDesc;
	}

	/**
	 * Sets the status desc.
	 * 
	 * @param statusDesc
	 *            the new status desc
	 */
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	/**
	 * Gets the result type.
	 * 
	 * @return the result type
	 */
	public String getResultType() {
		return resultType;
	}

	/**
	 * Sets the result type.
	 * 
	 * @param resultType
	 *            the new result type
	 */
	public void setResultType(String resultType) {
		this.resultType = resultType;
	}

	/**
	 * Gets the correlation key.
	 * 
	 * @return the correlation key
	 */
	public String getCorrelationKey() {
		return correlationKey;
	}

	/**
	 * Sets the correlation key.
	 * 
	 * @param correlationKey
	 *            the new correlation key
	 */
	public void setCorrelationKey(String correlationKey) {
		this.correlationKey = correlationKey;
	}

	public Transaction getTrans() {
		return trans;
	}

	public void setTrans(Transaction trans) {
		this.trans = trans;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
