package com.att.icasmx.rti.core.data;

import java.sql.Timestamp;

public class Main {

	/** The transaction id. */
	private String transactionId;

	/** The sys creation date. */
	private Timestamp sysCreationDate;

	/** The sys update date. */
	private Timestamp sysUpdateDate;

	/** The transaction start Time . */
	private Timestamp transactionStartTime;

	/** The Last Transaction Name. */
	private String  lastTransactionName;
	
	private Integer  lastTransactionSeq;

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public Timestamp getSysCreationDate() {
		return sysCreationDate;
	}

	public void setSysCreationDate(Timestamp sysCreationDate) {
		this.sysCreationDate = sysCreationDate;
	}

	public Timestamp getSysUpdateDate() {
		return sysUpdateDate;
	}

	public void setSysUpdateDate(Timestamp sysUpdateDate) {
		this.sysUpdateDate = sysUpdateDate;
	}

	public Timestamp getTransactionStartTime() {
		return transactionStartTime;
	}

	public void setTransactionStartTime(Timestamp transactionStartTime) {
		this.transactionStartTime = transactionStartTime;
	}

	public String getLastTransactionName() {
		return lastTransactionName;
	}

	public void setLastTransactionName(String lastTransactionName) {
		this.lastTransactionName = lastTransactionName;
	}

	public Integer getLastTransactionSeq() {
		return lastTransactionSeq;
	}

	public void setLastTransactionSeq(Integer lastTransactionSeq) {
		this.lastTransactionSeq = lastTransactionSeq;
	}


}
