package com.att.icasmx.rti.dao.impl;

import java.util.Calendar;
import java.util.concurrent.ThreadLocalRandom;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.att.icasmx.rti.core.data.Main;
import com.att.icasmx.rti.dao.MainDAO;
import com.att.icasmx.rti.workflow.WorkflowConstants;

@Repository
public class MainDAOImpl implements MainDAO {

		
	@Autowired
	private	NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	
    
	@Override
	public void saveMain(Main data) {		
		BeanPropertySqlParameterSource parameterSource = new BeanPropertySqlParameterSource(
				data);
		String SQL = "INSERT INTO ICAS_UC_MAIN(TRANSACTION_ID, SYS_CREATION_DATE, SYS_UPDATE_DATE, TRANSACTION_START_TIME) VALUES (:transactionId,:sysCreationDate,:sysUpdateDate,:transactionStartTime)";
	    namedParameterJdbcTemplate.update(SQL,parameterSource);	
	}
	
	
	/**
	 * Generates unified credit transaction ID 
	 */
	
	@Override
	public String generateUCTransactionID() {
           
		final String SQL = "select ICAS_UC_CREDIT_SEQ.nextval from dual";		
        String ucTransactionID ="";        
		Long nextSeq = jdbcTemplate.queryForObject(SQL,Long.class);
		Calendar now = Calendar.getInstance();
		int year = now.get(Calendar.YEAR);
		int month = now.get(Calendar.MONTH) + 1; // Note: zero based!
		int day = now.get(Calendar.DAY_OF_MONTH);
		String monthString = Integer.toString(month).length() > 1 ? Integer
				.toString(month) : "0" + Integer.toString(month);
		String dayString = Integer.toString(day).length() > 1 ? Integer
				.toString(day) : "0" + Integer.toString(day);
		String yearString =Integer.toString(year).substring(2, 4);
		// MOCK UnifiedPolicyTransactionId C/P +13 DIGIT RANDOM NUMBER+ DDMMYY
		ucTransactionID = 	"C"+nextSeq.longValue()+dayString + monthString +yearString ;
		System.out.println("ucTransactionID"+ucTransactionID);
		return ucTransactionID;
	}



	@Override
	public Main getMain(String ucTransactionID) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
