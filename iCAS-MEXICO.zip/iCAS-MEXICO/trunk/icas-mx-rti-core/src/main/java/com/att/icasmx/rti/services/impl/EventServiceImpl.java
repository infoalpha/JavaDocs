package com.att.icasmx.rti.services.impl;

import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.icasmx.rti.core.data.Event;
import com.att.icasmx.rti.core.data.Main;
import com.att.icasmx.rti.core.data.Transaction;
import com.att.icasmx.rti.dao.EventDAO;
import com.att.icasmx.rti.dao.MainDAO;
import com.att.icasmx.rti.dao.TransactionDAO;
import com.att.icasmx.rti.exception.ICASException;
import com.att.icasmx.rti.services.EventService;

@Service
public class EventServiceImpl implements EventService {

	@Autowired
	MainDAO mainDAO;

	@Autowired
	EventDAO evtDAO;
	@Autowired
	TransactionDAO transDAO;

	/**
	 * 
	 * @param originalTransactionID
	 * @return
	 */
	@Override
	public Main atWorkFlowStart(String originalTransactionID, String transactionName, String eventName,
			String transactionType) {
		// Get a unique transaction ID
		Main mainData;
		if (null == originalTransactionID || "".equals(originalTransactionID)) {
			mainData = createMainAtWorkFlowStart();
			System.out.println("TESTING:"+mainData.getTransactionId());
		} else {
			mainData = getMainAtWorkFlowStart(originalTransactionID);
		}
		// create an Event entry -- Call
		// create a transaction Entry -->
		// TODO
		return mainData;

	}

	@Override
	public void atWorkflowEnd(Event event, Transaction transaction) {
		// TODO Auto-generated method stub

	}

	@Override
	public void atEventBegin(Event event) {
		// TODO Auto-generated method stub

	}

	@Override
	public void atEventEnd(Event event) {
		// TODO Auto-generated method stub

	}

	/**
	 * Method used to insert Main entry
	 * 
	 * @return - Main
	 */
	private Main createMainAtWorkFlowStart() {

		String unifiedTransactionID = "";
		unifiedTransactionID = mainDAO.generateUCTransactionID();
		Main mainData = new Main();
		mainData.setTransactionId(unifiedTransactionID);
		mainData.setSysCreationDate(new Timestamp(System.currentTimeMillis()));
		mainData.setSysUpdateDate(new Timestamp(System.currentTimeMillis()));
		mainData.setTransactionStartTime(new Timestamp(System.currentTimeMillis()));
		// mainDAO.saveMain(mainData);
		return mainData;
	}

	/**
	 * 
	 * @param ucTransactionId
	 * @param transactionType
	 * @param transactionName
	 * @param transactionIdType
	 * @param startTime
	 * @param sourceApplicationId
	 * @return
	 */
	private Main getMainAtWorkFlowStart(String originalTransactionID) {

		Main mainData;
		mainData = mainDAO.getMain(originalTransactionID);
		return mainData;

	}

}
