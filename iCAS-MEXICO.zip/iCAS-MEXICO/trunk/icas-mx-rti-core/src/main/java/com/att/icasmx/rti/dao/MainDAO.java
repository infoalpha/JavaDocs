package com.att.icasmx.rti.dao;

import com.att.icasmx.rti.core.data.Main;

public interface MainDAO {

	/**
	 * @return Transaction ID 
	 */
	public void saveMain(Main obj);
	
	/**
	 * 
	 * @return - Returns generated transaction ID 
	 */
	public String generateUCTransactionID();
	
	/**
	 * 
	 * @param ucTransactionID - unified credit transaction ID 
	 * @return
	 */
	public Main getMain(String ucTransactionID);
	
}
