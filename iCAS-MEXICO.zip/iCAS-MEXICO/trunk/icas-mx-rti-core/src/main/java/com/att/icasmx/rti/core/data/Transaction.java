package com.att.icasmx.rti.core.data;

import java.sql.Timestamp;

public class Transaction {
	
	private Event event;

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5095632940596299801L;
	
	/** The transaction id. */
	private String transactionId;

	/** The transaction seq. */
	private int transactionSeq;

	/** The sys creation date. */
	private Timestamp sysCreationDate;

	/** The sys update date. */
	private Timestamp sysUpdateDate;

	/** The transaction name. */
	private String transactionName;

	/** The source app id. */
	private String sourceAppId;

	/** The trans start time. */
	private Timestamp transStartTime;

	/** The trans end time. */
	private Timestamp transEndTime;

	/** The trans status. */
	private String transStatus;

	/** The last event id. */
	private Long lastEventId;

	/** The last event name. */
	private String lastEventName;

	/** The last event end time. */
	private Timestamp lastEventEndTime;

	/** The last event status. */
	private String lastEventStatus;

	/** The env name. */
	private String envName;

	/** The csi conversation id. */
	private String csiConversationId;

	/** The csi toolkit version. */
	private String csiToolkitVersion;

	/**
	 * Gets the transaction id.
	 * 
	 * @return the transaction id
	 */
	public String getTransactionId() {
		return transactionId;
	}

	/**
	 * Sets the transaction id.
	 * 
	 * @param transactionId
	 *            the new transaction id
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	/**
	 * Gets the sys creation date.
	 * 
	 * @return the sys creation date
	 */
	public Timestamp getSysCreationDate() {
		// Fix Security Violation #2 Malicious code vulnerability - May expose
		// internal representation
		// by returning reference to mutable object
		// - MK5569 3/26/2015
		// return sysCreationDate;
		if (sysCreationDate != null)
			return new Timestamp(sysCreationDate.getTime());
		else
			return null;
	}

	/**
	 * Sets the sys creation date.
	 * 
	 * @param sysCreationDate
	 *            the new sys creation date
	 */
	public void setSysCreationDate(Timestamp sysCreationDate) {
		// Fix Security Violation #1 Malicious code vulnerability - May expose
		// internal representation
		// by incorporating reference to mutable object
		// - MK5569 3/27/2015
		if (sysCreationDate != null)
			this.sysCreationDate = new Timestamp(sysCreationDate.getTime());
		else
			this.sysCreationDate = null;
	}

	/**
	 * Gets the sys update date.
	 * 
	 * @return the sys update date
	 */
	public Timestamp getSysUpdateDate() {
		// Fix Security Violation #2 Malicious code vulnerability - May expose
		// internal representation
		// by returning reference to mutable object
		// - MK5569 3/27/2015
		// return sysUpdateDate;
		if (sysUpdateDate != null)
			return new Timestamp(sysUpdateDate.getTime());
		else
			return null;
	}

	/**
	 * Sets the sys update date.
	 * 
	 * @param sysUpdateDate
	 *            the new sys update date
	 */
	public void setSysUpdateDate(Timestamp sysUpdateDate) {
		// Fix Security Violation #1 Malicious code vulnerability - May expose
		// internal representation
		// by incorporating reference to mutable object
		// - MK5569 3/27/2015
		if (sysUpdateDate != null)
			this.sysUpdateDate = new Timestamp(sysUpdateDate.getTime());
		else
			this.sysUpdateDate = null;
	}

	/**
	 * Gets the transaction name.
	 * 
	 * @return the transaction name
	 */
	public String getTransactionName() {
		return transactionName;
	}

	/**
	 * Sets the transaction name.
	 * 
	 * @param transactionName
	 *            the new transaction name
	 */
	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}

	/**
	 * Gets the source app id.
	 * 
	 * @return the source app id
	 */
	public String getSourceAppId() {
		return sourceAppId;
	}

	/**
	 * Sets the source app id.
	 * 
	 * @param sourceAppId
	 *            the new source app id
	 */
	public void setSourceAppId(String sourceAppId) {
		this.sourceAppId = sourceAppId;
	}

	/**
	 * Gets the trans start time.
	 * 
	 * @return the trans start time
	 */
	public Timestamp getTransStartTime() {
		// Fix Security Violation #2 Malicious code vulnerability - May expose
		// internal representation
		// by returning reference to mutable object
		// - MK5569 3/27/2015
		// return transStartTime;
		if (transStartTime != null)
			return new Timestamp(transStartTime.getTime());
		else
			return null;
	}

	/**
	 * Sets the trans start time.
	 * 
	 * @param transStartTime
	 *            the new trans start time
	 */
	public void setTransStartTime(Timestamp transStartTime) {
		// Fix Security Violation #1 Malicious code vulnerability - May expose
		// internal representation
		// by incorporating reference to mutable object
		// - MK5569 3/27/2015
		if (transStartTime != null)
			this.transStartTime = new Timestamp(transStartTime.getTime());
		else
			this.transStartTime = null;
	}

	/**
	 * Gets the trans end time.
	 * 
	 * @return the trans end time
	 */
	public Timestamp getTransEndTime() {
		// Fix Security Violation #2 Malicious code vulnerability - May expose
		// internal representation
		// by returning reference to mutable object
		// - MK5569 3/27/2015
		// return transEndTime;
		if (transEndTime != null)
			return new Timestamp(transEndTime.getTime());
		else
			return null;
	}

	/**
	 * Sets the trans end time.
	 * 
	 * @param transEndTime
	 *            the new trans end time
	 */
	public void setTransEndTime(Timestamp transEndTime) {
		// Fix Security Violation #1 Malicious code vulnerability - May expose
		// internal representation
		// by incorporating reference to mutable object
		// - MK5569 3/27/2015
		if (transEndTime != null)
			this.transEndTime = new Timestamp(transEndTime.getTime());
		else
			this.transEndTime = null;
	}

	/**
	 * Gets the trans status.
	 * 
	 * @return the trans status
	 */
	public String getTransStatus() {
		return transStatus;
	}

	/**
	 * Sets the trans status.
	 * 
	 * @param transStatus
	 *            the new trans status
	 */
	public void setTransStatus(String transStatus) {
		this.transStatus = transStatus;
	}

	/**
	 * Gets the last event id.
	 * 
	 * @return the last event id
	 */
	public Long getLastEventId() {
		return lastEventId;
	}

	/**
	 * Sets the last event id.
	 * 
	 * @param lastEventId
	 *            the new last event id
	 */
	public void setLastEventId(Long lastEventId) {
		this.lastEventId = lastEventId;
	}

	/**
	 * Gets the last event name.
	 * 
	 * @return the last event name
	 */
	public String getLastEventName() {
		return lastEventName;
	}

	/**
	 * Sets the last event name.
	 * 
	 * @param lastEventName
	 *            the new last event name
	 */
	public void setLastEventName(String lastEventName) {
		this.lastEventName = lastEventName;
	}

	/**
	 * Gets the last event end time.
	 * 
	 * @return the last event end time
	 */
	public Timestamp getLastEventEndTime() {
		// Fix Security Violation #2 Malicious code vulnerability - May expose
		// internal representation
		// by returning reference to mutable object
		// - MK5569 3/27/2015
		// return lastEventEndTime;
		if (lastEventEndTime != null)
			return new Timestamp(lastEventEndTime.getTime());
		else
			return null;
	}

	/**
	 * Sets the last event end time.
	 * 
	 * @param lastEventEndTime
	 *            the new last event end time
	 */
	public void setLastEventEndTime(Timestamp lastEventEndTime) {
		// Fix Security Violation #1 Malicious code vulnerability - May expose
		// internal representation
		// by incorporating reference to mutable object
		// - MK5569 3/27/2015
		if (lastEventEndTime != null)
			this.lastEventEndTime = new Timestamp(lastEventEndTime.getTime());
		else
			this.lastEventEndTime = null;
	}

	/**
	 * Gets the last event status.
	 * 
	 * @return the last event status
	 */
	public String getLastEventStatus() {
		return lastEventStatus;
	}

	/**
	 * Sets the last event status.
	 * 
	 * @param lastEventStatus
	 *            the new last event status
	 */
	public void setLastEventStatus(String lastEventStatus) {
		this.lastEventStatus = lastEventStatus;
	}

	/**
	 * Gets the env name.
	 * 
	 * @return the env name
	 */
	public String getEnvName() {
		return envName;
	}

	/**
	 * Sets the env name.
	 * 
	 * @param envName
	 *            the new env name
	 */
	public void setEnvName(String envName) {
		this.envName = envName;
	}

	/**
	 * @return the csiConversationId
	 */
	public String getCsiConversationId() {
		return csiConversationId;
	}

	/**
	 * @param csiConversationId
	 *            the csiConversationId to set
	 */
	public void setCsiConversationId(String csiConversationId) {
		this.csiConversationId = csiConversationId;
	}

	/**
	 * @return the csiToolkitVersion
	 */
	public String getCsiToolkitVersion() {
		return csiToolkitVersion;
	}

	/**
	 * @param csiToolkitVersion
	 *            the csiToolkitVersion to set
	 */
	public void setCsiToolkitVersion(String csiToolkitVersion) {
		this.csiToolkitVersion = csiToolkitVersion;
	}

	/**
	 * Gets the serial version uid.
	 * 
	 * @return the serial version uid
	 */
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	/**
	 * Sets the transaction seq.
	 * 
	 * @param transactionSeq
	 *            the new transaction seq
	 */
	public void setTransactionSeq(int transactionSeq) {
		this.transactionSeq = transactionSeq;
	}

	/**
	 * Gets the transaction seq.
	 * 
	 * @return the transaction seq
	 */
	public int getTransactionSeq() {
		return transactionSeq;
	}

}
