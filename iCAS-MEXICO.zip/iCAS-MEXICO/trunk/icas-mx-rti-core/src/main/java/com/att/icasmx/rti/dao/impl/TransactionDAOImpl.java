package com.att.icasmx.rti.dao.impl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.att.icasmx.rti.core.data.Main;
import com.att.icasmx.rti.core.data.Transaction;
import com.att.icasmx.rti.dao.TransactionDAO;

@Repository
public class TransactionDAOImpl implements TransactionDAO {

	
	
	@Autowired
	private DataSource dataSource;
	
		
	@Override
	public Transaction saveTransaction(Transaction data) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> findAllTransactionById(String transactionId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeTransaction(String transactionId) {
		// TODO Auto-generated method stub

	}

	@Override
	public long getLastTransactionSequenceNumber(String transactionId) {
		// TODO Auto-generated method stub
		return 0;
	}

}
