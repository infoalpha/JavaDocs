package com.att.icasmx.rti.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.att.icasmx.rti.core.data.Event;

public interface EventDAO {
	
	/**
	 * Generate event id.
	 *
	 * @return the long
	 */
	public long generateEventId () ;

	
	/**
	 * Insert.
	 *
	 * @param Event
	 */
	public void saveEvent(Event data) throws DataAccessException;
	
	/**
	 * Update stepone status.
	 *
	 * @param eventData the event data
	 */
	
	public void updateSteponeStatus(Event eventData);
	
	/**
	 * Update steptwo status.
	 *
	 * @param eventData the event data
	 */
	
	public void updateSteptwoStatus(Event eventData);
	
	/**
	 * Update step one and two status.
	 *
	 * @param eventData the event data
	 */
	
	public void updateStepOneAndTwoStatus(Event eventData)		;
	
	
	/**
	 * Delete.
	 *
	 * @param eventId the event id
	 */
	
	public void removeEvent(Long eventId);
	
	/**
	 * Retrieve.
	 *
	 * @param eventId the event id
	 * @return the list
	 */
	public List<Event> retrieve(Long eventId);
	
	/**
	 * Retrieve by transaction id.
	 *
	 * @param transactionId the transaction id
	 * @return the list
	 */
	public List<Event> retrieveByTransactionId(String transactionId);
	
}
