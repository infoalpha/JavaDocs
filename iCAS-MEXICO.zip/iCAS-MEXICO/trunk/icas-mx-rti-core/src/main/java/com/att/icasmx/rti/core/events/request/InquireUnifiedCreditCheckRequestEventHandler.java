package com.att.icasmx.rti.core.events.request;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.att.icasmx.rti.constants.ICASConstants;
import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowEventHandler;
import com.att.icasmx.rti.ws.InquireUnifiedMXCreditCheckResultRequest;

/**
 * @author bb047p
 * 
 * class InquireUnifiedCreditCheckRequestEventHandler
 *
 */
public class InquireUnifiedCreditCheckRequestEventHandler implements WorkflowEventHandler {

	private static final Logger LOGGER = LogManager.getLogger();
	
		
	/**
	 * Execute IUCC request event handler
	 * @param EventManager
	 * @return String event result
	 */
	@Override
	public String execute(EventManager eventManager) {
		LOGGER.info("IUCC - RequestEventHandler called");
		String workflowResult = WorkflowConstants.WORKFLOW_RESULT_FAILURE;
		InquireUnifiedMXCreditCheckResultRequest request = (InquireUnifiedMXCreditCheckResultRequest) 
									eventManager.getWorkflowData(WorkflowConstants.INQUIRE_UNIFIED_CREDIT_CHECK_REQUEST);
		
		if (request.getDealerName() != null && request.getDealerName().startsWith(ICASConstants.XMOCK_DEALER_PATTERN))
			workflowResult = WorkflowConstants.WORKFLOW_RESULT_MOCK_GEN;
		else workflowResult = WorkflowConstants.WORKFLOW_RESULT_SUCCESS;
		
		return workflowResult;
	}

}
