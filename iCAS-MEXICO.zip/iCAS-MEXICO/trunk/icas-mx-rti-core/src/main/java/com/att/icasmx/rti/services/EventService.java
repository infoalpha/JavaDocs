package com.att.icasmx.rti.services;

import com.att.icasmx.rti.core.data.Event;
import com.att.icasmx.rti.core.data.Main;
import com.att.icasmx.rti.core.data.Transaction;
import com.att.icasmx.rti.exception.ICASException;

public interface EventService {

	/**
	 * atTransactionAndEventBegin
	 * 
	 * @throws ICASException
	 */
	public Main atWorkFlowStart(String originalTransactionID, String transactionName, String eventName,
			String transactionType);

	/**
	 * atTransactionAndEventEnd
	 * 
	 * @throws ICASException
	 */
	public void atWorkflowEnd(Event event, Transaction transaction);

	/**
	 * atEventBegin
	 * 
	 * @throws ICASException
	 */
	public void atEventBegin(Event event);

	/**
	 * atEventBegin
	 * 
	 * @throws ICASException
	 */
	public void atEventEnd(Event event);
	


}
