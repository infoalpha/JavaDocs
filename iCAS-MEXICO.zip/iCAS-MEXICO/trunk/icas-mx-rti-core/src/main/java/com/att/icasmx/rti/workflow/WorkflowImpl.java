package com.att.icasmx.rti.workflow;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

import com.att.icasmx.rti.exception.ICASException;

// TODO: Auto-generated Javadoc
/**
 * The Class WorkflowImpl.
 */


public class WorkflowImpl implements Workflow {
	
	/** The logger. */
	private static Logger  LOGGER = LogManager.getLogger(WorkflowImpl.class.getName());	
	
	/** The first event. */
	private String firstEvent;
	
	/** The event managers. */
	private HashMap eventManagers;
	
	/** The output. */
	private Object output;
	
	/** The output type. */
	private String outputType;
	

	/* (non-Javadoc)
	 * @see com.att.icas.workflow.Workflow#invokeEvent(java.lang.String, java.util.Map)
	 */
	public String invokeEvent(String eventName, Map workflowDataMap) {		
		
		String returnValue = null;		
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("invokeEvent called for: " + eventName);
		}
		// get the wrapper (an EventManager) for the event
		EventManager eventManager = (EventManager) eventManagers.get(eventName);
		if (eventManager == null) {
			throw new WorkflowException("Unknown Workflow Event: " + eventName);
		}
		
		// set the workflow data; keep it in the EventManager for convenience
		eventManager.setWorkflowDataMap(workflowDataMap);
		
		// execute the event
		try{
		returnValue = eventManager.executeEvent();
		}		
		catch(ICASException ice){
			// Extract the error code and build Error object and put in work flow data map
			
			LOGGER.error(ice.getMessage());
			ice.printStackTrace();
			//Configure return value
			returnValue = "icasError";
		}
		catch(RuntimeException re){
			LOGGER.error(re);
			re.printStackTrace();
			// set the un-handled general system error code and build Error object and insert in workflow data map
			returnValue = "icasError";
		}
		
		// determine next event based on result
		String nextEvent = eventManager.getNextEvent(returnValue);
		
		if (nextEvent == null) {
			throw new WorkflowException("Next event is NULL for Workflow event result: " + returnValue);
		}
	
		// Are we done?  Then set the output and return.
		if (nextEvent.compareTo(WorkflowConstants.WORKFLOW_END) == 0) {
			String resultKey = (String) ((WorkflowHashMap)workflowDataMap).get(WorkflowConstants.WORKFLOW_RESULT_NAME);
			output = ((WorkflowHashMap)workflowDataMap).get(resultKey);
			outputType = resultKey;
			
			// If an event has come to the end of the workflow due to an exception result, 
			// then create & throw an exception back to the workflow framework client.
			// We expect the output object in this case to extend Exception.
			if (returnValue.compareToIgnoreCase(WorkflowConstants.WORKFLOW_RESULT_EXCEPTION) == 0) {
			throw  new WorkflowException("Workflow Exception Event-related exception created.", (RuntimeException) output);
				
			}
			if (returnValue.compareToIgnoreCase(WorkflowConstants.WORKFLOW_RESULT_FAILURE) == 0) {
				throw new WorkflowException("Workflow Failure Event-related exception created.", (RuntimeException) output);
				
			}
			
			return null;
		}
		
		return nextEvent;
	}


	/* (non-Javadoc)
	 * @see com.att.icas.workflow.Workflow#getOutputType()
	 */
	public String getOutputType() {
		return outputType;
	}

	/* (non-Javadoc)
	 * @see com.att.icas.workflow.Workflow#setOutputType(java.lang.String)
	 */
	public void setOutputType(String outputType) {
		this.outputType = outputType;
	}

	/* (non-Javadoc)
	 * @see com.att.icas.workflow.Workflow#setFirstEvent(java.lang.String)
	 */
	public void setFirstEvent(String firstEvent) {
		this.firstEvent = firstEvent;
	}

	/* (non-Javadoc)
	 * @see com.att.icas.workflow.Workflow#getFirstEvent()
	 */
	public String getFirstEvent() {
		return this.firstEvent;
	}

	/* (non-Javadoc)
	 * @see com.att.icas.workflow.Workflow#setEvents(java.util.Map)
	 */
	public void setEvents(Map events) {
		this.eventManagers = (HashMap) events;
	}

	/**
	 * Sets the output.
	 *
	 * @param output the new output
	 */
	public void setOutput(Object output) {
		this.output = output;
	}
	
	/* (non-Javadoc)
	 * @see com.att.icas.workflow.Workflow#getOutput()
	 */
	public Object getOutput() {
		return output;
	}
}
