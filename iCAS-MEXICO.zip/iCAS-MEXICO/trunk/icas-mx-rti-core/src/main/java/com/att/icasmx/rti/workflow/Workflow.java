package com.att.icasmx.rti.workflow;

import java.util.Map;

/**
 * The Interface Workflow.
 */
public interface Workflow {

	/**
	 * Sets the first event.
	 *
	 * @param firstEvent
	 *            the new first event
	 */
	public void setFirstEvent(String firstEvent);

	/**
	 * Gets the first event.
	 *
	 * @return the first event
	 */
	public String getFirstEvent();

	/**
	 * Sets the events.
	 *
	 * @param events
	 *            the new events
	 */
	public void setEvents(Map events);

	/**
	 * Invoke event.
	 *
	 * @param event
	 *            the event
	 * @param data
	 *            the data
	 * @return the string
	 * @throws WorkflowException
	 *             the workflow exception
	 */
	public String invokeEvent(String event, Map data);

	/**
	 * Gets the output.
	 *
	 * @return the output
	 */
	public Object getOutput();

	/**
	 * Gets the output type.
	 *
	 * @return the output type
	 */
	public String getOutputType();

	/**
	 * Sets the output type.
	 *
	 * @param outputType
	 *            the new output type
	 */
	public void setOutputType(String outputType);

}
