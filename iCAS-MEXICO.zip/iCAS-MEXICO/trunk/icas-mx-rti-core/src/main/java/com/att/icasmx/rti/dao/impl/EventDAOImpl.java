package com.att.icasmx.rti.dao.impl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.att.icasmx.rti.core.data.Event;
import com.att.icasmx.rti.dao.EventDAO;

@Repository
public class EventDAOImpl implements EventDAO {

			
	@Autowired
	private DataSource dataSource;
		
	
	@Override
	public long generateEventId() {
		// TODO Auto-generated method stub
		return 0;
	}
	



	@Override
	public void saveEvent(Event data) {
		 NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(this.dataSource);
		 BeanPropertySqlParameterSource parameterSource = new BeanPropertySqlParameterSource(data);
		 String SQL = "INSERT INTO EVENT (EVENT_ID, TRANSACTION_ID, EVENT_NAME) VALUES (:eventID, :transactionID, :eventName)";
		 namedParameterJdbcTemplate.update(SQL,parameterSource);

	}

	@Override
	public void updateSteponeStatus(Event eventData) {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateSteptwoStatus(Event eventData) {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateStepOneAndTwoStatus(Event eventData) {
		// TODO Auto-generated method stub

	}

	@Override
	public void removeEvent(Long eventId) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Event> retrieve(Long eventId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Event> retrieveByTransactionId(String transactionId) {
		// TODO Auto-generated method stub
		return null;
	}

}
