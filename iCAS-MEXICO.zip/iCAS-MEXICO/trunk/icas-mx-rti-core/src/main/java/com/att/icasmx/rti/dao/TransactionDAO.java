package com.att.icasmx.rti.dao;

import java.util.List;

import com.att.icasmx.rti.core.data.Main;
import com.att.icasmx.rti.core.data.Transaction;

public interface TransactionDAO {

	
	
	
	
	
	/**
	 * Adds the new transaction data.
	 *
	 * @param transactionId the transaction id
	 * @param transactionName the transaction name
	 * @param lastEventId the last event id
	 * @param lastEventName the last event name
	 * @param sourceAppId the source app id
	 * @param environmentName the environment name
	 * @return the icas uc transactions
	 */
	public Transaction saveTransaction(Transaction data); 
	
	/**
	 * Retrieve.
	 *
	 * @param transactionId the transaction id
	 * @return the list
	 */
	public List<Transaction> findAllTransactionById(String transactionId);
	/**
	 * Delete.
	 *
	 * @param transactionId the transaction id
	 */	
	public void removeTransaction(String transactionId);
	
	/**
	 * Gets the last transaction sequence number.
	 *
	 * @param transactionId the transaction id
	 * @return the last transaction sequence number
	 */
	public long getLastTransactionSequenceNumber(String transactionId);
	
	

}
