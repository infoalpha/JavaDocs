package com.att.icasmx.rti.core.events.request;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.workflow.WorkflowEventHandler;
import com.att.icasmx.rti.ws.InquireUnifiedMXPolicyCheckResultRequest;


/**
 * @author bb047p
 * 
 * class InquireUnifiedPolicyCheckRequestEventHandler
 *
 */
public class InquireUnifiedPolicyCheckRequestEventHandler implements WorkflowEventHandler {

	private static Logger LOGGER = LogManager.getLogger(InquireUnifiedPolicyCheckRequestEventHandler.class.getName());
	

	/**
	 * Execute IUPC request event handler
	 * @param EventManager
	 * @return String event result
	 */
	@Override
	public String execute(EventManager eventManager) {
		LOGGER.info("IUPC - RequestEventHandler");
		String workflowResult = WorkflowConstants.WORKFLOW_RESULT_FAILURE;
		InquireUnifiedMXPolicyCheckResultRequest request = (InquireUnifiedMXPolicyCheckResultRequest) 
					eventManager.getWorkflowData(WorkflowConstants.INQUIRE_UNIFIED_POLICY_CHECK_REQUEST);
		
		if (request.getDealerName() != null && request.getDealerName().startsWith("XMOCK-"))
			workflowResult = WorkflowConstants.WORKFLOW_RESULT_MOCK_GEN;
		else workflowResult = WorkflowConstants.WORKFLOW_RESULT_SUCCESS;
		
		return workflowResult;
	}

}
