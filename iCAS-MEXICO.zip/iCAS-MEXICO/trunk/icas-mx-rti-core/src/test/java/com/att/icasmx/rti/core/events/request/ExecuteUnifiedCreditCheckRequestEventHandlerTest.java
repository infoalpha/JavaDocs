/**
 * 
 */
package com.att.icasmx.rti.core.events.request;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.att.icasmx.rti.workflow.EventManager;
import com.att.icasmx.rti.workflow.WorkflowConstants;
import com.att.icasmx.rti.ws.ExecuteUnifiedMXCreditCheckRequest;

/**
 * @author vk4235 Class ExecuteUnifiedCreditCheckRequestEventHandlerTest
 */
public class ExecuteUnifiedCreditCheckRequestEventHandlerTest {

		
	@Mock
	EventManager eventManager;
	@InjectMocks
	ExecuteUnifiedCreditCheckRequestEventHandler checkRequestEventHandler;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);

	}

	/**
	 * Test method for
	 * {@link com.att.icasmx.rti.core.events.request.ExecuteUnifiedCreditCheckRequestEventHandler#execute(com.att.icasmx.rti.workflow.EventManager)}
	 * .
	 */
	@Test
	public void testExecute() {
				
		ExecuteUnifiedMXCreditCheckRequest dummyObj = new ExecuteUnifiedMXCreditCheckRequest();
		dummyObj.setDealerName("XROCK-TEST");

		assertEquals(
				"ExecuteUnifiedCreditCheckRequestEventHandlerTest method Execute successful",
				WorkflowConstants.WORKFLOW_RESULT_SUCCESS,
				"success");
	}

}
