(function () {
  'use strict';

  angular.module('icasMXUIApp.controllers').controller("AppSearchListingCtrl", AppSearchListingCtrl);

  function AppSearchListingCtrl($state, $scope, appSearchService) {

    var vm = this
    this.goBack = goBack;
    this.showDetails = showDetails;

    // Pagination Settings
    vm.filteredTodos = [];
    vm.currentPage = 1;
    vm.itemsPerPage = 10;
    vm.maxSize = 5; //Number of pager buttons to show

    function goBack() {
      $state.go('main.searchApplication');
    }

    // show search details page
    function showDetails(id) {
      var data = {
        selectedId: id,
        currentPage: vm.currentPage
      }
      appSearchService.setAppSearchResultData(data);
      $state.go('main.appSrchDetails');
    }

    // Restore current page on returning from details page
    $scope.$on('$stateChangeSuccess',
      function (event, toState, toParams, fromState, fromParams) {
        if (fromState.name === "main.appSrchDetails") {
          var data = appSearchService.getAppSearchResultData();
          vm.currentPage = data.currentPage;
        }
      })

    var initialize = function () {
      // get search results from service      
      vm.searchListing = appSearchService.getAppSearchResults();
      if (vm.searchListing === '') {
        $state.go('main.searchApplication');
      }
    }

    initialize();

  }

  AppSearchListingCtrl.$inject = ["$state", "$scope", "appSearchService"];
})();
