(function () {
  'use strict';

  angular.module('icasMXUIApp.controllers', []).controller("MainPageCtrl", MainPageCtrl);

  function MainPageCtrl($state, $scope, $rootScope, $window, mainPageService) {

    var vm = this;
    this.userLogout = userLogout;

    function userLogout() {

      // In real time we will call restful service call (server)
      mainPageService.logout($rootScope.loggedInUser.attuid)
        .then(function (response) {
          sessionStorage.removeItem('loggedInUser');
          sessionStorage.setItem("loggedOut", "true");
          sessionStorage.setItem("loggedOutUser", $rootScope.loggedInUser.attuid);
          $window.location.href = '/';
        }, function (error) {
          // error occurred while logging out user in server
        });

    }

  }
  MainPageCtrl.$inject = ["$state", "$scope", "$rootScope", "$window", "mainPageService"];
})();
