'use strict';

var icasMXUIApp = angular.module('icasMXUIApp', ['ui.router', 'ngAnimate', 'ui.bootstrap', 'icasMXUIApp.controllers', 'icasMXUIApp.services', 'angular-jquery-validate', 'ncy-angular-breadcrumb']);

icasMXUIApp.config(config);

function config($stateProvider, $urlRouterProvider, $jqueryValidateProvider, uibDatepickerConfig, uibDatepickerPopupConfig) {

  //  var appContextPath = '/crsm';

  // use the HTML5 History API
  // $locationProvider.html5Mode(true)

  // Use $urlRouterProvider to configure any redirects (when) and invalid urls
  // (otherwise).
  $urlRouterProvider

  // The 'when' method says if the url is ever the 1st param, then redirect to
  // the 2nd param
    .when('/home.html', '/')

  // If the url is ever invalid, e.g. '/asdf', then redirect to '/' aka the
  // home state
  .otherwise('/');

  /* $stateProvider.state('login', {
    url: "/",
    templateUrl: 'partials/login/login.html',
    controller: 'LoginCtrl',
    controllerAs: 'login',
    data: {
      pageTitle: 'Login to iCAS Mexico'
    }
  }); */

  $stateProvider.state('main', {
    url: "",
    templateUrl: 'partials/main.html',
    controller: 'MainPageCtrl',
    controllerAs: 'mainPage',
    abstract: true
  });

  $stateProvider.state('main.home', {
    url: "/",
    templateUrl: 'partials/welcomePage.html',
    data: {
      pageTitle: 'Welcome to iCAS Mexico'
    },
    ncyBreadcrumb: {
      label: 'Home'
    }
  });

  $stateProvider.state('main.newCreditApp', {
    url: "/newCreditApp",
    templateUrl: 'partials/newApp/newCreditApplication.html',
    data: {
      pageTitle: 'New Credit Application'
    },
    ncyBreadcrumb: {
      label: 'New Credit Application',
      parent: 'main.home'
    }
  });

  $stateProvider.state('main.newCreditAppResult', {
    url: "/newCreditAppResult",
    templateUrl: 'partials/newApp/newCreditAppResult.html',
    data: {
      pageTitle: 'Credit Application Result'
    },
    ncyBreadcrumb: {
      label: 'Credit Result',
      parent: 'main.home'
    }
  });

  $stateProvider.state('main.newPolicyApp', {
    url: "/newPolicyApp",
    templateUrl: 'partials/newApp/newPolicyApplication.html',
    data: {
      pageTitle: 'New Policy Application'
    },
    ncyBreadcrumb: {
      label: 'New Policy Application',
      parent: 'main.home'
    }
  });

  $stateProvider.state('main.newPolicyResult', {
    url: "/newPolicyResult",
    templateUrl: 'partials/newApp/newPolicyResult.html',
    data: {
      pageTitle: 'Credit Application Result'
    },
    ncyBreadcrumb: {
      label: 'Policy Result',
      parent: 'main.home'
    }
  });

  $stateProvider.state('main.searchApplication', {
    url: "/searchApplication",
    templateUrl: 'partials/appSearch/applicationSearch.html',
    controller: 'AppSearchCtrl',
    controllerAs: 'appSearch',
    data: {
      pageTitle: 'Application Search'
    },
    ncyBreadcrumb: {
      label: 'Application Search',
      parent: 'main.home'
    }
  });

  $stateProvider.state('main.appSrchResultList', {
    url: "/appSrchResultList",
    templateUrl: 'partials/appSearch/appSrchListPage.html',
    controller: 'AppSearchListingCtrl',
    controllerAs: 'appListing',
    data: {
      pageTitle: 'Application Search - Result Listing'
    },
    ncyBreadcrumb: {
      label: 'Application Search Results',
      parent: 'main.searchApplication'
    }
  });

  $stateProvider.state('main.appSrchDetails', {
    url: "/appSrchDetails",
    templateUrl: 'partials/appSearch/appSrchDetails.html',
    controller: 'AppSearchDetailsCtrl',
    controllerAs: 'appDetails',
    data: {
      pageTitle: 'Application Details - Credit Results'
    },
    ncyBreadcrumb: {
      label: 'Credit Result',
      parent: 'main.appSrchResultList'
    }
  });

  $stateProvider.state('main.searchAccount', {
    url: "/searchAccount",
    templateUrl: 'partials/accountSearch/accountSearch.html',
    data: {
      pageTitle: 'Account Search'
    },
    ncyBreadcrumb: {
      label: 'Account Search',
      parent: 'main.home'
    }
  });

  $stateProvider.state('main.searchWorkItem', {
    url: "/searchWorkItem",
    templateUrl: 'partials/workItem/workItemSearch.html',
    data: {
      pageTitle: 'Work Item Search'
    },
    ncyBreadcrumb: {
      label: 'Work Items Search',
      parent: 'main.home'
    }
  });

  $stateProvider.state('main.workListSrchResultList', {
    url: "/workListSrchResultList",
    templateUrl: 'partials/workItem/workListSrchListingPage.html',
    data: {
      pageTitle: 'Work Items Search - Result Listing'
    },
    ncyBreadcrumb: {
      label: 'WorkList Search Results',
      parent: 'main.searchWorkItem'
    }
  });

  $stateProvider.state('main.workItemDetails', {
    url: "/workItemDetails",
    templateUrl: 'partials/workItem/workItemDetails.html',
    data: {
      pageTitle: 'Work Item Details'
    },
    ncyBreadcrumb: {
      label: 'Work Item Details',
      parent: 'main.workListSrchResultList'
    }
  });

  // Unlock Appliation
  $stateProvider.state('main.unlockAppSearch', {
    url: "/unlockAppSearch",
    templateUrl: 'partials/workItem/unlockAppSearch.html',
    data: {
      pageTitle: 'Unlock Work Item'
    },
    ncyBreadcrumb: {
      label: 'Unlock Work Item',
      parent: 'main.home'
    }
  });

  // Admin - User Maintenance
  $stateProvider.state('main.userMaintHome', {
    url: "/userMaintHome",
    templateUrl: 'partials/admin/user-maintainance/userMaintHome.html',
    controller: 'userMaintHomeCtrl',
    controllerAs: 'userMaintHome',
    data: {
      pageTitle: 'Adminstration - User Maintainance Home'
    },
    ncyBreadcrumb: {
      label: 'User Maintenance',
      parent: 'main.home'
    }
  });

  $stateProvider.state('main.createNewUser', {
    url: "/createNewUser",
    templateUrl: 'partials/admin/user-maintainance/createUser.html',
    controller: 'CreateUserCtrl',
    controllerAs: 'createUser',
    data: {
      pageTitle: 'Adminstration - Add New User'
    },
    ncyBreadcrumb: {
      label: 'Create User',
      parent: 'main.userMaintHome'
    }
  });

  $stateProvider.state('main.updateUser', {
    url: "/updateUser",
    templateUrl: 'partials/admin/user-maintainance/updateUser.html',
    controller: 'updateUserCtrl',
    controllerAs: 'updateUser',
    data: {
      pageTitle: 'Adminstration - Update Existing User'
    },
    ncyBreadcrumb: {
      label: 'Update User',
      parent: 'main.userMaintHome'
    }
  });

  $stateProvider.state('main.usersList', {
    url: "/usersList",
    templateUrl: 'partials/admin/user-maintainance/userListing.html',
    controller: 'userListingCtrl',
    controllerAs: 'userListing',
    data: {
      pageTitle: 'Adminstration - User Listing'

    },
    ncyBreadcrumb: {
      label: 'Users',
      parent: 'main.userMaintHome'
    }
  });
    
   



  // For any unmatched url, send to /home
  // $urlRouterProvider.otherwise("/home")

  // jQuery Validation Config
  $jqueryValidateProvider
    .setDefaults({
      errorPlacement: function (error, element) {

      },
      errorClass: 'validation-error',
      showErrors: function (errorMap, errorList) {
        this.defaultShowErrors();

        // destroy tooltips on valid elements
        $("." + this.settings.validClass).tooltip("destroy");
        $("." + this.settings.validClass).removeAttr("data-original-title");

        // add/update tooltips
        for (var i = 0; i < errorList.length; i++) {
          var error = errorList[i];

          if ($("#" + error.element.id).attr("data-original-title")) {
            if (!($("#" + error.element.id).attr("data-original-title") == error.message)) {
              $("#" + error.element.id).attr("data-original-title", error.message).tooltip("show");
            }
          } else {
            $("#" + error.element.id).tooltip({
              trigger: "manual",
              placement: "bottom",
              template: '<div class="tooltip tooltip-error" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>'
            }).attr("data-original-title", error.message).tooltip('show');
          }
        }
      },
      unhighlight: function (element, errorClass, validClass) {
        $(element).tooltip("destroy");
        $(element).removeAttr("data-original-title");
        if (element.type === "radio") {
          this.findByName(element.name).removeClass(errorClass).addClass(validClass);
        } else {
          $(element).removeClass(errorClass).addClass(validClass);
        }
      }
    });

  $jqueryValidateProvider.addMethod("alphaSpaces", function (value, element) {
    return this.optional(element) || /^([a-zа-яàáâãäåæçèéêëœìíïîðòóôõöøùúûñüýÿßÞďđ\s])+$/i
      .test(value);
  }, "May only contain letters and spaces.");

  $jqueryValidateProvider.addMethod("dateMx", function (value, element) {
    return this.optional(element) || /^(0[1-9]|[12][0-9]|3[01])(0[1-9]|1[012])(19|20)\d\d$/
      .test(value);
  }, "Must be a valid date format ddmmyyyy.");

  $jqueryValidateProvider.addMethod("startsWithAlphabet", function (value,
    element) {
    return /^[A-Za-z][A-Za-z0-9]*$/.test(value);
  }, "Start with Alphabet and no Spaces allowed");

  // Added below method as firefox was not working with used same property
  // from additional methods min js
  $jqueryValidateProvider.addMethod("alphaNumeric", function (value, element) {
    return /^[a-zA-Z0-9]*$/.test(value);
  }, "Letters and numbers only please");

  /* UI Datepicker Global configuration */
  uibDatepickerConfig.showWeeks = false;
  uibDatepickerPopupConfig.showButtonBar = true;
  uibDatepickerPopupConfig.closeText = 'Close';
  uibDatepickerPopupConfig.datepickerPopupTemplateUrl = 'template/datepicker/customPopup.html';
};

/*
 * icasMXUIApp.run(['$location', '$rootScope', function ($location, $rootScope) {
 *
 * $rootScope.$on('$routeChangeSuccess', function (event, current, previous) {
 * if (current.$$route != undefined) { $rootScope.title = current.$$route.title; }
 * });
 *
 * }]);
 */

/*
icasMXUIApp.run(['$rootScope', '$state', '$stateParams',
		function ($rootScope, $state, $stateParams) {

    // It's very handy to add references to $state and $stateParams to
    // the $rootScope
    // so that you can access them from any scope within your
    // applications.For example,
    // <li ng-class="{ active: $state.includes('contacts.list') }"> will
    // set the <li>
    // to active whenever 'contacts.list' or one of its decendents is
    // active.
    $rootScope.$state = $state;
    $rootScope.$stateParams = $stateParams;
		}]);*/

icasMXUIApp.directive('updateTitle', function ($rootScope) {
  return {
    link: function (scope, element) {

      var listener = function (event, toState, toParams, fromState,
        fromParams) {
        var title = 'Welcome to iCAS Mexico';
        if (toState.data && toState.data.pageTitle)
          title = toState.data.pageTitle;
        element.text(title)
      };

      $rootScope.$on('$stateChangeStart', listener);
    }
  }
});

/* Config Factory for all global configurations */
icasMXUIApp.factory('configFactory', function () {
  return {
    // UI Datepicker Config
    datePicker: (function () {
      var method = {};

      method.instances = [];

      method.open = function ($event, instance) {
        $event.preventDefault();
        $event.stopPropagation();
        method.instances[instance] = true;
      };

      method.format = 'ddMMyyyy';

      return method;
    }())

  }
});

/* Custom filter for pagination in ng-repeat */
icasMXUIApp.filter('pagination', function () {
  return function (input, currentPage, itemsPerPage) {
    if (angular.isArray(input)) {
      var start = (currentPage - 1) * itemsPerPage;
      var end = currentPage * itemsPerPage;
      return input.slice(start, end);
    }
  };
});

/* Angular-breadcrumb setup */
icasMXUIApp.run(function ($rootScope, $state, $breadcrumb) {
  $rootScope.isActive = function (stateName) {
    return $state.includes(stateName);
  }
});

/* Custom template for datepicker popup */
icasMXUIApp.run(["$templateCache", function ($templateCache) {
  $templateCache.put("template/datepicker/customPopup.html",
    "<ul class=\"dropdown-menu\" dropdown-nested ng-if=\"isOpen\" style=\"display: block\" ng-style=\"{top: position.top+'px', left: position.left+'px'}\" ng-keydown=\"keydown($event)\" ng-click=\"$event.stopPropagation()\">\n" +
    "	<li ng-transclude></li>\n" +
    "	<li ng-if=\"showButtonBar\" style=\"padding:4px 0px\">\n" +
    "		<span class=\"btn-group pull-left\">\n" +
    "			<button type=\"button\" class=\"btn btn-sm btn-info\" ng-click=\"select('today')\" ng-disabled=\"isDisabled('today')\">{{ getText('current') }}</button>\n" +
    "		</span>\n" +
    "		<button type=\"button\" class=\"btn btn-sm btn-success pull-right\" ng-click=\"close()\">{{ getText('close') }}</button>\n" +
    "	</li>\n" +
    "</ul>\n" +
    "");
}]);

/* Get logged in user from sessionStorage and set HTTP headers for all requests*/
icasMXUIApp.run(function ($rootScope, $http, $window) {
  var loggedInUser = JSON.parse($window.sessionStorage.getItem("loggedInUser"));
  if (!!loggedInUser) {
    $rootScope.loggedInUser = loggedInUser.loginUser;
    $http.defaults.headers.common.sessionId = loggedInUser.sessionId;
  } else {
    $window.location.href = '/index.html';
  }
});

icasMXUIApp.config(function ($logProvider) {
  $logProvider.debugEnabled(false);
});
