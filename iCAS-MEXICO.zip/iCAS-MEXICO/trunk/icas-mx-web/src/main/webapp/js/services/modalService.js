/**
 * Service for Managing Modals
 *

 USAGE : 
 
 SIMPLE Alert popUp
 ---------------------------
 modalService.createModal({
    type : 'alert',
    context: 'success' // 'success', 'info', 'warning', 'danger'
    message :  "WOKING AS EXPECTED"
 });
 
 SIMPLE Confirm popUp
 ---------------------------
 modalService.createModal({
    type : 'confirm',
    context: 'success' // '', 'primary', 'success', 'info', 'warning', 'danger'
    title: 'Success',
    message :  "WOKING AS EXPECTED"
 }); 
 
 SIMPLE Dynamic PopUp
 -----------------------
 modalService.createModal({
    type : 'dynamic',
    templateUrl : 'partials/customModal',
    controller: 'myController',
    size: 'lg',
    scopeData:vm.items
 }); 
 
 **/

(function () {
  'use strict';
  angular.module('icasMXUIApp.services', []).service("modalService", modalService);

  function modalService($q, $uibModal) {

    this.createModal = createModal;

    function createModal(options) {

      var defer = $q.defer();
      options.type = options.type || 'dynamic';
      options.controller = options.controller || 'ModalInstanceCtrl';
      options.title = options.title || '';
      options.message = options.message || '';
      options.backdrop = options.backdrop || 'static';
      options.scopeData = options.scopeData || {};
      options.resolve = {
        options: function () {
          return options;
        }
      };
      if (options.type === 'alert') {
        options.autoClose = true;
        options.autoCloseDelay = options.autoCloseDelay || 2000;
        options.context = options.context || 'info';
        options.windowClass = 'alertModal';
        options.templateUrl = 'partials/modal/alertModal.html';
      } else if (options.type === 'confirm') {
        options.context = options.context || '';
        options.windowClass = 'confirmModal';
        options.needOKButton = options.needOKButton || true;
        options.needCancelButton = options.needCancelButton || false;
        options.okButtonText = options.okButtonText || 'OK';
        options.cancelButtonText = options.cancelButtonText || 'Cancel';
        options.templateUrl = 'partials/modal/confirmModal.html';
      }

      $uibModal.open(options).result.then(function (scopeData) {
        defer.resolve(scopeData);
      }, function (scopeData) {
        defer.reject(scopeData);
      });

      return defer.promise;
    }

  }
  modalService.$inject = ["$q", "$uibModal"];

})();
