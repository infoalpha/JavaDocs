(function () {
  'use strict';

  angular.module('icasMXUIApp.services').service("appSearchService", appSearchService);

  function appSearchService($http, $log) {

    var vm = this;

    var searchData = '';
    var appSearchResults = '';
    var appSearchResultData = '';

    // Application Search Parameters
    vm.setSearchData = function (data) {
      searchData = data;
    }

    vm.getSearchData = function () {
      return searchData;
    }

    // Application Search Results
    vm.setAppSearchResults = function (data) {
      appSearchResults = data;
    }

    vm.getAppSearchResults = function () {
      return appSearchResults;
    }

    // Application Search Results - Selected ID & Page Number
    vm.setAppSearchResultData = function (data) {
      appSearchResultData = data;
    }

    vm.getAppSearchResultData = function () {
      return appSearchResultData;
    }

    // Get Application Search Results
    vm.getSearchListing = function (data) {
      var promise = $http({
        method: 'GET',
        //url: '/data/sample/appSearchListing_1result.json' // in case of 1 result only
        url: '/data/sample/appSearchListing.json'
      }).then(function (response) {
        // this callback will be called asynchronously
        // when the response is available
        return response.data;
      }, function (httpError) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
        throw httpError.status + " : " + httpError.data;
      });

      return promise;
    }

  }

  appSearchService.$inject = ["$http", "$log"];

})();
