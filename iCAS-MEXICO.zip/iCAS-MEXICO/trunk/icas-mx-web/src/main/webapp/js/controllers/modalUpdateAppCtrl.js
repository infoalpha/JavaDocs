(function () {
  'use strict';

  angular.module('icasMXUIApp.controllers').controller("ModalUpdateAppCtrl", ModalUpdateAppCtrl);

  function ModalUpdateAppCtrl($scope, $uibModalInstance, options, configFactory, appDetailsService, modalService) {

    $scope.scopeData = angular.copy(options.scopeData);

    $scope.datePicker = configFactory.datePicker;

    $scope.sameAsServAddrChkBox = false;

    $scope.appUpdate = {
      statusFlag: false,
      btn: "",
      orderNo: "",
      orderDueDate: "",
      appStatus: "",
      appStatusReason: "",
      contractId: ""
    }

    $scope.sameAsServAddrFn = function (checked) {
      if (checked) {
        $scope.scopeData.billingAddr = angular.copy(options.scopeData.serviceAddr);
      } else {
        $scope.scopeData.billingAddr = angular.copy(options.scopeData.billingAddr);
      }
    }

    $scope.ok = function () {
      var updatedData = {
        appUpdate: $scope.appUpdate,
        billingAddr: $scope.scopeData.billingAddr
      };
      // Service call to save the Updated Application data
      appDetailsService.updateCreditDecision(updatedData)
        .then(function (response) {
            if (response.success) {
              var title = 'Success';
              var msg = 'Application updated successfully';
              showAlertMsg('confirm', 'success', title, msg, $uibModalInstance.close);
            } else {
              var title = 'Error';
              var msg = 'An error occurred while saving the application. Please try again.';
              showAlertMsg('confirm', 'danger', title, msg);
            }
          },
          function (error) {
            // Error occurred while saving the data
            var title = 'Error';
            var msg = 'An error occurred while saving the application. Please try again.';
            showAlertMsg('confirm', 'danger', title, msg);
          });
    };

    $scope.cancel = function () {
      $uibModalInstance.dismiss('cancel');
    };

    $scope.reset = function () {
      $scope.checkbox = {
        statusFlag: false,
        sameAsServAddr: false
      }
      $scope.appUpdate = {
        btn: "",
        orderNo: "",
        orderDueDate: "",
        appStatus: "",
        appStatusReason: "",
        contractId: ""
      }
      $scope.scopeData = angular.copy(options.scopeData);
    }

    // PRIVATE FUNCTIONS

    //Show Alert Popup
    function showAlertMsg(type, context, title, message, callback) {
      modalService.createModal({
        type: type,
        context: context,
        title: title,
        message: message
      }).then(function () {
        if (callback) {
          callback();
        }
      });
    }

  }

  ModalUpdateAppCtrl.$inject = ["$scope", "$uibModalInstance", "options", "configFactory", "appDetailsService", "modalService"];
})();
