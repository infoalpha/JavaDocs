(function () {
  'use strict';

  angular.module('icasMXUILogin').controller("LoginCtrl", LoginCtrl);

  function LoginCtrl($state, $scope, $uibModal, $window) {

    var vm = this;
    this.showLoginModal = showLoginModal;
    this.showSignupModal = showSignupModal;


    function showLoginModal() {
      var modalInstance = $uibModal.open({
        templateUrl: 'partials/login/modal.html',
        controller: 'LoginModalCtrl',
        controllerAs: 'loginForm'
      });

      modalInstance.result.then(function (loggedInUser) {
        // clicked ok
        $window.sessionStorage.setItem("loggedInUser", JSON.stringify(loggedInUser));
        $window.location.href = '/home.html';
      }, function () {
        // clicked cancel
        console.log('Modal dismissed at: ' + new Date());
      });
    }

    function showSignupModal() {
      var modalInstance = $uibModal.open({
        templateUrl: 'partials/login/firstTimeUserModal.html',
        controller: 'FirstTimeUserModalCtrl',
        controllerAs: 'firstTimeUserForm'

      });

      modalInstance.result.then(function (signedUpUser) {
        // clicked ok        
        $window.location.href = '/index.html';
      }, function () {
        // clicked cancel
        console.log('Modal dismissed at: ' + new Date());
      });
    }



    var initialize = function () {
      //Check if user just logged out
      vm.userLoggedOut = $window.sessionStorage.getItem('loggedOut');
      if (vm.userLoggedOut) {
        vm.loggedOutUser = $window.sessionStorage.getItem('loggedOutUser');
        $window.sessionStorage.removeItem('loggedOutUser');
        $window.sessionStorage.removeItem('loggedOut');
      }
    }

    initialize();

  }

  LoginCtrl.$inject = ["$state", "$scope", "$uibModal", "$window"];
})();
