// $uibModalInstance represents a modal window (instance) dependency.

(function () {
    'use strict';

    angular.module('icasMXUILogin').controller("LoginModalCtrl", LoginModalCtrl);

    function LoginModalCtrl($scope, $uibModalInstance, loginService) {

        var vm = this;

        // Login Form parameter variables
        vm.loginParam = {
            'loginUserName': '',
            'loginPassword': '',

        };

        // jQuery Form Validator Rules and Messages
        this.formvalidate = {

            rules: {
                loginUserName: {
                    minlength: 6,
                    maxlength: 60,
                    startsWithAlphabet: true,
                    required: true
                },
                loginPassword: {
                    minlength: 4,
                    maxlength: 20,
                    alphaNumeric: true,
                    required: true
                },

            },
            messages: {
                loginUserName: {
                    required: "Please enter valid username",
                    minlength: "Invalid Username, Username atleast 6 characters required",
                    startsWithAlphabet: "Start with Alphabet and no spaces allowed"
                },
                loginPassword: {
                    required: "Please enter valid Password",
                    minlength: "Invalid Password, Password atleast 4 characters required",
                    alphaNumeric: "Password must be alphanumeric"
                }

            },

            validateOnInit: false,
            onkeyup: function () {

                // enable submit button only if all fields are valid
                // if ($('#loginUserNameId').valid()==true && $('#loginPasswordId').valid()==true)
                if ($('#loginUserNameId').val().length > 5 && $('#loginPasswordId').val().length > 3) {
                    if ($('#loginUserNameId').valid() && $('#loginPasswordId').valid()) {
                        $('#loginSubmit').removeAttr('disabled');
                    }
                } else {
                    $('#loginSubmit').attr('disabled', 'disabled');
                }
            }
        };

        // Submit form function
        $scope.submitForm = function () {

            if (vm.formvalidateapi.valid()) {
                var response = loginService.loginUser(vm.loginParam.loginUserName, vm.loginParam.loginPassword);

                response.success(function (data, status, headers, config) {
                    $uibModalInstance.close(data);
                });

                response.error(function (data, status, headers, config) {


                    vm.servererror = true;
                    vm.servermessageBold = "Authentication Failed!";
                    vm.servermessage = "  Entered Username & Password not valid, Please try again with valid credentials";

                });

            }
        };


        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

    }

    LoginModalCtrl.$inject = ["$scope", "$uibModalInstance", "loginService"];
})();