(function () {
    'use strict';
    angular.module('icasMXUIApp').service("createUserService", createUserService);

    function createUserService($http, $log, $q, $filter, $timeout, $rootScope) {
        var vm = this;
        /*  vm.saveUser = function (reqData) {
               // Use below for real time usage
               // return $http.post("//d1c1m119.vci.att.com:17170/icasweb-mx/api/admin/userMaintenance/addNewUser ".then( handleSuccess, handleError(Error) );
              $http({
               url: 'http://d1c1m119.vci.att.com:17170/icasweb-mx/api/admin/userMaintenance/addNewUser',
               method: "POST",
               data: reqData,
               headers: {'Content-Type': 'application/x-www-form-urlencoded'}
           }).success(function (data, status, headers, config) {
                  return data;
               }).error(function (data, status, headers, config) {
                   return data;
               });
               
           }*/
        vm.saveUser = function (requestData, callback) {
            var response = $http.post('http://d1c1m119.vci.att.com:17170/icasweb-mx/api/admin/userMaintenance/addNewUser', requestData);

            return response;
            /*  res.success(function(data, status, headers, config) {
                    alert( "success message: " + JSON.stringify({data: data}));
                  alert(status);
              });
              res.error(function(data, status, headers, config) {
              res.error(function(data, status, headers, config) {
                  alert( "failure message: " + JSON.stringify({data: data}));
              });*/
            /*    
                 $http.post('http://d1c1m119.vci.att.com:17170/icasweb-mx/api/admin/userMaintenance/addNewUser', requestData)
            .then(function (response) {
                 callback(response);
             });
             */
            /*      $http({
                      url: 'http://d1c1m119.vci.att.com:17170/icasweb-mx/api/admin/userMaintenance/addNewUser',
                      method: "POST",
                      data: requestData,
                  }).then(function (response) {
                      alert(response.success);
                      callback(response);
                  });*/
        }
    }
    createUserService.$inject = ["$http", "$log", "$q", "$filter", "$timeout", "$rootScope"];

})();