(function () {
  'use strict';
  angular.module('icasMXUIApp').service("updateUserService", updateUserService);

  function updateUserService($http) {

    var vm = this;

    vm.updateUser = function (attuid) {
      var url = "http://d1c1m119.vci.att.com:17170/icasweb-mx/api/admin/userMaintenance/" + attuid;
      var response = $http.get(url);
      return response;
    };

    // Get User History
    vm.getUserHistory = function (attuid) {
      var promise = $http({
        method: 'GET',
        url: 'http://d1c1m119.vci.att.com:17170/icasweb-mx/api/admin/userMaintenance/getUserHistory/' + attuid
      }).then(function (response) {
        return response.data;
      }, function (httpError) {
        throw httpError.status + " : " + httpError.data;
      });
      return promise;
    }

  }
  updateUserService.$inject = ["$http"];

})();
