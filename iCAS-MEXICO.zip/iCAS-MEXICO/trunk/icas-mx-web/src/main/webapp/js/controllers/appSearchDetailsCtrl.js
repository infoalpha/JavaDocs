(function () {
  'use strict';

  angular.module('icasMXUIApp.controllers').controller("AppSearchDetailsCtrl", AppSearchDetailsCtrl);

  function AppSearchDetailsCtrl($state, $scope, modalService, appSearchService, appDetailsService) {

    var vm = this;
    this.selectPolicy = selectPolicy;
    this.showUpdateAppModal = showUpdateAppModal;
    this.showDocHistoryModal = showDocHistoryModal;
    this.showUpdatePolicyModal = showUpdatePolicyModal;
    this.tabChange = tabChange;

    vm.selectedPolicy = [];

    vm.tabs = [{
        title: 'Credit Decision',
        template: 'partials/appSearch/tab/creditDecision.html'
      },
      {
        title: 'Black List',
        template: 'partials/appSearch/tab/blackList.html'
      },
      {
        title: 'Notes',
        template: 'partials/appSearch/tab/notes.html'
      },
      {
        title: 'Matched Accounts',
        template: 'partials/appSearch/tab/matchedAccounts.html'
      },
      {
        title: 'View Policy',
        template: 'partials/appSearch/tab/viewPolicy.html'
      },
      {
        title: 'View / Add Docs',
        template: 'partials/appSearch/tab/viewAddDocs.html'
      },
      {
        title: 'System Performance',
        template: 'partials/appSearch/tab/systemPerformance.html'
      }];


    function selectPolicy(element) {
      vm.selectedPolicy[element] = !vm.selectedPolicy[element];
    }

    function showUpdateAppModal() {

      modalService.createModal({
        type: 'dynamic',
        templateUrl: 'partials/appSearch/modal/updateApp.html',
        controller: 'ModalUpdateAppCtrl',
        size: 'lg',
        scopeData: vm.creditDec
      }).then(function (response) {
        // Update Credit Decision tab
        getCreditDecision();
      });

    }

    function showDocHistoryModal() {

      modalService.createModal({
        type: 'dynamic',
        templateUrl: 'partials/appSearch/modal/docHistory.html',
        size: 'lg'
      });

    }

    function showUpdatePolicyModal() {

      modalService.createModal({
        type: 'dynamic',
        templateUrl: 'partials/appSearch/modal/updatePolicy.html',
      });

    }

    function tabChange(activeTab) {
      if (activeTab === 'Credit Decision') {
        if (!vm.creditDec)
          getCreditDecision();
      } else if (activeTab === 'Black List') {
        if (!vm.blackList)
          getBlackList();
      } else if (activeTab === 'Notes') {
        if (!vm.notes)
          getNotes();
      }
    }

    // PRIVATE FUNCTIONS

    //Show Alert Popup
    function showAlertMsg(type, context, title, message, callback) {
      modalService.createModal({
        type: type,
        context: context,
        title: title,
        message: message
      }).then(function () {
        if (callback) {
          callback();
        }
      });
    }

    //get application credit decision from service
    function getCreditDecision() {
      appDetailsService.appCreditDecision(vm.selectedApp)
        .then(function (response) {
            vm.creditDec = response;
          },
          function (error) {
            // Error occurred while retrieving data
          });
    }

    //get application credit decision from service
    function getBlackList() {
      appDetailsService.appBlackList(vm.selectedApp)
        .then(function (response) {
            vm.blackList = response;
            //Dynamically set column width depending on the response
            var length = Object.keys(response).length;
            if (length == 3) {
              vm.blackList.columnWidth = {
                'row1': 'col-md-4',
                'row2': 'col-md-4'
              }
            } else if (length == 5) {
              vm.blackList.columnWidth = {
                'row1': 'col-md-4',
                'row2': 'col-md-6'
              }
            } else {
              vm.blackList.columnWidth = {
                'row1': 'col-md-6',
                'row2': 'col-md-6'
              }
            }
          },
          function (error) {
            // Error occurred while retrieving data
          });
    }

    //get application notes from service
    function getNotes() {
      appDetailsService.appNotes(vm.selectedApp)
        .then(function (response) {
            vm.notes = response;
          },
          function (error) {
            // Error occurred while retrieving data
          });
    }

    // load/set initial data in the view
    var initialize = function () {
      // get selected application id from service
      var data = appSearchService.getAppSearchResultData();
      if (data === '') {
        // $state.go('main.searchApplication');
      }
      vm.selectedApp = data.selectedId;
      // get application reference information from service
      appDetailsService.appRefInfo(vm.selectedApp)
        .then(function (response) {
            vm.refInfo = response;
          },
          function (error) {
            // Error occurred while retrieving data
          });
      vm.selectedTab = vm.tabs[0];

    }

    initialize();

  }

  AppSearchDetailsCtrl.$inject = ["$state", "$scope", "modalService", "appSearchService", "appDetailsService"];
})();
