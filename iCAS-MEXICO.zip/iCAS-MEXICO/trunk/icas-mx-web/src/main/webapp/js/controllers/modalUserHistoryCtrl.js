(function () {
  'use strict';

  angular.module('icasMXUIApp.controllers').controller("ModalUserHistory", ModalUserHistory);

  function ModalUserHistory($scope, $uibModalInstance, options, updateUserService) {

    $scope.scopeData = angular.copy(options.scopeData);

    $scope.ok = function () {
      $uibModalInstance.dismiss('ok');
    };

    $scope.cancel = function () {
      $uibModalInstance.dismiss('cancel');
    };

    var initialize = function () {
      updateUserService.getUserHistory($scope.scopeData)
        .then(function (response) {
          $scope.userHistory = response;
        }, function (error) {
          // Error occurred while retrieving data
        })
    }

    initialize();
  }

  ModalUserHistory.$inject = ["$scope", "$uibModalInstance", "options", "updateUserService"];
})();
