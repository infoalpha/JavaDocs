'use strict';

var icasMXUIApp = angular.module('icasMXUILogin', ['ui.router', 'ngAnimate', 'ui.bootstrap', 'angular-jquery-validate']);

icasMXUIApp.config(config);

function config($stateProvider, $urlRouterProvider, $jqueryValidateProvider) {

  $urlRouterProvider

  // The 'when' method says if the url is ever the 1st param, then redirect to
  // the 2nd param
    .when('/index.html', '/')

  // If the url is ever invalid, e.g. '/asdf', then redirect to '/' aka the
  // home state
  .otherwise('/');

  $stateProvider.state('login', {
    url: "/",
    templateUrl: 'partials/login/login.html',
    controller: 'LoginCtrl',
    controllerAs: 'login',
    data: {
      pageTitle: 'Login to iCAS Mexico'
    }
  });


  // jQuery Validation Config
  $jqueryValidateProvider
    .setDefaults({
      errorPlacement: function (error, element) {

      },
      errorClass: 'validation-error',
      showErrors: function (errorMap, errorList) {
        this.defaultShowErrors();

        // destroy tooltips on valid elements
        $("." + this.settings.validClass).tooltip("destroy");
        $("." + this.settings.validClass).removeAttr("data-original-title");

        // add/update tooltips
        for (var i = 0; i < errorList.length; i++) {
          var error = errorList[i];

          if ($("#" + error.element.id).attr("data-original-title")) {
            if (!($("#" + error.element.id).attr("data-original-title") == error.message)) {
              $("#" + error.element.id).attr("data-original-title", error.message).tooltip("show");
            }
          } else {
            $("#" + error.element.id).tooltip({
              trigger: "manual",
              placement: "bottom",
              template: '<div class="tooltip tooltip-error" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>'
            }).attr("data-original-title", error.message).tooltip('show');
          }
        }
      },
      unhighlight: function (element, errorClass, validClass) {
        $(element).tooltip("destroy");
        $(element).removeAttr("data-original-title");
        if (element.type === "radio") {
          this.findByName(element.name).removeClass(errorClass).addClass(validClass);
        } else {
          $(element).removeClass(errorClass).addClass(validClass);
        }
      }
    });

  $jqueryValidateProvider.addMethod("alphaSpaces", function (value, element) {
    return this.optional(element) || /^([a-zа-яàáâãäåæçèéêëœìíïîðòóôõöøùúûñüýÿßÞďđ\s])+$/i
      .test(value);
  }, "May only contain letters and spaces.");

  $jqueryValidateProvider.addMethod("dateMx", function (value, element) {
    return this.optional(element) || /^(0[1-9]|[12][0-9]|3[01])(0[1-9]|1[012])(19|20)\d\d$/
      .test(value);
  }, "Must be a valid date format ddmmyyyy.");

  $jqueryValidateProvider.addMethod("startsWithAlphabet", function (value,
    element) {
    return /^[A-Za-z][A-Za-z0-9]*$/.test(value);
  }, "Start with Alphabet and no Spaces allowed");

  // Added below method as firefox was not working with used same property
  // from additional methods min js
  $jqueryValidateProvider.addMethod("alphaNumeric", function (value, element) {
    return /^[a-zA-Z0-9]*$/.test(value);
  }, "Letters and numbers only please");

};

icasMXUIApp.directive('updateTitle', function ($rootScope) {
  return {
    link: function (scope, element) {

      var listener = function (event, toState, toParams, fromState,
        fromParams) {
        var title = 'Welcome to iCAS Mexico';
        if (toState.data && toState.data.pageTitle)
          title = toState.data.pageTitle;
        element.text(title)
      };

      $rootScope.$on('$stateChangeStart', listener);
    }
  }
});

icasMXUIApp.config(function ($logProvider) {
  $logProvider.debugEnabled(false);
});
