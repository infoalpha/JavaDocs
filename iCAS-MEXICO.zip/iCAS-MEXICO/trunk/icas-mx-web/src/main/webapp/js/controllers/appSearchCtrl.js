(function () {
  'use strict';

  angular.module('icasMXUIApp.controllers').controller("AppSearchCtrl", AppSearchCtrl);

  function AppSearchCtrl($state, $scope, $timeout, configFactory, appSearchService) {

    var vm = this;
    this.dateCheck = dateCheck;
    this.validateForm = validateForm;
    this.resetForm = resetForm;
    this.submitForm = submitForm;

    // Initialize date variables
    vm.datePicker = configFactory.datePicker;
    vm.today = new Date();
    vm.minDate = new Date();
    vm.minDate.setDate(vm.today.getDate() - 90);
    vm.dateValid = true;

    // Search parameter variables
    vm.searchParam = {
      'ucid': '',
      'rfc': '',
      'curp': '',
      'orderNumber': '',
      'firstName': '',
      'lastName': '',
      'secondLastName': '',
      'startDate': vm.minDate,
      'endDate': new Date()
    }

    // jQuery Form Validator Rules and Messages
    vm.formvalidate = {
      rules: {
        unifiedTransId: {
          digits: true,
          minlength: 20,
          maxlength: 20
        },
        rfc: {
          alphaNumeric: true,
          minlength: 10,
          maxlength: 13
        },
        curp: {
          alphaNumeric: true,
          minlength: 18,
          maxlength: 18
        },
        orderNumber: {
          alphaNumeric: true,
          minlength: 5,
          maxlength: 10
        },
        firstName: {
          alphaSpaces: true,
          required: {
            depends: function () {
              return vm.nameRequired;
            }
          }
        },
        lastName: {
          alphaSpaces: true,
          required: {
            depends: function () {
              return vm.nameRequired;
            }
          }
        },
        secondLastName: {
          alphaSpaces: true,
          required: {
            depends: function () {
              return vm.nameRequired;
            }
          }
        },
        startDate: {
          required: true,
          dateMx: true
        },
        endDate: {
          required: true,
          dateMx: true
        }
      },
      messages: {
        unifiedTransId: {
          digits: "Please enter valid Unified Transaction ID",
          minlength: "Please enter exactly {0} digits"
        },
        curp: {
          minlength: "Please enter exactly {0} characters"
        }
      },
      validateOnInit: false
    };

    // Custom check to validate names when atleast one field is entered
    /*$scope.$watchCollection(function () {
      return '[' + vm.searchParam.firstName + ',' + vm.searchParam.lastName + ',' + vm.searchParam.secondLastName + ']'
    }, function (newVal, oldVal) {
      newVal !== "[,,]") ? vm.nameRequired = true: vm.nameRequired = false;
      $timeout(function () {
        if (vm.formvalidateapi)
          vm.formvalidateapi.validate();
      }, 0)
    });*/

    function validateForm() {
      if (vm.searchParam.firstName.length || vm.searchParam.lastName.length || vm.searchParam.secondLastName.length) {
        vm.nameRequired = true;
      } else {
        vm.nameRequired = false;
        if (vm.formvalidateapi)
          vm.formvalidateapi.validate();
      }
    }

    // Custom check for Start date and End date
    function dateCheck() {
      (vm.searchParam.startDate > vm.searchParam.endDate) ? vm.dateValid = false: vm.dateValid = true;
      if (vm.searchParam.startDate < vm.minDate)
        vm.searchParam.startDate = vm.minDate;
      if (vm.searchParam.endDate > vm.today)
        vm.searchParam.endDate = vm.today
    }

    // Reset form function
    function resetForm() {
      vm.searchParam = {
        'ucid': '',
        'rfc': '',
        'curp': '',
        'orderNumber': '',
        'firstName': '',
        'lastName': '',
        'secondLastName': '',
        'startDate': vm.minDate,
        'endDate': new Date()
      };
      vm.dateValid = true;
      vm.nameRequired = false;
      vm.errorOccurred = false;
      vm.formvalidateapi.clear();
    };

    // Submit form function
    function submitForm() {
      if (vm.formvalidateapi.valid() && vm.dateValid) {

        // set search parameters in service
        appSearchService.setSearchData(vm.searchParam);

        // get search results list from service
        appSearchService.getSearchListing(vm.searchParam)
          .then(function (response) {
            if (response.length > 0) {
              if (response.length === 1) {
                $state.go('main.appSrchDetails');
              } else {
                appSearchService.setAppSearchResults(response);
                $state.go('main.appSrchResultList');
              }
            } else {
              vm.errorMsg = "Sorry, no results were found. Please try again."
              vm.errorOccurred = true;
            }
          }, function (error) {
            // Error occurred while retrieving data
            vm.errorMsg = error;
            vm.errorOccurred = true;
          });
      }
    }

    // Restore form values on returning from results page
    $scope.$on('$stateChangeSuccess',
      function (event, toState, toParams, fromState, fromParams) {
        if ((fromState.name === "main.appSrchResultList") || (fromState.name === "main.appSrchDetails")) {
          var data = appSearchService.getSearchData();
          if (data !== '') {
            vm.searchParam = appSearchService.getSearchData();
          }
        }
      })
  }

  AppSearchCtrl.$inject = ["$state", "$scope", "$timeout", "configFactory", "appSearchService"];
})();
