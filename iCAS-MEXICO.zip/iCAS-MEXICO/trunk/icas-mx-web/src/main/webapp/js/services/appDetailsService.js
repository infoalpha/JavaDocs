(function () {
  'use strict';

  angular.module('icasMXUIApp.services').service("appDetailsService", appDetailsService);

  function appDetailsService($http, $log) {

    var vm = this;

    // Get Application Reference Information
    vm.appRefInfo = function (data) {
      var promise = $http({
        method: 'GET',
        url: '/data/sample/appRefInfo.json'
      }).then(function (response) {
        // this callback will be called asynchronously
        // when the response is available
        return response.data;
      }, function (httpError) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
        throw httpError.status + " : " + httpError.data;
      });

      return promise;
    }

    // Get Credit Decision data
    vm.appCreditDecision = function (data) {
      var promise = $http({
        method: 'GET',
        url: '/data/sample/appCreditDecision.json'
      }).then(function (response) {
        // this callback will be called asynchronously
        // when the response is available
        return response.data;
      }, function (httpError) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
        throw httpError.status + " : " + httpError.data;
      });

      return promise;
    }

    // Set Credit Decision - Update Application
    vm.updateCreditDecision = function (data) {
      var promise = $http({
        method: 'GET', //change to POST on actual implementation
        // data: data,
        // url: '/data/sample/error.json' //to simulate error on update
        url: '/data/sample/success.json'
      }).then(function (response) {
        // this callback will be called asynchronously
        // when the response is available
        return response.data;
      }, function (httpError) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
        throw httpError.status + " : " + httpError.data;
      });

      return promise;
    }

    // Get Black List data
    vm.appBlackList = function (data) {
      var promise = $http({
        method: 'GET',
        url: '/data/sample/appBlackList.json'
      }).then(function (response) {
        // this callback will be called asynchronously
        // when the response is available
        return response.data;
      }, function (httpError) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
        throw httpError.status + " : " + httpError.data;
      });

      return promise;
    }

    // Get Notes data
    vm.appNotes = function (data) {
      var promise = $http({
        method: 'GET',
        url: '/data/sample/appNotes.json'
      }).then(function (response) {
        // this callback will be called asynchronously
        // when the response is available
        return response.data;
      }, function (httpError) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
        throw httpError.status + " : " + httpError.data;
      });

      return promise;
    }

  }

  appDetailsService.$inject = ["$http", "$log"];

})();
