// $uibModalInstance represents a modal window (instance) dependency.

(function () {
  'use strict';

  angular.module('icasMXUIApp.controllers').controller("ModalInstanceCtrl", ModalInstanceCtrl);

  function ModalInstanceCtrl($scope, $uibModalInstance, options, $timeout) {

    $scope.options = angular.copy(options);

    if ($scope.options.autoClose) {
      $timeout(function () {
        $uibModalInstance.close($scope.options.scopeData);
      }, $scope.options.autoCloseDelay);
    }

    $scope.ok = function () {
      $uibModalInstance.close($scope.options.scopeData);
    };

    $scope.cancel = function () {
      $uibModalInstance.dismiss('cancel');
    };

    $scope.reset = function () {
      $scope.options = angular.copy(options);
    }

  }

  ModalInstanceCtrl.$inject = ["$scope", "$uibModalInstance", "options", "$timeout"];
})();
