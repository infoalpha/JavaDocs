(function () {
  'use strict';
  angular.module('icasMXUIApp').service("userListingService", userListingService);

  function userListingService($http) {

    var vm = this;

    // Get User List
    vm.getUserList = function () {
      var promise = $http({
        method: 'GET',
        url: 'http://d1c1m119.vci.att.com:17170/icasweb-mx/api/admin/userMaintenance/getAllUsers'
      }).then(function (response) {
        return response.data;
      }, function (httpError) {
        throw httpError.status + " : " + httpError.data;
      });

      return promise;
    }

  }
  userListingService.$inject = ["$http"];

})();
