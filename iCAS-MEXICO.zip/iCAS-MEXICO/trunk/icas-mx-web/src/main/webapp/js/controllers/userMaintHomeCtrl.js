(function () {
  'use strict';

  angular.module('icasMXUIApp.controllers').controller("userMaintHomeCtrl", userMaintHomeCtrl);

  function userMaintHomeCtrl($state, $scope, $timeout, configFactory, userMaintHomeService) {
    var vm = this;
    this.listUsers = listUsers;
    this.searchUser = searchUser;
    this.reset = reset;

    // Search parameter variables
    vm.searchParam = {
      'attuid': ''
    }

    function listUsers() {
      $state.go('main.usersList');
    }

    function searchUser() {
      userMaintHomeService.searchUser(vm.searchParam.attuid)
        .then(function (response) {
          userMaintHomeService.setSearchUserResultData(response.data);
          $state.go('main.updateUser');
        }, function (error) {
          // Dont do anything
        });
    }

    function reset() {
      vm.searchParam = {
        'attuid': ''
      }
    }

  }
  userMaintHomeCtrl.$inject = ["$state", "$scope", "$timeout", "configFactory", "userMaintHomeService"];
})();
