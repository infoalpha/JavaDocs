(function () {
  'use strict';
  angular.module('icasMXUIApp').service("userMaintHomeService", userMaintHomeService);

  function userMaintHomeService($http) {
    var vm = this;
    var searchUserResultData = '';

    // Set Search Results based on attuid
    vm.setSearchUserResultData = function (data) {
      searchUserResultData = data;
    }

    vm.getSearchUserResultData = function () {
      return searchUserResultData;
    }

    vm.searchUser = function (attuid) {

      var url = "http://d1c1m119.vci.att.com:17170/icasweb-mx/api/admin/userMaintenance/" + attuid;
      var response = $http.get(url);
      return response;
    };

  }
  userMaintHomeService.$inject = ["$http"];

})();
