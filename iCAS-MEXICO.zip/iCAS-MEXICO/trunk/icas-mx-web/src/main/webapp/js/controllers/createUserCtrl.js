(function () {
  'use strict';

  angular.module('icasMXUIApp.controllers').controller("CreateUserCtrl", CreateUserCtrl);

  function CreateUserCtrl($state, $scope, $rootScope, $timeout, configFactory, createUserService) {

    // This controller will be called as createUser in our application

    var vm = this;

    // create User form  variables
    vm.saveParam = {
      'operatorId': $rootScope.loggedInUser.attuid,
      'attuid': '',
      'firstName': '',
      'lastName': '',
      'secondLastName': '',
      'emailAddress': '',
      'phone': '',
      'accessType': '',
      'languagePref': '',
      'addressLine1': '',
      'externalStreetNumber': '',
      'internalStreetNumber': '',
      'addressLine2': '',
      'municipality': '',
      'city': '',
      'state': '',
      'postalCode': '',
      'neigborhood': '',
      'country': '',

    };


    // jQuery Form Validator Rules and Messages
    this.formvalidate = {

      rules: {
        attuid: {
          minlength: 6,
          maxlength: 6,
          required: true
        },
        firstName: {
          minlength: 4,
          maxlength: 60,
          alphaSpaces: true,
          required: true
        },
        lastName: {
          minlength: 4,
          maxlength: 60,
          alphaSpaces: true,
          required: true
        },
        secondLastName: {
          minlength: 4,
          maxlength: 60,
          alphaSpaces: true,
          required: true
        },
        emailAddress: {
          minlength: 4,
          maxlength: 60,
          email: true,
          required: true
        },
        phoneNumber: {
          digits: true,
          required: true,
          minlength: 4,
          maxlength: 60
        },
        accessType: {
          required: true
        },
        languagePref: {
          required: true
        },
        addressLine1: {
          required: true
        },
        externalStreetNumber: {
          required: true
        },
        municipality: {
          required: true
        },
        city: {
          required: true
        },
        neigborhood: {
          required: true
        },
        country: {
          required: true
        },
      },
      messages: {
        attuid: {
          minlength: "Please enter valid ATTUID"
        }
      },

      validateOnInit: false,

    };



    // Save form function
    $scope.saveUser = function () {

      if (vm.formvalidateapi.valid()) {

        var response = createUserService.saveUser(vm.saveParam);
        response.success(function (data, status, headers, config) {


          vm.success = true;
          vm.serverError = false;
          vm.successmessageBold = "Success!";
          vm.successmessage = "New User Created .";
        });
        response.error(function (data, status, headers, config) {


          vm.serverError = true;
          vm.success = false;
          vm.serverErrorBold = "Sorry Could not save";
          vm.serverErrorMessage = status;

        });
        /*    if (response.success) {
                        
                        vm.success = true;
                        vm.successmessageBold = "Successfully!";
                        vm.successmessage = "Created New User.";

                    } else {
                        alert("error");
                        vm.serverError = true;
                        vm.serverErrorBold = "Sorry Could not save";
                        vm.serverError = response.message;
                    }
                    
                   
        }); */
        // get search results list from service
        /* createUserService.saveUser(vm.saveParam)
             .then(function (response) {

                          if (response.success) {

                                vm.success = true;
                                vm.successmessageBold = "Successfully!";
                                vm.successmessage = "Created New User.";


                            } else {

                               
                               
                                vm.serverError = true;
                             vm.serverErrorBold ="Sorry Could not save";
                             vm.serverError = response.message;
                            }
                            
            



                 },
                 function (error) {
                     // Error occurred while saving new user

                     vm.serverError = true;
                     vm.serverErrorBold = "Sorry Could not save";
                     vm.serverError = response.message;
                 });
                 
                 */
      }
    }






  }




  CreateUserCtrl.$inject = ["$state", "$scope", "$rootScope", "$timeout", "configFactory", "createUserService"];
})();
