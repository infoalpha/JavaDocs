(function () {
  'use strict';

  angular.module('icasMXUILogin').service("firstTimeUserService", firstTimeUserService);

  function firstTimeUserService($http, $log, $q, $filter, $timeout, $rootScope) {
    var vm = this;

    vm.firstTimeUserSignUp = function (username, password) {

      return $http.post('http://d1c1m119.vci.att.com:17170/icasweb-mx/api/user/updateUserLoginPassword', {
        userName: username,
        password: password
      });

    };

  }

  firstTimeUserService.$inject = ["$http", "$log", "$q", "$filter", "$timeout", "$rootScope"];

})();
