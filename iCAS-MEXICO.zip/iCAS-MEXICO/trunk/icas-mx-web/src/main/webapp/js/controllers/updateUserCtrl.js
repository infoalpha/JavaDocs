(function () {
  'use strict';

  angular.module('icasMXUIApp.controllers').controller("updateUserCtrl", updateUserCtrl);

  function updateUserCtrl($state, $scope, $timeout, modalService, updateUserService, userMaintHomeService) {
    var vm = this;
    this.showHistory = showHistory;

    vm.userInfo = {
      'attuid': '',
      'firstName': '',
      'lastName': '',
      'secondLastName': '',
      'emailAddress': '',
      'phone': '',
      'language': '',
      'preferredLanguage': '',
      'addressLine1': '',
      'externalStreetNumber': '',
      'internalStreetNumber': '',
      'addressLine2': '',
      'municipality': '',
      'city': '',
      'state': '',
      'postalCode': '',
      'neigborhood': '',
      'country': '',
    }

    function showHistory() {
      modalService.createModal({
        type: 'dynamic',
        templateUrl: 'partials/admin/user-maintainance/modalShowHistory.html',
        controller: 'ModalUserHistory',
        size: 'lg',
        scopeData: vm.userInfo.attuid
      });
    }

    // load initial data we got by searching for attuid
    var initialize = function () {

      // get selected application id from service and have it stored in $scope.data to access it in html
      var data = userMaintHomeService.getSearchUserResultData();
      vm.userInfo.attuid = data.attuid;
      vm.userInfo.firstName = data.firstName;
      vm.userInfo.lastName = data.lastName;
      vm.userInfo.secondLastName = data.secondLastName;
      vm.userInfo.emailAddress = data.emailAddress;
      vm.userInfo.phone = data.phone;
      vm.userInfo.preferredLanguage = data.preferredLanguage;
      vm.userInfo.addressLine1 = data.addressLine1;
      vm.userInfo.externalStreetNumber = data.externalStreetNumber;
      vm.userInfo.internalStreetNumber = data.internalStreetNumber;
      vm.userInfo.addressLine2 = data.addressLine2;
      vm.userInfo.municipality = data.municipality;
      vm.userInfo.city = data.city;
      vm.userInfo.state = data.state;
      vm.userInfo.postalCode = data.postalCode;
      vm.userInfo.neigborhood = data.neigborhood;
      vm.userInfo.country = data.country;
    }

    initialize();

  }
  updateUserCtrl.$inject = ["$state", "$scope", "$timeout", "modalService", "updateUserService", "userMaintHomeService"];
})();
