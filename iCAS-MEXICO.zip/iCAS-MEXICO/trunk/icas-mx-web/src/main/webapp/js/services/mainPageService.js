(function () {
    'use strict';

    angular.module('icasMXUIApp').service("mainPageService", mainPageService);

    function mainPageService($http, $log, $q, $filter, $timeout, $rootScope) {
        var vm = this;

        vm.logout = function (attuid) {

            var url = "http://d1c1m119.vci.att.com:17170/icasweb-mx/api/user/logout/" + attuid;
            var response = $http.post(url);
            return response;
        };

    }

    mainPageService.$inject = ["$http", "$log", "$q", "$filter", "$timeout", "$rootScope"];

})();