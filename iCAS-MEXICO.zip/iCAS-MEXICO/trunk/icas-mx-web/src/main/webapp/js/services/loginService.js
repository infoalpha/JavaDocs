(function () {
    'use strict';

    angular.module('icasMXUILogin').service("loginService", loginService);

    function loginService($http, $log, $q, $filter, $timeout, $rootScope) {
        var vm = this;

        vm.loginUser = function (username, password) {

            var response = $http.post('http://d1c1m119.vci.att.com:17170/icasweb-mx/api/user/login', {
                userName: username,
                password: password
            });

            return response;


        };

    }

    loginService.$inject = ["$http", "$log", "$q", "$filter", "$timeout", "$rootScope"];

})();