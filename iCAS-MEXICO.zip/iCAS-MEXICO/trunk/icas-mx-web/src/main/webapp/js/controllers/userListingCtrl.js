(function () {
  'use strict';

  angular.module('icasMXUIApp.controllers').controller("userListingCtrl", userListingCtrl);

  function userListingCtrl($state, $scope, $timeout, configFactory, userListingService, userMaintHomeService) {

    var vm = this;
    vm.updateUser = updateUser;

    // Pagination Settings
    vm.currentPage = 1;
    vm.itemsPerPage = 10;
    vm.maxSize = 5; //Number of pager buttons to show

    function updateUser(id) {
      userMaintHomeService.searchUser(id)
        .then(function (response) {
          userMaintHomeService.setSearchUserResultData(response.data);
          $state.go('main.updateUser');
        }, function (error) {
          // Dont do anything
        });
    }

    var initialize = function () {
      userListingService.getUserList()
        .then(function (response) {
            vm.userList = response;
          },
          function (error) {
            // Error occurred while retrieving data
          });
    }

    initialize();

  }

  userListingCtrl.$inject = ["$state", "$scope", "$timeout", "configFactory", "userListingService", "userMaintHomeService"];
})();
