// $uibModalInstance represents a modal window (instance) dependency.

(function () {
        'use strict';

        angular.module('icasMXUILogin').controller("FirstTimeUserModalCtrl", FirstTimeUserModalCtrl);

        function FirstTimeUserModalCtrl($scope, $uibModalInstance, firstTimeUserService) {

            var vm = this;



            // Login Form parameter variables
            vm.loginParam = {
                'loginUserName': '',
                'loginPassword': '',
                'confirmPassword': '',

            };

            // jQuery Form Validator Rules and Messages
            this.formvalidate = {

                rules: {
                    loginUserName: {
                        minlength: 6,
                        maxlength: 60,
                        startsWithAlphabet: true,
                        required: true
                    },
                    loginPassword: {
                        minlength: 4,
                        maxlength: 20,
                        alphaNumeric: true,
                        required: true
                    },
                    confirmPassword: {
                    equalTo: "#loginPasswordId"
                    },

                },
                messages: {
                    loginUserName: {
                        required: "Please enter valid username",
                        minlength: "Invalid Username, Username atleast 6 characters required",
                        startsWithAlphabet: "Start with Alphabet and no spaces allowed"
                    },
                    loginPassword: {
                        required: "Please enter valid Password",
                        minlength: "Invalid Password, Password atleast 4 characters required",
                        alphaNumeric: "Password must be alphanumeric"
                    },
                    confirmPassword: {
                        equalTo:"The password and its confirm Password are not the same"
                    }

                },

                validateOnInit: false,
                onkeyup: function () {

                    // enable submit button only if all fields are valid

                    if ($('#loginUserNameId').val().length > 5 && $('#loginPasswordId').val().length > 3 && $('#confirmPasswordId').val().length > 3) {
                        if ($('#loginUserNameId').valid() && $('#loginPasswordId').valid() && $('#confirmPasswordId').valid()) {
                            $('#saveID').removeAttr('disabled');
                        }
                    } else {
                        $('#saveID').attr('disabled', 'disabled');
                    }
                }
            };

            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };
            $scope.reset = function () {

                vm.loginParam = {
                    'loginUserName': '',
                    'loginPassword': '',
                    'confirmPassword': ''
                };
                vm.formvalidateapi.clear();
            };


                // Submit form function
                $scope.saveForm = function () {

                    if (vm.formvalidateapi.valid()) {
                        firstTimeUserService.firstTimeUserSignUp(vm.loginParam.loginUserName, vm.loginParam.loginPassword)
                            .then(function (response) {
                                //  $uibModalInstance.close(response.data);
                                vm.success = true;
                                vm.servererror = false;
                                vm.successmessageBold = "Success!";
                                vm.successmessage = "New User Created .";
                            }, function (error) {
                                vm.servererror = true;
                                vm.success = false;
                                vm.servermessageBold = "First Time User Signup Failed!";
                                vm.servermessage = "Please try again";
                            });

                    }

                };

            }

            FirstTimeUserModalCtrl.$inject = ["$scope", "$uibModalInstance", "firstTimeUserService"];
        })();